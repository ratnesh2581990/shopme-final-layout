/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :   Common scripts
 Description     :   All Common scripts are in this file.
 Included        :
 Last Modified   :   Aug 16,2017 / Arivarasi
 Assigned to     :
 */
////siteurl = $('#siteurl').val();
//currenturl = $('#currenturl').val();
//

///*
$('#scroll_top_id_serv').on('scroll', function () {
    if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
        $('#showmr_scrll_serv').css('display', 'none'), 300;
    } else {
        $('#showmr_scrll_serv').css('display', 'block'), 300;
    }
});
/************profile page accordian ***************/
$(function () {
    var Accordion = function (el, multiple) {
        this.el = el || {};
        this.multiple = multiple || false;
        // Variables privadas
        var links = this.el.find('.link');
        // Evento
        links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown);
    };
    Accordion.prototype.dropdown = function (e) {
        var $el = e.data.el;
        $this = $(this),
                $next = $this.next();
        $next.slideToggle();
        $this.parent().toggleClass('open');
        if (!e.data.multiple) {
            $el.find('.profile-submenu').not($next).slideUp().parent().removeClass('open');
        }
        ;
    };
    var accordion = new Accordion($('#profile-accordion'), false);
});
$(function () {
    $.fn.parsley.defaults = {
// basic data-api overridable properties here..
        inputs: 'input, textarea, select'           // Default supported inputs.
        , excluded: 'input[type=hidden], :disabled' // Do not validate input[type=hidden] & :disabled.
        , trigger: false                            // $.Event() that will trigger validation. eg: keyup, change..
        , animate: true                             // fade in / fade out error messages
        , animateDuration: 300                      // fadein/fadout ms time
        , focus: 'first'                            // 'fist'|'last'|'none' which error field would have focus first on form validation
        , validationMinlength: 3                    // If trigger validation specified, only if value.length > validationMinlength
        , successClass: 'has-success'           // Class name on each valid input
        , errorClass: 'has-error'               // Class name on each invalid input
        , errorMessage: false                       // Customize an unique error message showed if one constraint fails
        , validators: {}                            // Add your custom validators functions
        , showErrors: true                          // Set to false if you don't want Parsley to display error messages
        , messages: {}                              // Add your own error messages here

//some quite advanced configuration here..
        , validateIfUnchanged: false                                          // false: validate once by field value change
        , errors: {
            classHandler: function (elem, isRadioOrCheckbox) {
                // specify where parsley error-success classes are set
                return $(elem).parents(".form-group");
            }
            , container: function (elem, isRadioOrCheckbox) {}
            , errorsWrapper: '<span class="help-block"></span>'                                        // do not set an id for this elem, it would have an auto-generated id
            , errorElem: '<span></span>'                                            // each field constraint fail in an li
        }
        , listeners: {
            onFieldValidate: function (elem, ParsleyForm) {
                return false;
            } // Executed on validation. Return true to ignore field validation
            , onFormSubmit: function (isFormValid, event, ParsleyForm) {}     // Executed once on form validation
            , onFieldError: function (elem, constraints, ParsleyField) {}     // Executed when a field is detected as invalid
            , onFieldSuccess: function (elem, constraints, ParsleyField) {}   // Executed when a field passes validation
        }
    };
    var parseRequirement = function (requirement) {
        if (isNaN(+requirement))
            return parseFloat(jQuery(requirement).val());
        else
            return +requirement;
    };
    window.Parsley.addValidator('gt', {
        validateString: function (value, requirement) {
            return parseFloat(value) > parseRequirement(requirement);
        },
        priority: 32
    });
    var cityNames = new Bloodhound({
        datumTokenizer: function (datum) {
            return Bloodhound.tokenizers.whitespace(datum.value);
        },
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            wildcard: '%QUERY',
            url: URL_MAIN_PATH + '/search/api/city/search?city=%QUERY',
            transform: function (response) {
                // Map the remote source JSON array to a JavaScript object array
                return $.map(response, function (item) {
                    return {
                        value: item.city
                    };
                });
            }
        }
    });
// Instantiate the Typeahead UI
    $('#field2').typeahead(null, {
        display: 'value',
        source: cityNames
    }).bind('typeahead:select', function (ev, suggestion) {
//  console.log('Selection: ' + JSON.stringify(suggestion));
    });
    /***
     * Jscroll Pagination
     */
    $('.infinite-scroll').jscroll({
        nextSelector: 'a[rel=next]:last',
        loadingHtml: "<img style='display:block;margin:auto;' src='/assets/img/site/loader.gif'></img>",
        autoTrigger: false,
        padding: 0,
        autoTriggerUntil: 10,
        callback: function () {



            //  var url = $('a[rel=next]:last').attr('href');

            // window.history.pushState({url: "" + url + ""}, '', url);

            $('ul.pagination:not(:last)').hide();
        }
    });
//    $('.infinite-scroll').jscroll({
//        nextSelector: 'a[rel=next]:last',
//        loadingHtml: "<img style='display:block;margin:auto;' src='/assets/img/site/loader.gif'></img>",
//        autoTrigger: false,
//        padding: 0,
//        autoTriggerUntil: 10,
//        callback: function () {
//
//            $('ul.pagination:not(:last)').hide();
//        }
//    });
    /*** auto focus modal ***/
    $(document).on('shown.bs.modal', '.modal', function () {
        var inpVal = $(this).find('[autofocus]').val();
    });
    /*** disable form button on submit ****/
    $('form').submit(function () {
        $(this).children('input[type=submit]').prop('disabled', true);
    });
    /******** Go to top ***********/
    if ($('.go-top').length > 0) {
        $('.go-top').click(function () {
            $('html,body').animate({
                scrollTop: 0
            });
        });
    }
    /************ Global Db index page - thumbnail hover effect*******/
    $('.glob-up-bt-open').click(function () {
//        $('.glob-box-overlay').animate({
//            'bottom': '-100%'
//        });
        $(this).parents('.glob-ind-inner').find('.glob-box-overlay')
                .animate({
                    'bottom': '0%'
                });
    });
    $('.glob-up-bt-close').click(function () {
        $(this).parents('.glob-ind-inner').find('.glob-box-overlay')
                .animate({
                    'bottom': '-100%'
                });
    });
    $('[data-toggle="popover"]').popover();
    $('body').on('click', function (e) {
        $('[data-toggle="popover"]').each(function () {
//the 'is' for buttons that trigger popups
//the 'has' for icons within a button that triggers a popup
            if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                $(this).popover('hide');
            }
        });
    });
    //***** form in helpview *****//
    if ($('#helpForm').length) {
        $("#helpForm").parsley({
            successClass: "has-success",
            errorClass: "has-error",
            classHandler: function (el) {
                return el.$element.closest(".form-group");
            },
            errorsWrapper: "<span class='help-block'></span>",
            errorTemplate: "<span></span>"
        });
    }

//********   rippleEffect ***********//
    var rippleEffect = (function () {
        function rippleEffect(event) {
            var time = 2000, self = this, rect = self.getBoundingClientRect(), x = event.clientX - rect.left,
                    y = event.clientY - rect.top, circle = document.createElement("div");
            circle.style.top = y + "px";
            circle.style.left = x + "px";
            circle.className = "ripple animate";
            self.appendChild(circle);
            setTimeout(function () {
                self.removeChild(circle);
            }, time);
        }
        var targets = document.getElementsByClassName("ripple-effect")
                , l = targets.length
                , i;
        for (i = 0; i < l; i++) {
            targets[i].addEventListener('mousedown', rippleEffect, false);
        }
    });
    //********        footer accordion    (not in use)   ************//
    function toggleChevron(e) {
        $(e.target).prev('.panel-heading').find("i.indicator").toggleClass('animate');
        $(e.target).prev('.panel-heading').find("i.ic").toggleClass('dis');
        $(e.target).prev('.panel-heading').find("h4").toggleClass('act-clr');
    }
    $('#foot-menu-accordion').on('hidden.bs.collapse', toggleChevron);
    $('#foot-menu-accordion').on('shown.bs.collapse', toggleChevron);
    $('#accordion').on('hidden.bs.collapse', toggleChevron);
    $('#accordion').on('shown.bs.collapse', toggleChevron);
    $('#prod-accordion').on('hidden.bs.collapse', toggleChevron);
    $('#prod-accordion').on('shown.bs.collapse', toggleChevron);
    $('#prod-accordion').collapse(('show'));
    //******* category slider **********//
    $('.pro-cat').click(function () {
        $(this).find('.fa-angle-down').toggleClass('animate');
        $('.pro-ul').slideToggle();
        $('.serv-ul').slideUp();
        $('.serv-cat').find('.fa-angle-down').removeClass('animate');
    });
    $('.serv-cat').click(function () {
        $(this).find('.fa-angle-down').toggleClass('animate');
        $('.serv-ul').slideToggle();
        $('.pro-ul').slideUp();
        $('.pro-cat').find('.fa-angle-down').removeClass('animate');
    });
    $('.search-letter li').click(function () {
        $(this).addClass('active');
        $(this).prevAll('li').removeClass('active');
        $(this).nextAll('li').removeClass('active');
        $('.countrylist .border').addClass('border-none');
    });
    $('.search-letter .all').click(function () {
        $('.countrylist .border').addClass('border-block');
    });
//***********    tradeindexpage    **********//
    if ($(window).width() > 1200) {
        $(".trade-sec").mouseenter(function () {
            index = $(this).index();
            a = index + 1;
            $(this).children("a").stop().animate({"top": "8px", "left": "5px", "right": "5px", "bottom": "5px", "width": "auto", "height": "210px"});
            t1 = Number(a) - 6;
            b1 = Number(a) + 6;
            p = Number(a) - 1;
            n = Number(a) + 1;
            $(".trade-sec:nth-child(" + t1 + ")").stop().animate({"top": "-20px", "left": "0px"});
            $(".trade-sec:nth-child(" + b1 + ")").stop().animate({"top": "20px", "left": "0px"});
            $(".trade-sec:nth-child(" + p + ")").stop().animate({"left": "-20px", "top": "0px"});
            $(".trade-sec:nth-child(" + n + ")").stop().animate({"left": "20px", "top": "0px"});
            $(this).children("a").addClass("background");
        });
        $(".trade-sec").mouseleave(function () {
            $(this).children("a").stop().animate({"top": "25px", "left": "25px", "right": "25px", "bottom": "25px", "width": "auto", "height": "180px"});
            index = $(this).index();
            a = index + 1;
            t1 = Number(a) - 6;
            b1 = Number(a) + 6;
            p = Number(a) - 1;
            n = Number(a) + 1;
            $(".trade-sec:nth-child(" + t1 + ")").stop().animate({"top": "0px", "left": "0px"});
            $(".trade-sec:nth-child(" + b1 + ")").stop().animate({"top": "0px", "left": "0px"});
            $(".trade-sec:nth-child(" + p + ")").stop().animate({"left": "0px", "top": "0px"});
            $(".trade-sec:nth-child(" + n + ")").stop().animate({"left": "0px", "top": "0px"});
            $(".trade-sec").stop().animate({"left": "0px", "top": "0px"});
            $(this).children("a").removeClass("background");
        });
        $(".trade-sec:nth-child(6)").mouseenter(function () {
            $(".trade-sec:nth-child(7)").stop().animate({"left": "0px"});
        });
        $(".trade-sec:nth-child(12)").mouseenter(function () {
            $(".trade-sec:nth-child(13)").stop().animate({"left": "0px"});
        });
        $(".trade-sec:nth-child(7)").mouseenter(function () {
            $(".trade-sec:nth-child(6)").stop().animate({"left": "0px"});
        });
        $(".trade-sec:nth-child(13)").mouseenter(function () {
            $(".trade-sec:nth-child(12)").stop().animate({"left": "0px"});
        });
    }


});
//****** header script *********//
$(function () {
    $('.serch-menu-form').submit(function () {
        $('.navbar-collapse.collapse').removeClass('in');
    });
    $(".search-icon").click(function () {
        $('.serch-menu-form').stop().slideToggle();
    });
    $(".search-menu-list .dropdown .dropdown-toggle").mouseenter(function () {
        $(".search-menu-list .dropdown .dropdown-toggle").parent().removeClass("open");
        $(this).parent().addClass("open");
    });
    $(".search-menu-list .dropdown .dropdown-toggle").mouseleave(function () {
        $(".search-menu-list .dropdown .dropdown-toggle").parent().removeClass("open");
        $(this).parent().removeClass("open");
    });
    $(".search-menu-list .dropdown-menu").hover(function () {
        $(".search-menu-list .dropdown-menu").parent().removeClass("open");
        $(this).parent().addClass("open");
    });
    $(".search-menu-list .dropdown-menu").mouseleave(function () {
        $(".search-menu-list .dropdown .dropdown-toggle").parent().removeClass("open");
    });
    //all news
    if ($('#awards').length) {
        $('#awards').vTicker({
            speed: 2000,
            pause: 1000,
            //                    animation: 'fade',
            mousePause: true,
            direction: "up",
            showItems: 10
//            height: 200
        });
    }

    /* all page banners */
    if (typeof bannerurl != '') {
        $.ajax({
            url: URL_MAIN_PATH + '/all-banners',
            data: {
                bannerurl: bannerurl,
                member_id: MEMBER_ID
            },
            type: 'post',
            success: function (e) {
                var results = e.split('||*||');
//                results = results.replace(/\s/g, '');

                for (var i = 0; i < results.length; i++) {
                    if (i != results.length - 1) {
                        if (i % 2 === 0) { // index is even
                            var j = i + 1;
                            var div1 = '#' + results[i];
                            var div2 = div1.replace(/\s/g, '');
//                            alert(results[j]);
                            if ($(div2).is(':empty')) {
                                $(div2).html(results[j]);
                            } else {
                                $(div2).append(results[j]);
                            }
//                            $(div2).html(results[j]);
                        }
                    }
                }
            }
        });
    }
});
//function postbannerclick() {
//    var formdata = $('#adbannerpost').serialize();
//    $.ajax({
//        url: URL_MAIN_PATH + '/adbannerpost',
//        type: 'post',
//        data: formdata,
//        success: function (e) {
//            if (e.status == 0) {
//            } else if (e.status == 1) {
//                $('#postedid').val(e.postedid);
//                window.location.href = URL_MAIN_PATH + '/banner-success';
//            }
//        }
//    });
//}
/// Header fixed position ///
$(window).scroll(function () {
//    var scr = $(window).scrollTop();
//    var ch = $('#slideshow').outerHeight(true);
//    if (scr >= ch) {
//        $('.go-top').show();
//    } else {
//        $('.go-top').hide();
//    }
    if ($(window).width() > 767) {
        $wt = $(window).scrollTop();
        if ($wt > 10) {
            $('.search-header').addClass('fixed');
        } else {
            $('.search-header').removeClass('fixed ');
        }
    }
    if ($(window).scrollTop() > 400) {
        $("#premium-menu").addClass('sticky-premium-nav');
    } else {
        $("#premium-menu").removeClass('sticky-premium-nav');
    }
});
/////////////      zoom       ///////////
$(document).ready(function () {
    $('.okzoomImg').okzoom({width: 300, height: 300, round: true, border: "1px solid black", shadow: "0 0 5px #000"});
});
/** Condition - No Data in HS Code except China **/
var hscod_count = $('#hscode_country').val();
if (hscod_count != 'China') {
    $('.hswrap-list').find('.panel-title').removeClass('plus-minus');
}
/** HS Code - Need to remove these lines when fill data to all country **/
function loadSubHsCodes(slug, code, incre, plus) {
    $.ajax({
        url: '/hs-codes/getsubproducts.html',
        data: {
            cslug: slug,
            hscode: code
        },
        type: 'post',
        success: function (e) {
            $('#subsubhscode' + incre).css('display', 'block');
            $('#subsubhscode' + incre).html(e);
            var countcode = $('#subcodehs').val();
            if (countcode == '6') {
                $('.hswrap-list').find('.panel-title').removeClass('plus-minus');
            }
        }
    });
}

var countcode = $('#subcodehs').length;
if (countcode == '6') {
    $('#hscode-list').find('.panel-title').removeClass('plus-minus');
}
/// request for delivery charge ecomm button ///
function requestsend(memid, supplierid, product_id, pincode) {
    $.ajax({
        url: URL_PRODUCTS_PATH + '/reuest-login-post',
        data: {supplierid: supplierid, reqproductid: product_id, sendpincode: pincode, action: 'pinreq'},
        type: 'post',
        success: function (e) {
//            console.log(e);
            $('#sucreq').show();
            setTimeout(function () {
                $('#sucreq').html();
                $('#sucreq').hide();
            }, 2000)
        }
    });
}
/// currency and unit converter //
function numeric(e) {
    var k;
    document.all ? k = e.keyCode : k = e.which;
    return ((k >= 46 && k < 58) || k == 8 || k == 32 || k == 13);
}
/// country names by alphabetical order in GD, City, Country
function countrylistfilter(id) {
    if (id == 'all') {
        $('.countrylist').css('display', 'block');
        $('#' + id).css('display', 'block');
    } else {
        $('.countrylist').css('display', 'none');
        $('#' + id).css('display', 'block');
        $('#' + id).css('border', 'none');
        var countryht = $('#' + id).length;
        if (countryht == '0') {
            $('.no-record-error').show();
        } else {
            $('.no-record-error').hide();
        }
    }
}

//function filter_catlist(element) {
//    var value = $(element).val();
//    $("#supsubcatlist li").each(function () {
//        if ($(this).text().search(new RegExp(value, "i")) > -1) {
//            $(this).show();
//            $('#noresult_cat').hide('fast');
//        } else {
//            $(this).hide();
//            $('#noresult_cat').show();
//        }
//    });
//}
//
//

// question and answer
$(document).ready(function () {
    $(".lat-question h3").click(function () {
        $(".res-qus-box").slideToggle("slow");
    });
    // core modules category more button process
    $("#showmr_scrll,#showmr_scrll1,#showmr_scrll2").click(function () {
        $('.prod-category').animate({
            scrollTop: '+=150'
        }, 500);
    });
    // otherpage header mobile menu hover action
//    if (screen.width > 767) {
//        $('.categ-sec-blk').hover(function () {
//            alert(1);
//            $('.categ-drpdown').fadeToggle();
//        });
//    }

    $('.prod-category').on('scroll', function () {
        if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
            $('#showmr_scrll,#showmr_scrll1,#showmr_scrll2').css('display', 'none'), 300;
        } else {
            $('#showmr_scrll,#showmr_scrll1,#showmr_scrll2').css('display', 'inline-block'), 300;
        }
    });


    $("#adbannerpost").on("submit", function (e) {
        e.preventDefault();
        if ($(this).parsley().isValid()) {
//        var formData = $(this).serializeArray();
            var formdata = new FormData($("#adbannerpost")[0]);
//        console.log(form);
            $.ajax({
                url: URL_MAIN_PATH + '/adbannerpost',
                type: 'post',
                data: formdata,
                async: false, // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (e) {
                    if (e.status == 0) {
                    } else if (e.status == 1) {
//                        window.location.href = URL_MAIN_PATH + '/banner-success';
                        var paymentString = e.paymentString;
                        $('#billdesk_pay_msg').val(paymentString);
//                $('#bill_pay_section').load(location.href + ' #bill_pay_section');
                        document.getElementById('billdesk_payment_form').submit();
                    }
                }
            });
        }
    });
});
if ($(window).innerWidth() <= 767) {
    $('.categ-sec-blk').click(function () {
        $('.categ-drpdown').fadeToggle();
    });
} else {
    $('.categ-sec-blk').hover(function () {
        $('.categ-drpdown').fadeToggle();
    });
}
/// Product Categories list- search box
function filtersupp_catlist(element, serachid) {
    var value = $(element).val();
    var length = $(element).val().length;
//    var prdheight = $(serachid).length();
//    console.log(prdheight);
//    console.log(length);
    if (length > 0) {
        $("." + serachid + " li").each(function () {
            if ($(this).text().search(new RegExp(value, "i")) > -1) {
                $(this).show();
                $('#noresult_cat,.noresult_cat').hide('fast');
//                $('.more-btn').hide();
//                $('.hidedisplay').show();
            } else {
//                console.log("novalue");
                $(this).hide();
                $('#noresult_cat,.noresult_cat').show();
//                $('.more-btn').hide();
            }

        });
    } else {
        $("." + serachid + " li").show();
        $('#noresult_cat,.noresult_cat').hide('fast');
//        $('.hidedisplay').hide();
        $('.more-btn').show();
//        $('.hideshowdiv').show();
    }
    var ullength = $('#scroll_top_id_prod  > li:visible').size();
    if (ullength < 13 || ullength == 0) {
        $('#showmr_scrll_prod ').css('display', 'none'), 300;

    } else {
        $('#showmr_scrll_prod').css('display', 'inline-block'), 300;

    }
    var ullengthmob = $('#scroll_top_id_prod_mbl  > li:visible').size();
    if (ullengthmob < 7 || ullengthmob == 0) {
        $('#showmr_scrll_prod_mbl ').css('display', 'none'), 300;
    } else {
        $('#showmr_scrll_prod_mbl').css('display', 'inline-block'), 300;
    }
    var ullengthserv = $('#scroll_top_id_serv  > li:visible').size();
    if (ullengthserv < 22 || ullengthserv == 0) {
        $('#showmr_scrll_serv ').css('display', 'none'), 300;

    } else {
        $('#showmr_scrll_serv').css('display', 'inline-block'), 300;
    }
    var ullengthservmbl = $('#scroll_top_id_serv_mbl  > li:visible').size();
    if (ullengthservmbl < 7 || ullengthservmbl == 0) {
        $('#showmr_scrll_serv_mbl ').css('display', 'none'), 300;

    } else {
        $('#showmr_scrll_serv_mbl').css('display', 'inline-block'), 300;

    }
}
/// Categories list- search box
//function filtservice_catlist(element, serachid) {
//    var value = $(element).val();
//    var length = $(element).val().length;
////    var prdheight = $(serachid).length();
////    console.log(prdheight);
////    console.log(length);
//    if (length > 0) {
//        $("." + serachid + " li").each(function () {
//            if ($(this).text().search(new RegExp(value, "i")) > -1) {
//                $(this).show();
//                $('#noresult_cat,.noresult_cat').hide('fast');
////                $('.more-btn').hide();
////                $('.hidedisplay').show();
//            } else {
////                console.log("novalue");
//                $(this).hide();
//                $('#noresult_cat,.noresult_cat').show();
////                $('.more-btn').hide();
//            }
//
//        });
//    } else {
//        $("." + serachid + " li").show();
//        $('#noresult_cat,.noresult_cat').hide('fast');
////        $('.hidedisplay').hide();
//        $('.more-btn').show();
////        $('.hideshowdiv').show();
//    }
// var ullength = $('#scroll_top_id_prod > li:visible').length;
//    console.log(ullength);
//        if (ullength < 13 || ullength==0 ) {
////            alert();
// $('#showmr_scrll_prod').css('display', 'none'), 300;
//
//        } else {
//            $('#showmr_scrll_prod').css('display', 'block'), 300;
//
//        }
//}
// GD- Bank, Embassy, Consulates  filter////
function filter_list(element, divid, resid) {
    var value = $(element).val();
    var value1 = '#' + divid;
    var value2 = '#' + resid;
    var count = 0;
//    console.log(value1);
    $(value1).each(function () {

        if ($(this).text().search(new RegExp(value, "i")) > -1) {
            count++;
            if ($(this).hasClass('bank-allone'))
                $(this).show();
            else {
//                console.log($(this).parent().parent());
                $(this).parent().parent().find('div.listli').show();
                $(this).show();
            }
        } else {
            $(this).hide();
//            console.log('er' + $(this).text());
        }
    });
    if (count == 0)
        $(value2).show();
    else
        $(value2).hide('fast');
}
function listFilter(new_ban, allbank) {
    var form = $("<form>").attr({"class": "filterform", "action": "#"}),
            input = $("<input>").attr({"class": "filterinput", "type": "text"});
    $(form).append(input).appendTo(new_ban);
    $(input).change(function () {
        var filter = $(this).val(); // get the value of the input, which we filter on
        if (filter) {
            $(allbank).find("a:contains(" + filter + ")").parent().slideDown();
            $(allbank).find("a:contains(" + filter + ")").parent().slideDown();
        } else {
            $(allbank).find("li").slideDown();
        }
    }).keyup(function () {
        // fire the above change event after every letter
        $(this).change();
    });
    jQuery.expr[':'].Contains = function (a, i, m) {
        return (a.textContent || a.innerText || "").toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
    };
}
/// Press release, Business Classifieds  category filter ///
function filter_presscat(element) {
    var value = $(element).val();
    var length = $(element).val().length;
//    var count = 0;
    if (length > 0) {
        $("#presscat li").each(function () {
            if ($(this).text().search(new RegExp(value, "i")) > -1) {
//            count++;
                $(this).show();
                $('#noresult').hide('fast');
                $('.hideshowdiv').hide();
                $('.hidedisplay').show();
                $('#noresult1, #noresult').css('display', 'none');
            } else {
                $(this).hide();
                $('#noresult').show();
                $('.hideshowdiv').hide();
                $('#noresult1, #noresult').css('display', 'block');

            }


        });
    } else {
//        console.log('no result found');
        $("#presscat li").show();
        $('#noresult').hide('fast');
        $('.hidedisplay').hide();
//        $('.more-btn').show();
        $('.hideshowdiv').show();
//    if (count == 0) {
//        $('.hideshowdiv').hide();
//        $('#noresult, #noresult1').show();
        $('#noresult1').css('display', 'block');
//    } else {
//        $('.hideshowdiv').show('fast');
//        $('#noresult, #noresult1').hide('fast');
//    }
    }
}
/*  billionaires start  */
$("ul.chs-bill li a").click(function () {
    var mainImage = $(this).attr("href"); // Find Image URL
    var imgLink = $(this).children('img').attr('rel'); // Find the image link in rel
    var imgTitle = $(this).children('img').attr('title');
    $("#bill_view").html('<a alt="' + imgLink + '" title="' + imgTitle + '"  class="galleryItemOver" target="_self"><img src="' + mainImage + '" class="galleryThumb img-responsive" title="' + imgTitle + '" alt="' + imgTitle + '" /></a>');
    return false;
});
$('#country').change(function () {
    var s = $("#country :selected").text().toLowerCase();
    s = s.replace("/[^a-zA-Z 0-9-]+/g,").replace(/\s/g, '-');
    p1 = $("#country").val();
    checkcond1 = $('#countrycode').val();
    urllink = $('#urllink').val();
    yearlist = $('#yearlisting').val();
    if (checkcond1 === 'youngest-billionaires') {
        if (p1 === 'all') {
            url = yearlist + "/youngest-billionaires.html";
        } else {
            url = yearlist + "/youngest-billionaires/" + s + ".html";
        }
    } else if (checkcond1 === 'women-billionaires') {
        if (p1 === 'all') {
            url = yearlist + "/women-billionaires.html";
        } else {
            url = yearlist + "/women-billionaires/" + s + ".html";
        }
    } else if (checkcond1 === 'oldest-billionaires') {
        if (p1 === 'all') {
            url = yearlist + "/oldest-billionaires.html";
        } else {
            url = yearlist + "/oldest-billionaires/" + s + ".html";
        }
    } else if (checkcond1 === 'ranking' || checkcond1 !== '') {
        if (p1 === 'all') {
            url = yearlist + "/ranking.html";
        } else {
            if (yearlist !== '') {
                url = yearlist + "/" + s + ".html";
            } else {
                url = yearlist + "/ranking.html";
            }
        }
    }
    url = urllink + url;
//        console.log(url);
    window.location = url;
});
function filter(element) {
    var value = $(element).val();
    $("#terms li").each(function () {
        if ($(this).text().search(new RegExp(value, "i")) > -1) {
            $(this).show();
        } else {
            $(this).hide();
        }
    });
}
/**** Modal Form Component ****/
$('#formpost_data, #formpost_data2').click(function () {
    targetUrl = '?form=addform';
    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
    $('#formModel').modal('show');
    return false;
});
///// detail page feedback options in GD ////
$('#feedbackedit').click(function () {
    targetUrl = '?form=editform';
    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
    $('#editdata').modal('show');
});
///// contact button in coremodules ///
$('#directory_inquiry').click(function () {
    targetUrl = '?form=directoryinquiry';
    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
    $('#directoryInquiryModal').modal('show');
    return false;
});
/************* Ecommerce ************/
/////// ecomm- delivery charge request ///
$('#formpost_reuest').click(function () {
    targetUrl = '?form=reuestform';
    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
    $('#addreuestform_modal').modal('show');
    var pin = $('#pincodeTxtBox').val();
    var ship_addr = $('#tmPincode').val();
    $('#ship_pin').val(ship_addr);
    if (typeof pin != 'undefined') {
        var sendpincode = $('#sendpincode').val(pin);
    }
});
//$('#reviewedit').click(function () {
//    targetUrl = '?form=editform';
//    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
//    $('#editdata').modal('show');
//});
/// profile -ewallet
$('#search_ewallet').click(function () {
    targetUrl = '#ewallet';
    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
//    $('#editdata').modal('show');
});
//$('#formpost_buynow').click(function () {
//    targetUrl = '?buynow';
//    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
//    $('#formBuynow').modal('show');
//});
/// buy now //
$('#formpost_buynow').click(function () {
    var pin = $('#pincodeTxtBox').val();
    var del_chg = $('#delivery_charge').val();
    if (pin == '' && del_chg == 0)
    {
        $('#picodeErrDiv').html('Enter Valid Pincode');
        $('#pincodeTxtBox').focus();
        $('#pincodeTxtBox').select();
    } else {
        if (pin != '' && del_chg == 0)
        {
            $('#picodeErrDiv').html('Enter Valid Pincode');
            $('#pincodeTxtBox').focus();
            $('#pincodeTxtBox').select();
        } else {
            targetUrl = '?buynow';
            window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
            $('#formBuynow').modal('show');
        }
    }
});
/*** Remove query string on modal close *****/
$('body').on('hidden.bs.modal', function () {
    var href = window.location.href;
    var url = href.split('?form=');
    if (location.href.split("?")[0] != URL_PROFILE_PATH + 'delivery-requests' && location.href.split("?")[0] != URL_PROFILE_PATH + 'ecommerce/orders')
        history.pushState(null, null, location.href.split("?")[0]);
});
function changeimage(id) {
    $('#myFile').click();
}
function changestoryimage(id) {
    $('#' + id).click();
}
// gallery fancybox fr quotes

//$('document').ready(function () {
//    $('.fancybox-buttons').fancybox({
//        openEffect: 'none',
//        closeEffect: 'none',
//        prevEffect: 'none',
//        nextEffect: 'none',
//        closeBtn: true,
//        helpers: {
//            title: {
//                type: 'inside'
//            },
//            buttons: {}
//        },
//        afterLoad: function () {
//            this.title = 'image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
//        }
//    });
//});

$(document).ready(function (e) {
    $(document).on('click', '.xhrModal', function (e) {
        openAjaxModel($(this), e);
    });
    $(document).on('click', '.inquiryModal', function (e) {
//e.preventDefault();
        openAjaxInquiryModel($(this), e);
    });
    $(document).on('click', '.complaintModal', function (e) {
//e.preventDefault();
        openAjaxComplaintModel($(this), e);
    });
    $(document).on('click', '.ratingModal', function (e) {
        openAjaxRatingModel($(this), e);
    });
    $(document).on('click', '.bannerModal', function (e) {
        openAjaxBannerModel($(this), e);
    });
});
$(function () {
    if (window.location.href.indexOf('?form=editform') !== -1) {
        $('#editdata').modal('show');
    }
    if (window.location.href.indexOf('?form=addform') !== -1) {
        $('#formModel').modal('show');
    }

    if (window.location.href.indexOf('?form=reuestform') !== -1) {
        $('#addreuestform_modal').modal('show');
    }
    if (window.location.href.indexOf('?form=directoryinquiry') !== -1) {
        $('#directoryInquiryModal').modal('show');
    }
    if (window.location.href.indexOf('?buynow') !== -1) {
        $('#formBuynow').modal('show');
    }

    if (window.location.href.indexOf('?login') !== -1) {
        openAjaxModel($('*[data-symlink="login"]'), null);
    }
    if (window.location.href.indexOf('?signup') !== -1) {
        openAjaxModel($('*[data-symlink="signup"]'), null);
    }
    if (window.location.href.indexOf('?forgot') !== -1) {
        openAjaxModel($('*[data-symlink="forgot"]'), null);
    }
    if (window.location.href.indexOf('?inquiry') !== -1) {

        var id = getParameterByName('id');
        openAjaxInquiryModel($('.inquiryModal[data-entity="' + id + '"]'), null);
    }
    if (window.location.href.indexOf('?complaint') !== -1) {

        openAjaxComplaintModel($('*[data-symlink="complaint"]'), null);
    }

    if (window.location.href.indexOf('?review') !== -1) {

        openAjaxRatingModel($('*[data-symlink="review"]'), null);
    }
    if (window.location.href.indexOf('?addbanner') !== -1) {

        openAjaxBannerModel($('*[data-symlink="addbanner"]'), null);
    }
});
function openAjaxModel(element, e) {
    if (APP_HTTP_SCHEME + '://' + document.domain == URL_LOGIN_PATH) {
        return false;
    }
    var $modal = $('#testM');
    $('.modal-backdrop').remove();
    $(".modal-backdrop").fadeIn(1000, function () {
        element.remove();
    });
    $modal.removeData('bs.modal');
    if (e !== null) {
        e.preventDefault();
    }
    $modal.find(".modal-body").html('<p style="color:white;"> Loading... </p>');
    var url = element.data('href');
    var symUrl = element.data('symlink');
    var adnum = element.data('adnum');
    var divid = element.data('divid');
    if (typeof symUrl != 'undefined') {
        window.history.pushState({url: '?' + symUrl}, '', '?' + symUrl);
    }
    $.ajax({
        type: 'GET',
        url: url,
        dataType: 'jsonp',
        crossDomain: true
    }).done(function (response) {
        $modal.find(".modal-body").html(response[0]);
        if (typeof adnum != 'undefined') {
            $modal.find(".book_banner").val(adnum);
            $modal.find(".bannerid").val(divid);
        }
        $modal.modal('show');
    }).fail(function (error) {
//        console.log(error.statusText);
    });
}

function openAjaxInquiryModel(element, e) {
//  console.log(element);

    var $modal = $('#InquiryModal');
    $('.modal-backdrop').remove();
    $(".modal-backdrop").fadeIn(1000, function () {
        element.remove();
    });
    $modal.removeData('bs.modal');
    $itemName = $('.itemname').html();
    $attrsVal = $(element).data('entities');
    if (e !== null) {
        e.preventDefault();
    }

    $modal.find(".modal-body").html('<p style="color:white;"> Loading... </p>');
    var url = element.data('href');
    var entity_id = element.data('entity');
    var module_id = element.data('module');
    var symUrl = 'inquiry' + '&id=' + element.data('entity');
    var paginationNumber = getParameterByName('page');
    if (isInt(paginationNumber)) {
        var paginationParam = '&page=' + paginationNumber;
    } else {
        var paginationParam = '';
    }
//    console.log(element);
    window.history.pushState({url: '?' + symUrl}, '', '?' + symUrl + paginationParam);
    $.ajax({
        type: 'GET',
        url: url,
        data: {entity_id: entity_id, module_id: module_id},
        dataType: 'jsonp',
        crossDomain: true,
    }).done(function (response) {
// console.log(response);
        $modal.find(".modal-body").html(response[0]);
        $modal.modal('show');
        // $(".itemname").clone().appendTo($(".itemName"));
//        if (typeof $(".itemimage").find('img:first').attr('src') != 'undefined') {
//            $('.product_name').hide();
//          //  $(".itemimage").find('img:first').clone().appendTo("#itemImage");
//
//        } else {
//            $('.product_details').hide();
//            $('.formcontainer').addClass('col-lg-12 col-sm-12 col-xs-12');
//            $('.inquiry-wrap .modal-dialog').css({'width': '400px'});
////                $('.inquiry-wrap').addClass('nonimage-wrap');
//        }

        $(".entities").val(JSON.stringify($attrsVal));
        if ($('#contactenquiryimg').length) {
            $('#InquiryModal .modal-dialog').css({
                width: 400
            });
        } else {
            $('#InquiryModal .modal-dialog').css({
                width: 800
            });
        }
    }).fail(function (error) {
//        console.log(error.statusText);
    });
}
function openAjaxComplaintModel(element, e) {
//  console.log(element);

    var $modal = $('#ComplaintModal');
    $('.modal-backdrop').remove();
    $(".modal-backdrop").fadeIn(1000, function () {
        element.remove();
    });
    $modal.removeData('bs.modal');
    if (e !== null) {
        e.preventDefault();
    }
    $modal.find(".modal-body").html('<p style="color:white;"> Loading... </p>');
    var url = element.data('href');
    var entity_id = element.data('entity');
    //alert(entity_id);
    // var suspicious = element.data('entityname');
    //console.log('==' + suspicious);
    // var module_id = element.data('module');
    // var entity_name = element.data('entityname');
    var symUrl = element.data('symlink');
    //  var receiverid = element.data('receiverid');
    window.history.pushState({url: '?' + symUrl}, '', '?' + symUrl);
    $.ajax({
        type: 'GET',
        url: url,
        data: {entity_id: entity_id},
        dataType: 'jsonp',
        crossDomain: true,
    }).done(function (response) {
        $modal.find(".modal-body").html(response[0]);
        $modal.modal('show');
    }).fail(function (error) {
//        console.log(error.statusText);
    });
}
function isInt(value) {
    var x;
    return isNaN(value) ? !1 : (x = parseFloat(value), (0 | x) === x);
}

function openAjaxRatingModel(element, e) {

    var $modal = $('#ratingModelID');
    $('.modal-backdrop').remove();
    $(".modal-backdrop").fadeIn(1000, function () {
        element.remove();
    });
    $modal.removeData('bs.modal');
    if (e !== null) {
        e.preventDefault();
    }

    $modal.find(".modal-body").html('<p style="color:white;"> Loading... </p>');
    var url = element.data('href');
    var entity_id = element.data('entity');
    var module_id = element.data('module');
    var entity_name = element.data('entityname');
    var symUrl = element.data('symlink');
    var receiverid = element.data('receiverid');
    window.history.pushState({url: '?' + symUrl}, '', '?' + symUrl);
    $.ajax({
        type: 'GET',
        url: url,
        data: {entity_id: entity_id, entity_name: entity_name, module_id: module_id, receiver_id: receiverid},
        dataType: 'jsonp',
        crossDomain: true,
    }).done(function (response) {
        $modal.find(".modal-body").html(response[0]);
        $modal.modal('show');
    }).fail(function (error) {
//        console.log(error.statusText);
    });
}
function openAjaxBannerModel(element, e) {

    var $modal = $('#adbannerModelID');
    $('.modal-backdrop').remove();
    $(".modal-backdrop").fadeIn(1000, function () {
        element.remove();
    });
    $modal.removeData('bs.modal');
    if (e !== null) {
        e.preventDefault();
    }
    $modal.find(".modal-body").html('<p style="color:white;"> Loading... </p>');
    var url = element.data('href');
    var entity_id = element.data('entity');
    var module_id = element.data('module');
    var entity_name = element.data('entityname');
    var symUrl = element.data('symlink');
    var receiverid = element.data('receiverid');
    window.history.pushState({url: '?' + symUrl}, '', '?' + symUrl);
    $.ajax({
        type: 'GET',
        url: url,
        data: {entity_id: entity_id, entity_name: entity_name, module_id: module_id, receiver_id: receiverid},
        dataType: 'jsonp',
        crossDomain: true,
    }).done(function (response) {
        $modal.find(".modal-body").html(response[0]);
        $modal.modal('show');
    }).fail(function (error) {
//        console.log(error.statusText);
    });
}

/*
 * inquiry common modal
 */
//$(document).ready(function (e) {
//    var $modal = $('#testM');
//    $(document).on('click', '.inquiryModal', function (e) {
//        $(".modal-backdrop").fadeIn(600, function () {
//            $(this).remove();
//        });
//        $modal.removeData('bs.modal');
//        e.preventDefault();
//        $itemName = $('.itemname').html();
//        $attrsVal = $(this).data('entities');
//        //console.log(JSON.stringify($attrsVal));
//
//        $modal.find(".modal-body").html('<p style="color:white;"> Loading... </p>');
//        $.ajax({
//            type: 'GET',
//            url: $(this).data('href'),
//            dataType: 'jsonp',
//            crossDomain: true,
//        }).done(function (response) {
//
//            $modal.find(".modal-body").html(response[0]);
//            $modal.modal('show');
//            $(".itemname").clone().appendTo($(".itemName"));
//
//            if (typeof $(".itemimage").find('img:first').attr('src') != 'undefined') {
//                $('.product_name').hide();
//                $(".itemimage").find('img:first').clone().appendTo("#itemImage");
//
//            } else {
//                $('.product_details').hide();
//                $('.formcontainer').addClass('col-lg-12 col-sm-12 col-xs-12');
//                $('.inquiry-wrap .modal-dialog').css({'width': '400px'});
////                $('.inquiry-wrap').addClass('nonimage-wrap');
//            }
//
//            $(".entities").val(JSON.stringify($attrsVal));
//        }).fail(function (error) {
//            console.log(error.statusText);
//        });
//    });
//});
//contactus-new

$(function () {

//    $('.map-wrap').click(function () {
//        $('.map-wrap iframe').css({'pointer-events': 'auto'});
//    });
//    $('.map-wrap').mouseleave(function () {
//        $('.map-wrap iframe').css({'pointer-events': 'none'});
//    });

// chatbox contactus - (hidden in viewpage)
    $('.live-chat-open').click(function () {
        $('.live-chat-open-wrap').addClass('bounceInUp').show();
        $('.live-chat-open-wrap').removeClass('bounceOutDown');
        $('.live-chat-open').addClass('bounceOutDown').hide();
        $('.live-chat-open').removeClass('bounceInUp');
    });
    $('.live-chat-close').click(function () {
        $('.live-chat-open-wrap').removeClass('bounceInUp');
        $('.live-chat-open').removeClass('bounceOutDown');
        $('.live-chat-open-wrap').addClass('bounceOutDown').hide();
        $('.live-chat-open').addClass('bounceInUp').show();
    });
});
var substringMatcher = function (strs) {
    return function findMatches(q, cb) {
        var matches, substringRegex;
        // an array that will be populated with substring matches
        matches = [];
        // regex used to determine if a string contains the substring `q`
        substrRegex = new RegExp(q, 'i');
        // iterate through the pool of strings and for any string that
        // contains the substring `q`, add it to the `matches` array
        $.each(strs, function (i, str) {
            if (substrRegex.test(str)) {
                matches.push(str);
            }
        });
        cb(matches);
    };
};
//script for show more

//quotes mobilesize menu
$(document).ready(function () {
    $('.scrollquotes').click(function () {
        var hre = $(this).attr('href');
        var scroll = $(hre).offset().top;
        $('html,body').animate({
            scrollTop: scroll
        });
    });
    $(".bl-category h2").click(function () {
        $(".bl-category ul").toggleClass('letter-accordion', 1000);
        $(".letter-accord").toggleClass('letter-accord-down', 1000);
    });
    $(".mbl-se-heading").click(function () {
        $(".ser-categ ul").toggleClass('letter-accordion', 1000);
        $(".letter-accord").toggleClass('letter-accord-down', 1000);
    });
    $("#carousel-a").carousel({interval: 10000});
//    ---------------cart----------
//    $('.c-quantity input').keypress(function () {
//        $(this).parent().children('.cart-save').css({"opacity": "1"});
//    });
//    $('.c-quantity span').click(function () {
//        $(this).parent().children('.cart-save').css({"opacity": "1"});
//    });
//
    //$(".cart-popup").click(function () {
//        $(".cart-fixed").fadeIn();
//        setTimeout(function () {
//            $(".cart-fixed").fadeOut();
//        }, 5000);
    //});

});
//--------------- header cart show & hidden ----------------------//
function cart_fixed_close() {
    $('.cart-fixed').fadeOut();
}
//----------------Advertise--------------
function ad_close() {
    $('.banner-type-descrp').fadeOut();
}

//$(function () {
//    $('.email_whole').click(function () {
//        $('.cont_mail').fadeOut();
//        $('.email_whole').css({"display": "none"});
//    });
//});

var sanitize = function (name) {
    name = name.replace(/\s+/gi, '-'); // Replace white space with dash
    return name.replace(/[^a-zA-Z0-9\-]/gi, ''); // Strip any special charactere
};
var photo_counter = 0;
Dropzone.autoDiscover = false;
var fileList = new Array;
var fileListImage = new Array;
var i = 0;
var maxfile = $('#maxfile').val();
var acceptfile = $('#acceptfile').val();
if (maxfile != '' || maxfile != 0) {
    maxfilesize = maxfile;
} else {
    maxfilesize = 8;
}
if ($('#acceptfile').length > 0) {
    acceptval = acceptfile;
//  console.log(acceptfile);

} else {
    acceptval = 'image/jpg,image/jpeg';
}
/**** for brochure ****/
var maxsizebroch = 2;
var maxfilebroch = $('#maxfilebroch').val();
var acceptfilebroch = $('#acceptbroch').val();
if (maxfilebroch != '' || maxfilebroch != 0) {
    maxsizebroch = maxfilebroch;
}
if (acceptfilebroch != '') {
    acceptvalbroch = acceptfilebroch;
} else {
    acceptfilebroch = 'image/*,.doc,.docx,.txt,.application/pdf';
}

//------------ basic flow - company logo uploader ---------------//
if ($('#complogo_dZUpload').length) {
//    console.log('hi');
    var myDropzoneTheFirst = new Dropzone("#complogo_dZUpload", {
        url: "/uploadhandler/logo-upload",
        uploadMultiple: false,
        parallelUploads: 100,
        maxFilesize: 1,
        addRemoveLinks: true,
        dictRemoveFile: '',
//        clickable: false,
        dictRemoveFileConfirmation: 'Are you sure want to delete this',
        dictFileTooBig: "You can't upload image above 1 mb size",
        dictCancelUploadConfirmation: "Uploading process ongoing, are you sure you want to cancel this upload?",
        dictResponseError: 'Uploading on progress.Changes may not to be saved! ',
        maxFiles: 1,
        acceptedFiles: acceptval,
        dictInvalidFileType: 'You can only upload jpg and jpeg files',
        dictMaxFilesExceeded: 'You can upload only 1 image',
        accept: function (file, done) {
            if (this.files.length > 1) {
                this.removeFile(this.files[0]);
            }
            done();
        },
        init: function () {
            /***
             * Retrive Old files
             */

            thisDropzone = this;
//            var submitButton = document.querySelector("#complogo_dZUpload");
            $.getJSON('/uploadhandler/getuploadefiles', function (data) {
                var existingFileCount = data.length;
                thisDropzone.options.maxFiles = thisDropzone.options.maxFiles - existingFileCount;
                $.each(data, function (i, val) {
//                    console.log(val);
                    var fileName = val.name.replace(/^.*[\\\/]/, '');
                    fileListImage[i] = {'serverFileName': val.name, 'fileName': fileName, 'fileId': i};
                    var mockFile = {name: fileName, size: val.size};
                    //var mockFile = {name: fileName};
                    thisDropzone.emit("addedfile", mockFile);
                    thisDropzone.createThumbnailFromUrl(mockFile, URL_UPLOADS_PATH + '/' + val.name, null, true);
                    thisDropzone.emit("complete", mockFile);
                    thisDropzone.files.push(mockFile);
                });
            });
            this.on("sending", function (file, xhr, data) {
                data.append("module_name", $('#module_name').val());
            });
            this.on("sending", function (file, xhr, data) {
                data.append("company_name", $('#company_name').val());
            });
            this.on('error', function (file, response) {
                // alert("You can't upload image with above 5 mb size");
                // (assuming your response object has an errorMessage property...)
                var errorMessage = response.errorMessage;
                $(file.previewElement).find('.dz-error-message').text(errorMessage);
            });
            /***
             * File Removal
             */
            this.on("removedfile", function (file) {

                var rmvFile = "";
                $.each(fileListImage, function (index, value) {

                    if (typeof value !== 'undefined') {
                        if (value.fileName == file.name) {
                            rmvFile = value.serverFileName;
                        }
                    }
                });
                if (rmvFile) {
                    var modname = $('#module_name').val();
                    var editid = $('#editid').val();
                    $.ajax({
                        type: 'POST',
                        url: '/uploadhandler/delete',
                        data: {'fileList': rmvFile, module_name: modname, editid: editid},
                        dataType: 'html',
                        success: function (data) {
                            var rep = JSON.parse(data);
                            if (rep.code == 200) {
                                photo_counter--;
//                                var count = myDropzoneTheFirst.files.length;
//                                alert(count);
                            }
                        }
                    });
                }
            });
            /**** File Added ***/
            this.on('addedfile', function (file) {
                var img = $(file.previewTemplate).find("img");
                img[0].onload = function () {
                    var max = this.width > this.height ? this.width : this.height;
                    var ratio = 100.0 / max;
                    var width = this.width * ratio;
                    var height = this.height * ratio;
                    img.css({
                        width: width + "px",
                        height: height + "px",
                        top: ((100 - height) / 2) + "px",
                        left: ((100 - width) / 2) + "px"
                    });
                };
                this.accept = function (file, done) {

                    // custom duplicate check
                    if (this.files.length) {
                        var _i, _len;
                        var isDuplicate = false;
                        for (_i = 0, _len = this.files.length - 1; _i < _len; _i++) {
                            if (this.files[_i].name === file.name || this.files[_i].name === sanitize(file.name)) {
                                isDuplicate = true;
                                this.removeFile(file);
                                return false;
                            }
                        }
                    }

                    // default dropzone checks
                    if (file.size > this.options.maxFilesize * 1024 * 1024) {
                        return done(this.options.dictFileTooBig.replace("{[{filesize}]}", Math.round(file.size / 1024 / 10.24) / 100).
                                replace("{[{maxFilesize}]}", this.options.maxFilesize));
                    } else if (!Dropzone.isValidFile(file, this.options.acceptedFiles)) {
                        return done(this.options.dictInvalidFileType);
                    } else if ((this.options.maxFiles != null) && this.files.length >= maxsizebroch) {
                        done(this.options.dictMaxFilesExceeded.replace("{[{maxFiles}]}", this.options.maxFiles));
                        return this.emit("maxfilesexceeded", file);
                    } else if (isDuplicate === true) {
                        // output my error string for duplicates
                        return done(this.options.dictDuplicate);
                    } else {
//                        file.previewElement.classList.add("dz-success");
//                        submitButton.setAttribute("clickable", "false");
                        return this.options.accept.call(this, file, done);
                    }
                };

            });
            this.on("maxfilesexceeded", function (file) {
                this.removeFile(file);
            });
            /***
             * On Upload Success
             */

            this.on("success", function (file, serverFileName) {
//                Dropzone("#complogo_dZUpload", {
//                    clickable: false
//                });
//                file.previewElement.classList.add("dz-success");
//                submitButton.setAttribute("clickable", "false");
                console.log(serverFileName);
                fileListImage[i] = {'serverFileName': serverFileName, 'fileName': file.name, 'fileId': i};
                i++;
//            $("#photoCounter").text("(" + i + ")");
            });
        }
    });
}

/**** set limit for upload image ****/

var maximg_choosen = 5;
var img_maxfile = $('#img_maxfile').val();
if (img_maxfile != '' || img_maxfile != 0) {
    maximg_choosen = img_maxfile;
}
//------------ Image uploader ---------------//
if ($('#dZUpload').length) {
    $('.dropzone>.dz-preview>.dz-remove').hide();
    var myDropzoneTheFirst = new Dropzone("#dZUpload", {
        url: "/uploadhandler/upload",
        uploadMultiple: false,
        parallelUploads: 100,
        maxFilesize: 3,
        addRemoveLinks: true,
        dictCancelUpload: null,
        dictRemoveFile: '',
        dictRemoveFileConfirmation: 'Are you sure want to delete this',
        dictFileTooBig: "You can't upload image above 3 mb size",
        dictCancelUploadConfirmation: "Uploading process ongoing, are you sure you want to cancel this upload?",
        dictResponseError: 'Uploading on progress.Changes may not to be saved! ',
        maxFiles: maximg_choosen,
        acceptedFiles: acceptval,
        dictInvalidFileType: 'You can only upload jpg and jpeg files',
        dictMaxFilesExceeded: 'You can upload upto ' + maximg_choosen + ' images only',
        init: function () {
            /***
             * Retrive Old files
             */
            thisDropzone = this;
            $.getJSON('/uploadhandler/getuploadefiles', function (data) {
                var existingFileCount = data.length;
                thisDropzone.options.maxFiles = thisDropzone.options.maxFiles - existingFileCount;
                $.each(data, function (i, val) {
                    var fileName = val.name.replace(/^.*[\\\/]/, '');
                    fileListImage[i] = {'serverFileName': val.name, 'fileName': fileName, 'fileId': i};
                    var mockFile = {name: fileName, size: val.size};
                    //var mockFile = {name: fileName};
                    thisDropzone.emit("addedfile", mockFile);
                    thisDropzone.createThumbnailFromUrl(mockFile, URL_UPLOADS_PATH + '/' + val.name, null, true);
                    thisDropzone.emit("complete", mockFile);
                    thisDropzone.files.push(mockFile);
                });
            });
            this.on("sending", function (file, xhr, data) {
                $(".dzimgprocess").prop("disabled", true);
                $(".dz-remove").css("display", "none");
                data.append("module_name", $('#module_name').val());
            });
            this.on("sending", function (file, xhr, data) {
                $(".dzimgprocess").prop("disabled", true);
                $(".dz-remove").css("display", "none");
                data.append("product_name", $('#product_name').val());
            });
            this.on("sending", function (file, xhr, data) {
                $(".dzimgprocess").prop("disabled", true);
                $(".dz-remove").css("display", "none");
                data.append("servicename", $('#servicename').val());
            });
            this.on("sending", function (file, xhr, data) {
                $(".dzimgprocess").prop("disabled", true);
                $(".dz-remove").css("display", "none");
                data.append("company_name", $('#company_name').val());
            });
            this.on('error', function (file, response) {
                // console.log('heellloo');
                // alert("You can't upload image with above 5 mb size");
                // (assuming your response object has an errorMessage property...)
                var errorMessage = response.errorMessage;
                $(file.previewElement).find('.dz-error-message').text(errorMessage);
            });
            /***
             * File Removal
             */
            this.on("removedfile", function (file) {
                var rmvFile = "";
                $.each(fileListImage, function (index, value) {
                    if (typeof value !== 'undefined') {
                        if (value.fileName == file.name) {
                            rmvFile = value.serverFileName;
                        }
                    }
                });
                if (rmvFile) {
                    var modname = $('#module_name').val();
                    var editid = $('#editid').val();
                    $.ajax({
                        type: 'POST',
                        url: '/uploadhandler/delete',
                        data: {'fileList': rmvFile, module_name: modname, editid: editid},
                        dataType: 'html',
                        success: function (data) {
                            var rep = JSON.parse(data);
                            if (rep.code == 200) {
                                photo_counter--;
                            }
                        }
                    });
                }
            });

            /**** File Added ***/
            this.on('addedfile', function (file) {
                var img = $(file.previewTemplate).find("img");
                img[0].onload = function () {
                    var max = this.width > this.height ? this.width : this.height;
                    var ratio = 100.0 / max;
                    var width = this.width * ratio;
                    var height = this.height * ratio;
                    img.css({
                        width: width + "px",
                        height: height + "px",
                        top: ((100 - height) / 2) + "px",
                        left: ((100 - width) / 2) + "px"
                    });
                };
                this.accept = function (file, done) {

                    // custom duplicate check
                    if (this.files.length) {
                        var _i, _len;
                        var isDuplicate = false;
                        for (_i = 0, _len = this.files.length - 1; _i < _len; _i++) {
                            if (this.files[_i].name === file.name || this.files[_i].name === sanitize(file.name)) {
                                isDuplicate = true;
                                this.removeFile(file);
                                return false;
                            }
                        }
                    }
//                    alert(this.options.maxFiles + '==' + this.getAcceptedFiles().length + '==' + this.options.maxFiles);
                    // default dropzone checks
                    if (file.size > this.options.maxFilesize * 1024 * 1024) {
                        return done(this.options.dictFileTooBig.replace("{[{filesize}]}", Math.round(file.size / 1024 / 10.24) / 100).
                                replace("{[{maxFilesize}]}", this.options.maxFilesize));
                    } else if (!Dropzone.isValidFile(file, this.options.acceptedFiles)) {
                        return done(this.options.dictInvalidFileType);
                    } else if ((this.options.maxFiles != null) && (this.files.length > maximg_choosen)) {
                        alert('Sorry, you can upload only ' + maximg_choosen + ' images');
                       // done(this.options.dictMaxFilesExceeded.replace("{[{maxFiles}]}", this.options.maxFiles));
                        return this.emit("maxfilesexceeded", file);
                        
                    } else if (isDuplicate === true) {
                        return done(this.options.dictDuplicate);
                    } else {
                        return this.options.accept.call(this, file, done);
                    }
                };

            });
            this.on("maxfilesexceeded", function (file) {
                this.removeFile(file);
            });
            /***
             * On Upload Success
             */
            this.on("queuecomplete", function (file, serverFileName) {
                $(".dzimgprocess").prop("disabled", false);
                $(".dz-remove").css("display", "block");
            });
            this.on("success", function (file, serverFileName) {
                //console.log(serverFileName);
//                $('.dropzone>.dz-preview>.dz-remove').show();
                fileListImage[i] = {'serverFileName': serverFileName, 'fileName': file.name, 'fileId': i};
                i++;
//            $("#photoCounter").text("(" + i + ")");
            });
        }

    });
}

if ($('#dZUploadBro').length > 0) {
    var myDropzone1 = new Dropzone("#dZUploadBro", {
        url: "/uploadhandler/uploadbrochure",
        uploadMultiple: false,
        parallelUploads: 100,
        maxFilesize: 3,
        addRemoveLinks: true,
        dictRemoveFile: '',
        dictRemoveFileConfirmation: 'Are you sure want to delete this',
        dictFileTooBig: 'Broucher is bigger than 3MB',
        maxFiles: maxsizebroch,
        acceptedFiles: acceptfilebroch,
        dictInvalidFileType: 'You can only upload ' + acceptfilebroch + ' files',
        dictMaxFilesExceeded: 'You can upload upto ' + maxsizebroch + ' images only',
        init: function () {
            /***
             * Retrive Old files
             */
            brochureDropzone = this;
            $.getJSON('/uploadhandler/getuploadebrochures', function (data) {
                var existingFileCount = data.length;
                brochureDropzone.options.maxFiles = brochureDropzone.options.maxFiles - existingFileCount;
                $.each(data, function (i, val) {
//                    console.log(i);
//                    console.log(val);
                    var fileName = val.name.replace(/^.*[\\\/]/, '')
                    fileList[i] = {'serverFileName': val.name, 'fileName': fileName, 'fileId': i};
//                    console.log(fileName);
                    var mockFile = {name: fileName, size: val.size};
                    brochureDropzone.emit("addedfile", mockFile);
                    var ext = val.name.split('.').pop();
                    var iconPath;
                    if (ext == 'txt') {
                        iconPath = URL_CDN_PATH + '/assets/img/icons/txt.png';
                    } else if (ext == 'pdf') {
                        iconPath = URL_CDN_PATH + '/assets/img/icons/pdf.png';
                    } else if (ext == 'doc' || ext == 'docx') {
                        iconPath = URL_CDN_PATH + '/assets/img/icons/doc.png';
                    } else {
                        iconPath = URL_UPLOADS_PATH + '/' + val.name;
                    }
                    brochureDropzone.createThumbnailFromUrl(mockFile, iconPath, null, true);
                    brochureDropzone.emit("complete", mockFile);
                    brochureDropzone.files.push(mockFile);
                });
            });
            this.on("sending", function (file, xhr, data) {
                $(".dzimgprocess").prop("disabled", true);
                $(".dz-remove").css("display", "none");
                data.append("module_name", $('#module_name').val());
            });
            this.on('error', function (file, response) {

                // console.log('heellloo');
                // alert("You can't upload image with above 5 mb size");
                // (assuming your response object has an errorMessage property...)
                var errorMessage = response.errorMessage;
                $(file.previewElement).find('.dz-error-message').text(errorMessage);
            });
            /***
             * File Removal
             */
            this.on("removedfile", function (file) {
                var rmvFile = "";
                $.each(fileList, function (index, value) {
                    if (typeof value !== 'undefined') {
                        if (value.fileName == file.name) {
                            rmvFile = value.serverFileName;
//                            console.log(rmvFile);
                        }
                    }
                });
                if (rmvFile) {
                    var modname = $('#module_name').val();
                    $.ajax({
                        type: 'POST',
                        url: '/uploadhandler/delete',
                        data: {'fileList': rmvFile, module_name: modname},
                        dataType: 'html',
                        success: function (data) {
                            var rep = JSON.parse(data);
                            if (rep.code == 200) {
                                photo_counter--;
                            }
                        }
                    });
                }
            });
            /**** File Added ****/
            this.on('addedfile', function (file) {
                var ext = file.name.split('.').pop();
                var iconPath;
                if (ext == 'txt') {
                    iconPath = URL_CDN_PATH + '/assets/img/icons/txt.png';
                } else if (ext == 'pdf') {
                    iconPath = URL_CDN_PATH + '/assets/img/icons/pdf.png';
                } else if (ext == 'doc' || ext == 'docx') {
                    iconPath = URL_CDN_PATH + '/assets/img/icons/doc.png';
                } else {
                    iconPath = '';
                }

                var img = $(file.previewTemplate).find("img");
                if (ext == 'txt' || ext == 'pdf' || ext == 'doc' || ext == 'docx') {
                    var img11 = $(img[0]);
                    img11.attr('src', iconPath);
                }

                img[0].onload = function () {

                    var max = this.width > this.height ? this.width : this.height;
                    var ratio = 100.0 / max;
                    var width = this.width * ratio;
                    var height = this.height * ratio;
                    img.css({
                        width: width + "px",
                        height: height + "px",
                        currentSrc: iconPath,
                        top: ((100 - height) / 2) + "px",
                        left: ((100 - width) / 2) + "px"
                    });
                };
                this.accept = function (file, done) {
                    // custom duplicate check
                    if (this.files.length) {
                        var _i, _len;
                        var isDuplicate = false;
                        for (_i = 0, _len = this.files.length - 1; _i < _len; _i++) {
                            if (this.files[_i].name === file.name || this.files[_i].name === sanitize(file.name)) {
                                isDuplicate = true;
                                this.removeFile(file);
                                return false;
                            }
                        }
                    }
                    if (file.size > this.options.maxFilesize * 1024 * 1024) {
                        return done(this.options.dictFileTooBig.replace("{[{filesize}]}", Math.round(file.size / 1024 / 10.24) / 100).
                                replace("{[{maxFilesize}]}", this.options.maxFilesize));
                    } else if (!Dropzone.isValidFile(file, this.options.acceptedFiles)) {
                        return done(this.options.dictInvalidFileType);
                    } else if ((this.options.maxFiles != null) && (this.files.length > maxsizebroch)) {
                        alert('Sorry, you can upload only ' + maxsizebroch + ' brochures');
                        done(this.options.dictMaxFilesExceeded.replace("{[{maxFiles}]}", this.options.maxFiles));
                        return this.emit("maxfilesexceeded", file);
                    } else if (isDuplicate === true) {
                        // output my error string for duplicates
                        return done(this.options.dictDuplicate);
                    } else {
                        return this.options.accept.call(this, file, done);
                    }
                }
            });
            this.on("maxfilesexceeded", function (file) {
                this.removeFile(file);
            });
            /***
             * On Upload Success
             */
            this.on("queuecomplete", function (file, serverFileName) {
                $(".dzimgprocess").prop("disabled", false);
                $(".dz-remove").css("display", "block");
            });
            this.on("success", function (file, serverFileName) {
//                console.log("sucess");
                fileList[i] = {'serverFileName': serverFileName, 'fileName': file.name, 'fileId': i};
                i++;
            });
        }
    });
}
;
//***** hotnews ***********//
//$(function () {
//    $(".submenu").mouseenter(function () {
//        $(this).next(".dropdown-listmenu").show();
//        $(this).find(".news-drpdwn").show();
//    });
//    $(".submenu").mouseleave(function () {
//        $(this).next(".dropdown-listmenu").hide();
//        $(this).find(".news-drpdwn").hide();
//    });
//    $(".dropdown-listmenu,.news-drpdwn2").mouseenter(function () {
//        $(this).show();
//    });
//    $(".dropdown-listmenu,.news-drpdwn2").mouseleave(function () {
//        $(this).hide();
//    });
//});


// hotnews Dropdown Menu Fade
//jQuery(document).ready(function () {
//    $(".dropdown-mn").hover(
//            function () {
//                $('.dropdown-menu-news', this).stop().fadeIn("fast");
//            },
//            function () {
//                $('.dropdown-menu-news', this).stop().fadeOut("fast");
//            });
//});
//privacy-policy//
$(function () {
    $(".pp-list nav ul li a").click(function () {
        $(this).parent().prevAll('li').find('ul').hide();
        $(this).parent().prevAll('li').find('i').removeClass('ani');
        $(this).parent().nextAll('li').find('ul').hide();
        $(this).parent().nextAll('li').find('i').removeClass('ani');
        $(this).find("i").toggleClass("ani");
        $(this).next("ul").toggle();
    });
});
//buyers//
$(function () {
    $(".buyers-wrap .categories .cat-sub-head, .buyers-wrap .cat-head2,.trade-cat-det .trade-categories .trade-cat-head,.refine-head,.press-aside h3,.cate-title h4").click(function () {
        $(this).next(".form-group,.form-group2, .categories2").slideToggle();
        $(this).parent(".categories2,.categories").toggleClass("padd-bot");
        $(this).nextAll(".form-group2").slideToggle();
        $(this).find("i").toggleClass("ani");
        $('.vid-cat-tog').slideToggle();
    });
    $(".categories-new input").focusin(function () {
        $(".categories-new .input-group").addClass("cat-search-bot");
    });
    $(".categories-new input").focusout(function () {
        $(".categories-new .input-group").removeClass("cat-search-bot");
    });
    $(".buyers-wrap .more-btn").click(function () {
        $(".buyers-wrap .lightbox").addClass("posfix").show();
    });
    $(".more-cat .buyer-close,.buyers-wrap .lightbox").click(function () {
        $(".buyers-wrap .lightbox").removeClass("posfix").hide();
    });
});
//for empty field hidden
$(function () {
//   $('.empty-child:empty').closest('.empty-parent').remove();
});
//* * * * * * * * * * * * * * MENU * * * * * * * * * * * * * * //
/*global $, URL_MAIN_PATH */
$(document).ready(function () {

    "use strict";
    $('.menu > ul > li:has( > ul)').addClass('menu-dropdown-icon');
    //Checks if li has sub (ul) and adds class for toggle icon - just an UI

    $('.menu > ul > li > ul:not(:has(ul))').addClass('normal-sub');
    //Checks if drodown menu's li elements have anothere level (ul), if not the dropdown is shown as regular dropdown, not a mega menu (thanks Luka Kladaric)

    $(".menu > ul").before("<a href=\"#\" class=\"menu-mobile\">menu</a>");
    //Adds menu-mobile class (for mobile toggle menu) before the normal menu
    //Mobile menu is hidden if width is more then 959px, but normal menu is displayed
    //Normal menu is hidden if width is below 959px, and jquery adds mobile menu
    //Done this way so it can be used with wordpress without any trouble

    $(".menu > ul > li").hover(function (e) {
        if ($(window).width() > 943) {
            $(this).children("ul").stop(true, false).fadeToggle(150);
            e.preventDefault();
        }
    });
    //If width is more than 943px dropdowns are displayed on hover

    $(".menu > ul > li").click(function () {
        if ($(window).width() <= 943) {
            $(this).children("ul").fadeToggle(150);
        }
    });
    //If width is less or equal to 943px dropdowns are displayed on click (thanks Aman Jain from stackoverflow)

    $(".menu-mobile").click(function (e) {
        $(".menu > ul").toggleClass('show-on-mobile');
        e.preventDefault();
    });
    //when clicked on mobile-menu, normal menu is shown as a list, classic rwd menu story (thanks mwl from stackoverflow)

});
//create websites
$(function () {
    $("#check-responsive,.comp").click(function () {
        $("#check-responsive").fadeOut();
        $(".mobile-app,.mobile-app2,.tab-app,.tab-app2").fadeOut();
        $(".secound-view").fadeOut();
    });
    $(".mob").click(function () {
        $(".mobile-app").fadeIn();
        $(".mobile-app2,.tab-app,.tab-app2").fadeOut();
        $("#check-responsive").fadeIn();
    });
    $(".mob2").click(function () {
        $(".mobile-app2").fadeIn();
        $(".mobile-app,.tab-app,.tab-app2").fadeOut();
        $("#check-responsive").fadeIn();
    });
    $(".tab").click(function () {
        $(".tab-app").fadeIn();
        $(".tab-app2,.mobile-app,.mobile-app2").fadeOut();
        $("#check-responsive").fadeIn();
    });
    $(".tab2").click(function () {
        $(".tab-app2").fadeIn();
        $(".tab-app,.mobile-app,.mobile-app2").fadeOut();
        $("#check-responsive").fadeIn();
    });
    $(".mob,.mob2,.tab,.tab2").click(function () {
        $(".secound-view").fadeIn();
    });
    $(".responce-check-header .close1").click(function () {
        $(".responce-check-header").slideUp();
        $(".res-down-arrow").fadeIn();
    });
    $(".res-down-arrow").click(function () {
        $(this).fadeOut();
        $(".responce-check-header").slideDown();
    });
    $("#step1").click(function () {
        $(this).addClass("active");
        $("#step2,#step3").removeClass("active");
        $(".choose-template-wrap").show();
        $(".name-site-wrap").hide();
        $(".cus-finish-wrap").hide();
    });
    $("#step2").click(function () {
        $(this).addClass("active");
        $("#step1").addClass("active");
        $("#step3").removeClass("active");
        $(".name-site-wrap").show();
        $(".choose-template-wrap").hide();
        $(".cus-finish-wrap").hide();
    });
    $("#step3").click(function () {
        $(this).addClass("active");
        $("#step1,#step2").addClass("active");
        $(".cus-finish-wrap").show();
        $(".name-site-wrap").hide();
        $(".choose-template-wrap").hide();
    });
    $(".create-web-secound .tempzoom").click(function () {
        $(".create-web-secound .modal").show();
        var img = $(this).parents(".thumbnail").find("img").attr("src");
        var temid = $(this).parents(".thumbnail").find("img").attr("onclick");
        var imgtem_function = 'addtemplateuser(' + temid + ')';
        $("#img01").attr("src", img);
        $("#imgtem_id").attr("onclick", imgtem_function);
    });
    $("#myModal1").click(function () {
        $(this).hide();
    });
    $(".name-site-wrap form input").focusin(function () {
        $(".name-site-wrap form input,.name-site-wrap form select").parents(".form-group").find("i").removeClass("focus-color");
        $(this).parents(".form-group").find("i").addClass("focus-color");
    });
    $(".name-site-wrap form select").focusin(function () {
        $(".name-site-wrap form input,.name-site-wrap form select").parents(".form-group").find("i").removeClass("focus-color");
        $(this).parents(".form-group").find("i").addClass("focus-color");
    });
});

/// business blogs share icons ///
$(function () {
    $('.share-icon').click(function () {
        $(this).children('.share-detail').toggleClass('share-new');
    });
});
////buying needs detail page image
$(function () {
    $(".buyersimg").hover(function () {
//        var rimg = $(this).attr("src");
//        $(this).parents(".bigimgwrap").find(".bigimg").attr("src", rimg);
//        $(this).parents(".bigimgwrap").find(".bigimg").attr("data-zoom-image", rimg);
    });
    $(".prod-detail-sub-img a").click(function () {
        $(".prod-detail-sub-img a").removeClass("active");
        $(this).addClass("active");
    });
});
$(document).ready(function () {
    //// business promotional////
    $('.promo-menu-icon').click(function () {
        $('.nav-icon-relate').animate({
            'left': '0%'
        });
        $('.promo-over').addClass('promo-overlay');
    });
    $('.promo-close,.promo-overlay').click(function () {
        $('.nav-icon-relate').animate({
            'left': '-25%'
        });
        $('.promo-over').removeClass('promo-overlay');
//         $('.promo-overlay').addClass('promo-over');
    });
    $(".mat-input").focus(function () {
        $(this).parent().addClass("is-active is-completed");
    });
    $(".mat-input").focusout(function () {
        if ($(this).val() === "")
            $(this).parent().removeClass("is-completed");
        $(this).parent().removeClass("is-active");
    });
//    $('.b2b-service').mouseover(function () {
//
//        $('.serv-trans').css({
//            'transform': 'scale(1)'
//        });
//    });
//    $('.b2b-service').mouseleave(function () {
//
//        $('.serv-trans').css({
//            'transform': 'scale(1.1)'
//        });
//    });
//
//////b2b clssifieds /////
    var b = 1;
    $('.b2b-responsive').click(function () {
        if (b == 1) {
            $('.question-category').css({
                'top': '53px', 'transition': '0.5s ease-in-out', 'opacity': '1', 'z-index': '999', 'border-top': '2px solid white'

            });
            $('.b2b-responsive span:nth-child(3)').css({
                'transform': 'rotate(150deg)', 'transition': '0.5s ease-in-out', 'top': '27px'
            });
            $('.b2b-responsive span:nth-child(2)').css({
                'transform': 'rotate(-150deg)', 'transition': '0.5s ease-in-out'
            });
            $('.b2b-responsive span:nth-child(4)').css({
                'transition': '0.5s ease-in-out', 'opacity': '0'
            });
            $('.b2b-responsive').css({
                'overflow': 'auto', 'height': '400px', 'overflow-x': 'hidden'
            });
            b = 0;
        } else
        {
            $('.question-category').css({
                'top': '53px', 'transition': '0.5s ease-in-out', 'opacity': '0', 'z-index': '-1'
            });
            $('.b2b-responsive span:nth-child(3)').css({
                'transform': 'rotate(0deg)', 'transition': '0.5s ease-in-out', 'top': '34px'
            });
            $('.b2b-responsive span:nth-child(2)').css({
                'transform': 'rotate(0deg)', 'transition': '0.5s ease-in-out'
            });
            $('.b2b-responsive span:nth-child(4)').css({
                'transition': '0.5s ease-in-out', 'opacity': '1'
            });
            $('.b2b-responsive').css({
                'overflow': 'hidden', 'height': '50px'
            });
            b = 1;
        }
    });
});
//Tooltip
//$(document).ready(function () {
//    $(".owl-demo1").each(function (index, crousel) {
//        crousel.owlCarousel();
//    });
//});
$(function () {
    $('[data-toggle="tooltip"]').tooltip();

    ////hot news///
    var owl4 = $(".newss");
    owl4.owlCarousel({
        items: 1,
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            500: {
                items: 1
            },
            770: {
                items: 1
            },
            990: {
                items: 1
            }
        },
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ]
    });
    $('.play').on('click', function () {
        owl4.trigger('autoplay.play.owl', [4000]);
    });
    $('.stop').on('click', function () {
        owl4.trigger('autoplay.stop.owl');
    });
//Business certificates
    $(window).scroll(function () {
        if ($(window).width() < 767) {
            $wt = $(window).scrollTop();
            if ($wt > 10) {
                $('.con-nav1').addClass('fixed');
            } else {
                $('.con-nav1').removeClass('fixed');
            }
        }
        if ($(window).scrollTop() > 500) {
            $(".con-nav1").addClass('busi-certi');
        } else {
            $(".con-nav1").removeClass('busi-certi');
        }

    });
//////////////////////////////////////////////////
    function ChangeUrl(page, url) {
        if (typeof (history.pushState) != "undefined") {
            var obj = {Page: page, Url: url};
            history.pushState(obj, obj.Page, obj.Url);
        } else {
            alert("Browser does not support HTML5.");
        }
    }
    function isSet(name) { // Like isset function in PHP
        var ret = false;
        if (typeof name != "undefined")
            ret = true;
        return ret;
    }
    function removeValue(list, value, separator) {
        separator = separator || ",";
        var values = list.split(separator);
        for (var i = 0; i < values.length; i++) {
            if (values[i] == value) {
                values.splice(i, 1);
                return values.join(separator);
            }
        }
        return list;
    }
    $(function () {
        /// search filter -  filter premium member ///
        $(".premium1").click(function () {
            var mt = querySt = '';
            var clkval = $(this).val();
            var queries = {};
            $.each(document.location.search.substr(1).split('&'), function (c, q) {
                var i = q.split('=');
                queries[i[0].toString()] = i[1].toString();
            });
            $('input:checkbox[name=mtype]:checked').each(function () {
                if (this.checked) {
                    if (mt != '')
                        mt = mt + ',' + $(this).val();
                    else
                        mt = $(this).val();
                }
            });
            var uniqueList = mt.split(',').filter(function (allItems, i, a) {
                return i == a.indexOf(allItems);
            }).join(',');
            if (isSet(queries['mtype']) && queries['mtype'].indexOf(clkval) != -1)
            {
                uniqueList = removeValue(uniqueList, clkval, ',');
            }
            querySt = getUrlQueries(queries, 'mtype', uniqueList);
            window.location.href = URL_MAIN_PATH + '/search?' + querySt;
        });
        /// search filter -Country filter ///
        $(".mcountry").click(function () {
            var mc = querySt = '';
            var clkval = $(this).val();
            var queries = {};
            $.each(document.location.search.substr(1).split('&'), function (c, q) {
                var i = q.split('=');
                queries[i[0].toString()] = i[1].toString();
            });
            $('input:checkbox[name=mcountry]').each(function ()
            {
                if (this.checked) {
                    if (mc != '')
                        mc = mc + ',' + $(this).val();
                    else
                        mc = $(this).val();
                }
            });
            var uniqueList = mc.split(',').filter(function (allItems, i, a) {
                return i == a.indexOf(allItems);
            }).join(',');
            if (isSet(queries['country']) && queries['country'].indexOf(clkval) != -1)
            {
                uniqueList = removeValue(uniqueList, clkval, ',');
            }

            querySt = getUrlQueries(queries, 'country', uniqueList);
            window.location.href = URL_MAIN_PATH + '/search?' + querySt;
        });
        /// search filter -Classifieds filter ///
        $(".classipremium").click(function () {
            var mt = querySt = '';
            var clkval = $(this).val();
            var queries = {};
            $.each(document.location.search.substr(1).split('&'), function (c, q) {
                var i = q.split('=');
                queries[i[0].toString()] = i[1].toString();
            });
            $('input:checkbox[name=mtype]:checked').each(function ()
            {
                if (this.checked) {
                    if (mt != '')
                        mt = mt + ',' + $(this).val();
                    else
                        mt = $(this).val();
                }
            });
            var uniqueList = mt.split(',').filter(function (allItems, i, a) {
                return i == a.indexOf(allItems);
            }).join(',');
            if (isSet(queries['verified']) && queries['verified'].indexOf(clkval) != -1)
            {
                uniqueList = removeValue(uniqueList, clkval, ',');
            }
            querySt = getClasiUrlQueries(queries, 'verified', uniqueList);
            window.location.href = URL_MAIN_PATH + '/classifieds/search?' + querySt;
        });
        $(".clasicountry").click(function () {
            var mc = querySt = '';
            var clkval = $(this).val();
            var queries = {};
            $.each(document.location.search.substr(1).split('&'), function (c, q) {
                var i = q.split('=');
                queries[i[0].toString()] = i[1].toString();
            });
            $('input:checkbox[name=clasicountry]').each(function ()
            {
                if (this.checked) {
                    if (mc != '')
                        mc = mc + ',' + $(this).val();
                    else
                        mc = $(this).val();
                }
            });
            var uniqueList = mc.split(',').filter(function (allItems, i, a) {
                return i == a.indexOf(allItems);
            }).join(',');
            if (isSet(queries['country']) && queries['country'].indexOf(clkval) != -1)
            {
                uniqueList = removeValue(uniqueList, clkval, ',');
            }

            querySt = getClasiUrlQueries(queries, 'country', uniqueList);
            window.location.href = URL_MAIN_PATH + '/classifieds/search?' + querySt;
        });
    });
    function getUrlQueries(queries, name, setvalue) {
        var qarray = {};
        var querySt = '';
        var querySt = qarray['q'] = qarray['mtype'] = qarray['country'] = qarray['type'] = '';
        if (isSet(queries['q']) && queries['q'] != '') {
            qarray['q'] = 'q=' + queries['q'];
        }
        if (isSet(queries['view']) && queries['view'] != '') {
            qarray['view'] = 'view=' + queries['view'];
        }
        if (isSet(queries['type']) && queries['type'] != '') {
            qarray['type'] = 'type=' + queries['type'];
        }
        if (isSet(queries['mtype']) && queries['mtype'] != '') {
            qarray['mtype'] = 'mtype=' + queries['mtype'];
        }
        if (isSet(queries['country']) && queries['country'] != '') {
            qarray['country'] = 'country=' + queries['country'];
        }

        if (qarray['q'] != '' && name != 'q')
            querySt += (querySt != '' ? '&' : '') + qarray['q']
        if (qarray['view'] != '' && name != 'view')
            querySt += (querySt != '' ? '&' : '') + qarray['view']
        if (qarray['type'] != '' && name != 'type')
            querySt += (querySt != '' ? '&' : '') + qarray['type']
        if (qarray['mtype'] != '' && name != 'mtype')
            querySt += (querySt != '' ? '&' : '') + qarray['mtype']
        if (qarray['country'] != '' && name != 'country')
            querySt += (querySt != '' ? '&' : '') + qarray['country']
        if (setvalue != '')
            querySt += '&' + name + '=' + setvalue;
        return querySt;
    }

    function getClasiUrlQueries(queries, name, setvalue) {
        var qarray = {};
        var querySt = '';
        var querySt = qarray['q'] = qarray['verified'] = qarray['country'] = qarray['type'] = '';
        if (isSet(queries['q']) && queries['q'] != '') {
            qarray['q'] = 'q=' + queries['q'];
        }
        if (isSet(queries['view']) && queries['view'] != '') {
            qarray['view'] = 'view=' + queries['view'];
        }
        if (isSet(queries['type']) && queries['type'] != '') {
            qarray['type'] = 'type=' + queries['type'];
        }
        if (isSet(queries['verified']) && queries['verified'] != '') {
            qarray['verified'] = 'verified=' + queries['verified'];
        }
        if (isSet(queries['country']) && queries['country'] != '') {
            qarray['country'] = 'country=' + queries['country'];
        }

        if (qarray['q'] != '' && name != 'q')
            querySt += (querySt != '' ? '&' : '') + qarray['q']
        if (qarray['view'] != '' && name != 'view')
            querySt += (querySt != '' ? '&' : '') + qarray['view']
        if (qarray['type'] != '' && name != 'type')
            querySt += (querySt != '' ? '&' : '') + qarray['type']
        if (qarray['verified'] != '' && name != 'verified')
            querySt += (querySt != '' ? '&' : '') + qarray['verified']
        if (qarray['country'] != '' && name != 'country')
            querySt += (querySt != '' ? '&' : '') + qarray['country']
        if (setvalue != '')
            querySt += '&' + name + '=' + setvalue;
        return querySt;
    }

    $("#share").jsSocials({
        showLabel: false,
        showCount: false,
        shareIn: "popup",
        shares: ["email", "twitter", "facebook", "googleplus", "linkedin", "pinterest", "stumbleupon", "whatsapp"]
    });
    $(".shareRoundIcons").each(function () {
        $(this).jsSocials({
            url: $(this).data('url'),
            showLabel: false,
            showCount: false,
            shareIn: "popup",
            shares: ["twitter", "facebook", "googleplus", "linkedin", "pinterest"]
        });
    });
});
//function sampleclickfunc(countslug) {
//    console.log(countslug);
//    var selected_val = $('#selected_val').val();
//    var boxes = $('.mcountry' + countslug).is(":checked");
//    console.log(boxes);
//}

//function blogshare(blog){
//    $('#busiblog').val(blog);
//}

$(function () {
    if (typeof buynowBtn != 'undefined') {
//        console.log('sadffsda');
        $('#buynowButton').click();
    }
});
$(document).ready(function () {
    $('#scrol_rate').click(function () {
//        console.log('test');
    });
    ////// page share - social icons //////
    $('#share').hover(function () {
        $(".share-close-menu").css({'left': '0px', 'transition': '0.6s all linear'});
    });
    $('.more_li').hover(function () {
        $(".share-close-menu").css({'left': '0px', 'transition': '0.6s all linear'});
    });
    var s = 0;
    $(".share-close-menu").click(function () {
        if (s == 0) {
            $("#share").animate({'left': '-400px'});
            $(".share-close-menu").html("<i class='fa fa-angle-double-right' aria-hidden='true'></i>");
            s = 1;
        } else {
            $("#share").animate({'left': '0px'});
            $(".share-close-menu").html("<i class='fa fa-angle-double-left' aria-hidden='true'></i>");
            s = 0;
        }
    });
    $(".share-responsive-close-menu").click(function () {
        if (s == 0) {
            $("#share").animate({'left': '0'});
            s = 1;
        } else {
            $("#share").animate({'left': '-500px'});
            s = 0;
        }
    });
    $(".chat-center").mouseover(function () {
        $(".help-popup").animate({'right': '75px'});
    });
    $(".chat-center").mouseleave(function () {
        $(".help-popup").animate({'right': '-200px'});
    });
    $(".chat-center").click(function () {

        $('.chat-transform').toggleClass('transform-active');
    });
    $('.close-section').click(function () {
//        $('.chat-login').sideToggle();
        $('.chat-transform').toggleClass('transform-active');
    });
    $(".chat-center").click(function () {

        $('.chat-transform1').toggleClass('transform-active1');
    });
    $('.close-section').click(function () {
        $('.chat-transform1').toggleClass('transform-active1');
    });
    $('.review-scroll').click(function () {
        var hre = $(this).attr('href');
        var scroll = $(hre).offset().top - 130;
        $('html,body').animate({
            scrollTop: scroll
        });
        return false;
        $('.review-scroll').attr('id', 'cur-menu');
    });
//    $(".rating-container").click(function () {
//     $('#review-scr').scrollView();
//    });
    $(".ratingInput").click(function () {
        $("html, body").animate({scrollTop: $("#review-scr").offset().top}, 'slow');
    });
});
//$(function() {
//    $('.noAutoComplete').attr('autocomplete', 'off');
//});

////////////////////////////////////////////////////////////////////////////////////////
//profile member type
$(document).ready(function () {

//    $(".community_left").click(function(){
//       $(".individual_left").hide();
//    });
//    $(".wel_active").click(function () {
//        $(".wel_active a").removeClass("welcome_icons-b,welcome_icons-d");
//    });

//----------------------HOME-FLASHNEWS-RUNNING TEXT-------------------------//
    window.requestAnimationFrame = (function () {
        return  window.requestAnimationFrame ||
                window.webkitRequestAnimationFrame ||
                window.mozRequestAnimationFrame ||
                function (callback) {
                    window.setTimeout(callback, 1000 / 60);
                };
    })();
    var speed = 10000;
    (function currencySlide() {
        var currencyPairWidth = $('.slideItem:first-child').outerWidth();
        $(".news-slideContainer").animate({marginLeft: -currencyPairWidth}, speed, 'linear', function () {
            $(this).css({marginLeft: 0}).find("li:last").after($(this).find("li:first"));
        });
        requestAnimationFrame(currencySlide);
    })();
});
$(function () {
    var active = true;
    $('#collapse-init').click(function () {
        if (active) {
            active = false;
            $('.panel-collapse').collapse('show');
            $('.panel-title').attr('data-toggle', '');
            $(this).text('Enable accordion behavior');
        } else {
            active = true;
            $('.panel-collapse').collapse('hide');
            $('.panel-title').attr('data-toggle', 'collapse');
            $(this).text('Disable accordion behavior');
        }
    });
    $('.msgAccordion').on('show.bs.collapse', function () {
        if (active)
            $('.msgAccordion .in').collapse('hide');
    });
});
$(function () {
    $(".ratingInput").rating({
        'showCaption': false,
        'step': 1,
        'size': 'xs',
//            'color':'orange',
        'background': 'orange',
        'showClear': false,
        'type': 'hidden'
    });
//$(".rating-container").css({'position':'relative','cursor':'pointer','vertical-align':'middle','display':'inline-block','overflow':'hidden','white-space':'nowrap'});
//    $(".ratingInput").css({'border':'0px transparent ','position':'absolute','cursor':'pointer','width':'0px','height':'0px','bottom':'0','left':'0','font-size':'0px','background':'0 0','padding':'0','margin':'0','display':'inline-block','box-shadow':'none'});
    $('#input-id').rating('refresh', {disabled: true, showClear: false, showCaption: true});
    /*************** method chaining *********/
    var ratingValue = $('#input-id').rating('refresh', {
        disabled: true,
        showClear: false,
        showCaption: true
    }).val();
});
//gallery for quotes
//
//
//function quote_close() {
//    $('.quote-image-box').css("display", "none");
//}
//$(function () {
//    $('.gal-imgs').click(function () {
//        $('.quote-image-box').css("display", "block");
//    });
//    $('.quote-image-box').click(function () {
//        $('.quote-image-box').css("display", "none");
//    });
//
//
//});

//*************** lightbox for gallery quotes *****************//
$(document).ready(function () {
    $('.thumbnail,.gallery-sec i').click(function () {
        $('.modal-body').empty();
        var title = $(this).parent('a').attr("title");
        $('.modal-title').html(title);
        $($(this).parents('div').html()).appendTo('.modal-body');
        $('#quotesmodal').modal({show: true});
    });
});
///************** Profile inbox checkbox ********///
$(function () {
    $('.msgCheckAll').click(function () {
        //   $('.childCheckBox').attr('checked', this.checked);
        if (this.checked) {
            $('.childCheckBox').each(function () {
                this.checked = true;
            });
        } else {
            $('.childCheckBox').each(function () {
                this.checked = false;
            });
        }
        // $(".childCheckBox").attr("checked",function(){return $(this).attr("checked") ? false : true;});
    })
    $('.childCheckBox').click(function () {
//        if($('.childCheckBox:checked').length == $('.childCheckBox').length){
//            $('.msgCheckAll').attr('checked',true);
//        }else{
//            $('.msgCheckAll').attr('checked',false);
//        }
    });
});
//$('#mainq').keypress(function () {
//    var txtval = $(this).val();
////    console.log(txtval.length);
//    if (txtval.length > 2) {
//        $('#mainq').autocomplete({
//            minlength: 3,
//            source: URL_MAIN_PATH + '/autosuggest'
//        });
//    }
//});

//if (typeof searchtypehead != 'undefined') {
//
//    var searchNames = new Bloodhound({
//        datumTokenizer: function (datum) {
//            return Bloodhound.tokenizers.whitespace(datum.value);
//        },
//        queryTokenizer: Bloodhound.tokenizers.whitespace,
//        remote: {
//            wildcard: '%QUERY',
//            url: searchtypeheadurl,
//            transform: function (response) {
//                return $.map(response, function (item) {
//                    return {
//                        search: item
//                    };
//                });
//            }
//        }
//    });
//
//    $('.typeahead').typeahead(null, {
//        display: 'search',
//        source: searchNames
//    }).bind('typeahead:select', function (ev, suggestion) {
//        var text = suggestion.search;
//        var searchkey = text.toLowerCase();
//        var replaced = searchkey.split(' ').join('+');
//        if (typeof text != 'undefined') {
//            window.location.href = URL_MAIN_PATH + '/search?q=' + replaced;
//        }
//    });
//
//}
///////////////// article, press releases,news,blog image uploader //
var old_imgpromo = $('#old_imgpromo').val();
function readURLPromotion(input, div) {
//    console.log(input.files.length);
    if (input.files.length > 0) {
        var extension = input.files[0].name.split('.').pop().toLowerCase();
        if (input.files && input.files[0] && (extension == 'jpg' || extension == 'JPG' || extension == 'jpeg' || extension == 'JPEG' || extension == 'png' || extension == 'PNG' || extension == 'gif' || extension == 'GIF')) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#' + div).attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            } else {
                if (typeof old_imgpromo != 'undefined' && old_imgpromo != '') {
                    $('#' + div).attr('src', URL_UPLOADS_PATH + '/' + old_imgpromo);
                } else {
                    $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
                }
            }
        } else {

            $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
        }
    } else {
        $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
    }
}
if (typeof b2b_android_app != 'undefined') {
    $(window).scroll(function () {
        var wt = $(window).scrollTop();
        var wh = $(window).height();
        var top1 = $('#top1').offset().top;
        var top2 = $('#top2').offset().top;
        var top3 = $('#top3').offset().top;
        var top4 = $('#top4').offset().top;
        var top5 = $('#top5').offset().top;
        var top6 = $('.tab').offset().top;
        if (wt === 0) {
            $('#down').show(400);
        } else {
            $('#down').hide(400);
        }
        if (top1 <= wt + wh - 300) {
            $('.animation1').removeClass("animated fadeOutLeft");
            $('.animation1').addClass("animated fadeInLeft");
        }
        if (top1 > wt + wh - 300) {
            $('.animation1').removeClass("animated fadeInLeft");
            $('.animation1').addClass("animated fadeOutLeft");
        }
        if (top2 <= wt + wh - 400) {
            $('.animation2').removeClass("animated fadeOut");
            $('.animation2').addClass("animated fadeIn");
        }
        if (top2 > wt + wh - 400) {
            $('.animation2').removeClass("animated fadeIn");
            $('.animation2').addClass("animated fadeOut");
        }
        if (top3 <= wt + wh - 300) {
            $('.animation3').removeClass("animated fadeOutLeft");
            $('.animation3').addClass("animated fadeInLeft");
        }
        if (top3 > wt + wh - 300) {
            $('.animation3').removeClass("animated fadeInLeft");
            $('.animation3').addClass("animated fadeOutLeft");
        }
        if (top4 <= wt + wh - 300) {
            $('.animation4').removeClass("animated fadeOut");
            $('.animation4').addClass("animated fadeIn");
        }
        if (top4 > wt + wh - 300) {
            $('.animation4').removeClass("animated fadeIn");
            $('.animation4').addClass("animated fadeOut");
        }
        if (top5 <= wt + wh - 300) {
            $('.animation5').removeClass("animated fadeOutLeft");
            $('.animation5').addClass("animated fadeInLeft");
        }
        if (top5 > wt + wh - 300) {
            $('.animation5').removeClass("animated fadeInLeft");
            $('.animation5').addClass("animated fadeOutLeft");
        }
        if (top6 <= wt + wh - 300) {
            $('.animation6').removeClass("animated fadeOutRight");
            $('.animation6').addClass("animated fadeInRight");
        }
        if (top6 > wt + wh - 300) {
            $('.animation6').removeClass("animated fadeInRight");
            $('.animation6').addClass("animated fadeOutRight");
        }
/////////////////////    mobile animations   ///////////////////////
        if (top1 <= wt + wh - 400)
        {
            $('.animation1m').removeClass("animated fadeOutRight");
            $('.animation1m').addClass("animated fadeInRight");
        }

        if (top1 > wt + wh - 400)
        {
            $('.animation1m').removeClass("animated fadeInRight");
            $('.animation1m').addClass("animated fadeOutRight");
        }
        if (top2 <= wt + wh - 300)
        {
            $('.animation2m').removeClass("animated fadeOutLeft");
            $('.animation2m').addClass("animated fadeInLeft");
            $('.animation2m1').removeClass("animated fadeOutRight");
            $('.animation2m1').addClass("animated fadeInRight");
        }

        if (top2 > wt + wh - 300)
        {
            $('.animation2m').removeClass("animated fadeInLeft");
            $('.animation2m').addClass("animated fadeOutLeft");
            $('.animation2m1').removeClass("animated fadeInRight");
            $('.animation2m1').addClass("animated fadeOutRight");
        }
        if (top3 <= wt + wh - 300)
        {
            $('.animation3m,.animation3m1,.animation3m2,.animation3m3').removeClass("animated fadeOutRight");
            $('.animation3m,.animation3m1,.animation3m2,.animation3m3').addClass("animated fadeInRight");
        }

        if (top3 > wt + wh - 300)
        {
            $('.animation3m,.animation3m1,.animation3m2,.animation3m3').removeClass("animated fadeInRight");
            $('.animation3m,.animation3m1,.animation3m2,.animation3m3').addClass("animated fadeOutRight");
        }
        if (top4 <= wt + wh - 400)
        {
            $('.animation4m').removeClass("animated fadeOutRight");
            $('.animation4m1').removeClass("animated fadeOutLeft");
            $('.animation4m').addClass("animated fadeInRight");
            $('.animation4m1').addClass("animated fadeInLeft");
        }

        if (top4 > wt + wh - 400)
        {
            $('.animation4m').removeClass("animated fadeInRight");
            $('.animation4m1').removeClass("animated fadeInLeft");
            $('.animation4m').addClass("animated fadeOutRight");
            $('.animation4m1').addClass("animated fadeOutLeft");
        }
        if (top3 <= wt + wh - 400)
        {
            $('.animation5m,.animation5m1,.animation5m2').removeClass("animated fadeOutRight");
            $('.animation5m,.animation5m1,.animation5m2').addClass("animated fadeInRight");
        }

        if (top3 > wt + wh - 400)
        {
            $('.animation5m,.animation5m1,.animation5m2').removeClass("animated fadeInRight");
            $('.animation5m,.animation5m1,.animation5m2').addClass("animated fadeOutRight");
        }

    });
    $(document).ready(function () {


        function scrollbutton() {
            var target = $(lin);
            if (target.length)
            {
                var top = target.offset().top;
                $('html,body').animate({
                    scrollTop: top - 100
                }, 1000);
                return false;
            }
        }
        $('.scrollbtn').click(function () {
            lin = $(this).attr('alt');
            scrollbutton(lin);
            $('#down').hide(400);
            return false;
        });
    });
    $(document).ready(function () {
//	$(window).scroll(function(){
//		if ($(".scroll_btn").scrollTop() > 600) {
//			$('.scroll_btn').fadeIn();
//		} else {
//			$('.scroll_btn').fadeOut();
//		}
//	});

        $('#app-top').click(function () {
            $('html, body').animate({scrollTop: 0}, 800);
            return false;
        });
        $('.newsbilla_dwnld_destin').click(function () {
            $('html, body').animate({scrollTop: $(".newsbilla_download").offset().top});
        });
    });
}
//choose file js
$(document).on('click', '.browse', function () {
    var file = $(this).parent().parent().parent().find('.file');
    file.trigger('click');
});
$(document).on('change', '.file', function () {
    $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
});
function getParameterByName(name, url) {
    if (!url)
        url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
    if (!results)
        return null;
    if (!results[2])
        return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
//auto hide of alert messages within 2 sec
$(function () {
    setTimeout(function () {
        $('#auto_hide .alert').fadeOut('slow');
    }, 4000);
});
(function ($) {
    $.fn.progress = function () {
        var percent = this.data("percent");
        this.css("width", percent + "%");
    };
}(jQuery));
$(document).ready(function () {
    $(".bar-one .bar").progress();
    $(".bar-two .bar").progress();
    $(".bar-three .bar").progress();
    $(".bar-four .bar").progress();
    $(".bar-five .bar").progress();
    $(".addform_modal").mouseover(function () {
        $(this).css({'cursor': 'default !important'});
    });
});
//    $(window).load(function(){
//        var redirect = $('#redirect').val();
//        if(redirect){
//       alert();
//
//        }
//    });
$(function () {
    //// core modules chatbox button ///
    $('.chatNowBox').on('click', function (e) {
        e.preventDefault();
        var user = $(this).data("user");
        var userId = user.userId;
//        openInNewTab(URL_MAIN_PATH + '/trade-connect?u=' + userId)
    });
})

function openInNewTab(url) {
    var win = window.open(url, '_blank');
    win.focus();
}
//// create webiste page ////
function dissignup() {
    $('#websitereg').hide();
    $('#usertypecheck').hide();
}
//function checkLiveMembers(){
//       $.ajax({
//        url: URL_PRODUCTS_PATH + '/reuest-login-post',
//        data: {supplierid: supplierid, reqproductid: product_id, sendpincode: pincode, action: 'pinreq'},
//        type: 'post',
//        success: function (e) {
////            console.log(e);
//            $('#sucreq').show();
//            setTimeout(function () {
//                $('#sucreq').html();
//                $('#sucreq').hide();
//            }, 2000)
//        }
//    });
//}
//$(function () {
//    if (typeof chatPage != 'undefined') {
//        console.log('_users');
//
//        var membersList = jQuery.parseJSON(_users);
//        $.each(membersList, function (index, value) {
//
//            $('#chat_' + value).addClass("sell-chat");
//            $('#chat_' + value).removeClass("chat-offline");
//        });
//    }
//
//});
//// profile message add favourite ////
function setStarMessage(id) {

    var starclass = $('.msgid_' + id).attr('data-star');
    $.ajax({
        type: 'post',
        url: URL_PROFILE_PATH + 'messages/markToStarred',
        data: {
            message_id: id,
            star_type: starclass
        },
        success: function (e) {

            var starvalue = jQuery.parseJSON(e)
            // console.log(starvalue.attr);

            $('.msgid_' + id).addClass(starvalue.addclass).removeClass(starvalue.removeclass).attr("data-star", starvalue.attr);
        }
    });
}
//function deleteMessage($msg_id){
//     $.ajax({
//                url: URL_PROFILE_PATH + 'messages/moveToTrash',
//                data: {
//                    pageName: 'inbox',
//                    ids: $msg_id
//
//                },
//                type: "get",
//                success: function (data) {
//                    //  console.log(data);
//
//                }
//
//            });
//}
//$("#owl-demo-indx").owlCarousel({
//    autoPlay: 3000, //Set AutoPlay to 3 seconds
//
//    items: 4,
//    itemsDesktop: [1199, 3],
//    itemsDesktopSmall: [979, 3]
//
//});

//
//$(document).ready(function () {
//    var owl6 = $("#owl-demo-indx");
//    owl6.owlCarousel({
//        items: 1,
//        loop: true,
//        margin: 10,
//        nav: true,
//        responsive: {
//            0: {
//                items: 1
//            },
//            500: {
//                items: 1
//            },
//            770: {
//                items: 1
//            },
//            990: {
//                items: 1
//            }
//        },
//        autoplay: true,
//        autoplayTimeout: 5000,
//        autoplayHoverPause: true,
//        navText: [
//            "<i class='fa fa-angle-left'></i>",
//            "<i class='fa fa-angle-right'></i>"
//        ]
//    });
//    $('.play').on('click', function () {
//        owl6.trigger('autoplay.play.owl', [4000]);
//    });
//    $('.stop').on('click', function () {
//        owl6.trigger('autoplay.stop.owl');
//    });
//
//});
$(document).ready(function () {
    var sync1 = $("#sync1");
    var sync2 = $("#sync2");
    var slidesPerPage = 1; //globaly define number of elements per page
    var syncedSecondary = true;
    sync1.owlCarousel({
        items: 1,
        slideSpeed: 4000,
        nav: true,
        autoplay: true,
        dots: true,
        loop: true,
        responsiveRefreshRate: 200,
        navText: ['<svg version="1.1" viewBox="0 0 476.213 476.213"><polygon points="476.213,223.107 57.427,223.107 151.82,128.713 130.607,107.5 0,238.106 130.607,368.714 151.82,347.5   57.427,253.107 476.213,253.107 "/></svg>', '<svg version="1.1" viewBox="0 0 476.213 476.213" ><polygon points="345.606,107.5 324.394,128.713 418.787,223.107 0,223.107 0,253.107 418.787,253.107 324.394,347.5   345.606,368.713 476.213,238.106 "/></svg>'],
    }).on('changed.owl.carousel', syncPosition);
    sync2
            .on('initialized.owl.carousel', function () {
                sync2.find(".owl-item").eq(0).addClass("current");
            })
            .owlCarousel({
                items: slidesPerPage,
                dots: true,
                nav: true,
                smartSpeed: 2000,
                slideSpeed: 4000,
                slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
                responsiveRefreshRate: 100
            }).on('changed.owl.carousel', syncPosition2);
    function syncPosition(el) {
        //if you set loop to false, you have to restore this next line
        //var current = el.item.index;

        //if you disable loop you have to comment this block
        var count = el.item.count - 1;
        var current = Math.round(el.item.index - (el.item.count / 2) - .5);
        if (current < 0) {
            current = count;
        }
        if (current > count) {
            current = 0;
        }

        //end block

        sync2
                .find(".owl-item")
                .removeClass("current")
                .eq(current)
                .addClass("current");
        var onscreen = sync2.find('.owl-item.active').length - 1;
        var start = sync2.find('.owl-item.active').first().index();
        var end = sync2.find('.owl-item.active').last().index();
        if (current > end) {
            sync2.data('owl.carousel').to(current, 100, true);
        }
        if (current < start) {
            sync2.data('owl.carousel').to(current - onscreen, 100, true);
        }
    }

    function syncPosition2(el) {
        if (syncedSecondary) {
            var number = el.item.index;
            sync1.data('owl.carousel').to(number, 100, true);
        }
    }

    sync2.on("click", ".owl-item", function (e) {
        e.preventDefault();
        var number = $(this).index();
        sync1.data('owl.carousel').to(number, 300, true);
    });
});
$(".alert-dismissible").fadeTo(10000, 500).slideUp(500, function () {
    $(".alert-dismissible").slideUp(500);
});
//function preventOnload(){
//      $(window).bind('beforeunload', function () {
//            return '>>>>>Before You Go<<<<<<<< \n Your custom message go here';
//        });
//}


$(function () {
    //console.log(bannerPage);
//    if (typeof bannerPage !== 'undefined') {
//        adBanners();
//    }

});
//function adBanners() {
//    var pageId = __pageId;
//    var moduleId = __moduleId;
//    var cityId = __cityId;
//    var countryId = __countryId;
//    var categoryType = __categoryType;
//    var categoryId = __categoryId;
//    $.ajax({
//        type: 'GET',
//        url: URL_MAIN_PATH + '/adbanners',
//        data: {
//            _pageId: pageId,
//            _moduleId: moduleId,
//            _categoryType: categoryType,
//            _categoryId: categoryId,
//            _cityId: cityId,
//            _countryId: countryId
//        },
//        dataType: 'jsonp'
//    }).done(function (response) {
//
//        var res = response[0];
//        if (res) {
//            var adBanners = JSON.parse(res.banners);
//            $.each(adBanners, function (index, e) {
//                if (e.img != '' && e.status == 1) {
//                    var imgPath = URL_UPLOADS_PATH + '/' + e.img;
//                    var addbannerPath = URL_MAIN_PATH + '/addbanner';
//                    var adshereimg = URL_CDN_PATH + '/assets/img/add-banner/ads_here.gif';
//                    var imgElement = $("<img>", {alt: e.brand_name, title: e.brand_name, src: imgPath, id: 'bannerImg'});
//                    imgElement.appendTo('.ad_' + index);
////                $(".ad_" + index).wrap("<a href='" + e.brand_url + "' target='_blank'></a>");
//                    $(".ad_" + index + " #bannerImg").wrap("<a href='" + e.brand_url + "' target='_blank' style='position:relative;'></a>");
//                    $(".ad_" + index + ">a").append("<p data-href='" + addbannerPath + "' data-symlink='addbanner' title='ads here' class='bannerModal' style='position: absolute;z-index: 10;left: 0;top: -40px;cursor: pointer'><img src='" + adshereimg + "' alt='ads here' title='ads here'></p>");
////                var addbanne_length = $(".ad_" + index).find('a').size();
////                console.log(addbanne_length);
////                if (addbanne_length == 2) {
////                    $(".ad_" + index + ">a").eq(0).css('display', 'none');
////                }
//
//                }
//            });
//
////            if (adBanners.h1 && adBanners.h2) {
////                $('.ad_h1').parents('.horiz-banner').children('div').css({"width": "50%"});
////            } else {
////                $('.ad_h1').parents('.horiz-banner').children('div').css({"width": "100%"});
////            }
//        }
//
//    }).fail(function (error) {
////        console.log(error.statusText);
//    });
//}

$(function () {
    setTimeout(function () {
        $("#basic_alert").alert('close');
        $("#basic_alert").remove;
    }, 6000);
});
/////////////////New home page-june//////////////

$(function () {
//    $('.grid-view-head .grid-trigger-link').addClass('view-active');

    $('.grid-view-head .grid-trigger-link').click(function () {
        $(this).addClass('view-active');
        $('.grid-view-head .list-trigger-link').removeClass('view-active');
        $('.view-type').addClass('grid-view-block');
    });
    $('.grid-view-head .list-trigger-link').click(function () {
        $(this).addClass('view-active');
        $('.grid-view-head .grid-trigger-link').removeClass('view-active');
        $('.view-type').removeClass('grid-view-block');
    });
});
//    $('.head-search #search_key option').css({"padding": "2px 15px", "cursor": "pointer"});

//***************no result search page**************
$(function () {
    $('.search-new-user input, .search-new-user label').click(function () {
        $('.search-newuser').show();
        $('.search-olduser').hide();
    });
    $('.search-old-user input, .search-old-user label').click(function () {
        $('.search-olduser').show();
        $('.search-newuser').hide();
    });
});
$(function () {
//   $('#rcountry').select2();
//$('.inactiveLink').click(function () {
////        $('.inactiveLink').attr('data-toggle','modal').attr('data-target','myModal');
//    $('#prem_mem').show();
//});
//    $('.inactiveLink').mouseover(function () {
//        $(this).parents(".details").parents(".thumbnail").find(".img-block .img-overlay").css('opacity', '1');
//    });
//    $('.inactiveLink').mouseleave(function () {
//        $(this).parents(".details").parents(".thumbnail").find(".img-block .img-overlay").css('opacity', '0');
//    });
//    $('#txtcountry,#txtdept').select2();
});
/////// Comments,ratings,reviews /////
function inquiry_alreadyemail_user(email, type) {
//    if (!validateEmail(email)) {
//        return false;
//    }
    if (email !== '') {
        $.ajax({
            type: 'GET',
            url: URL_LOGIN_PATH + '/getemail',
            dataType: 'jsonp',
            data: {
                emailid: email
            },
            crossDomain: true
        }).done(function (e) {
            var countrows = e.cntrows;
            if (countrows > 0) {
                $('.existing_user_password').show();
                $('#exampleInputPassword1').focus();
                $('#exampleInputPassword1').attr('required', 'required');
                $('#exampleInputName1,#exampleInputPassword2,#exampleInputCountry,#exampleInputbuyCountry').removeAttr('required', 'required');
                $('.new_user_password').hide();
            } else {
                $('.new_user_password').show();
                $('#exampleInputName1').focus();
                $('#exampleInputName1,#exampleInputPassword2,#exampleInputCountry,#exampleInputbuyCountry').attr('required', 'required');
                $('#exampleInputPassword1').removeAttr('required', 'required');
                $('.existing_user_password').hide();
            }
        }).fail(function (error) {
//            console.log(error.statusText);
        });
    }
}
/* complaints */
function complaint_alreadyemail_user(email, type) {
//    if (!validateEmail(email)) {
//        return false;
//    }
    if (email !== '') {
        $.ajax({
            type: 'GET',
            url: URL_LOGIN_PATH + '/getemail',
            dataType: 'jsonp',
            data: {
                emailid: email
            },
            crossDomain: true
        }).done(function (e) {
            var countrows = e.cntrows;
            if (countrows > 0) {
                $('.old_user_password').show();
                $('#exampleInputPassword1').focus();
                $('#exampleInputPassword1').attr('required', 'required');
                $('#exampleInputName1,#exampleInputComName1,#complaintCountry,#exampleInputContact1').removeAttr('required', 'required');
                $('.new_user_password').hide();
            } else {
                $('.new_user_password').show();
                $('#exampleInputName1').focus();
                $('#exampleInputName1,#exampleInputComName1,#complaintCountry,#exampleInputContact1').attr('required', 'required');
                $('#exampleInputPassword1').removeAttr('required', 'required');
                $('.old_user_password').hide();
            }
        }).fail(function (error) {
//            console.log(error.statusText);
        });
    }
}

/////// Post product, post buying needs, post services /////
function formtype_alreadyemail_user(email, type) {
    if (!validateEmail(email)) {
        return false;
    }
    if (email !== '') {
        $.ajax({
            type: 'GET',
            url: URL_LOGIN_PATH + '/getemail',
            dataType: 'jsonp',
            data: {
                emailid: email
            },
            crossDomain: true
        }).done(function (e) {
            var countrows = e.cntrows;
            // alert(countrows);
            if (countrows > 0) {
//                document.getElementById("alreadymail").style.color = "red";
//                $('#alreadymail').html('Email id already exist');
//                setTimeout(function () {
//                    $('#newemail').val('');
//                    $('#alreadymail').html('');
//                    $('#oldemail').val('');
//                }, 2000);
            } else {
                document.getElementById("emaildoes").style.color = "red";
                $('#emaildoes').html('Email does not exist');
                $('#oldemail').focus();
                setTimeout(function () {
                    $('#emaildoes').html('');
                    $('#oldemail').val('');
                }, 2000);
            }
        }).fail(function (error) {
//            console.log(error.statusText);
        });
    }
}

$("#exampleInputbuyCountry").select2({
    placeholder: 'Choose country',
    selectOnClose: true,
    tokenSeparators: [" "],
    matcher: function (params, data) {
        return matchStart(params, data);
    }
});

$(function () {

    $('#comment_form,#postBuyingRequirementForm').submit(function () {
        $('#comment_form,#postBuyingRequirementForm').parsley().validate("first");
        if ($('#comment_form,#postBuyingRequirementForm').parsley().isValid()) {
            $('.submitting').css({'display': 'none'});
            $('.processing').css({'display': 'inline-block', 'width': 'auto'});
        }
    });
});

$(function () {
    $('#min_order_qty').keydown(function (e) {
        if (e.shiftKey || e.ctrlKey || e.altKey) {
            e.preventDefault();
        } else {
            var key = e.keyCode;
            if (!((key == 8) || (key == 9) || (key == 46) || (key >= 35 && key <= 40) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105))) {
                e.preventDefault();
            }
        }
    });
});
$(function () {
    $('#exampleInputbuyCountry').next('.select2').find('.select2-selection').one('focus', select2Focus).on('blur', function () {
        $(this).one('focus', select2Focus);
    });

    function select2Focus() {
        $(this).closest('.select2').prevAll('#exampleInputbuyCountry').select2('open');
        $(this).closest("form").find("#product_name").focus();
    }
});
//------------------------------------------------------------------------------
$(window).scroll(function () {
    if ($(window).width() > 767) {
        $wt = $(window).scrollTop();
        if ($wt > 10) {
            $('.prim-head').addClass('head-fix');
//            $('#all_address').addClass('fixed-addr');
        } else {
            $('.prim-head').removeClass('head-fix');
//            $('#all_address').removeClass('fixed-addr');
        }
    }
});
if ($('.go-top').length > 0) {
    $('.go-top').click(function () {
        $('html,body').animate({
            scrollTop: 0
        });
    });
}

/*
 * get parent id for banner purpose
 */
function getparentid(parentid, pageid, memid) {
//    var parentid = $(this).parent().parent().attr('id');
//    console.log(parentid);
//    console.log(pageid);
//    console.log(memid);
//    alert(parentid);
    $.ajax({
        type: 'post',
        url: URL_MAIN_PATH + '/banners/setsession',
        data: {
            parentid: parentid, pageid: pageid, memid: memid
        },
        success: function (e) {
            if (e) {
//                alert(e);
                window.location.href = URL_MAIN_PATH + '/book-banner?pagesid=' + btoa(pageid);
            }
        }
    });
}

/*
 * get banner price
 */
function getBannerPrice(month, prc) {
    var totamt = month * prc;
//    alert(totamt);
    if (month > 1) {
        var mnstr = 'months';
    } else {
        mnstr = 'month';
    }
    var disc = $('#bandiscount').val();
    var discamt = (parseInt(disc) / 100) * totamt;
//    alert(discamt);
    var disctotamt = parseInt(totamt) - parseInt(discamt);
    var netamt = 0;
    var tottax = $('#taxcount').val();
    for (var i = 0; i < tottax; i++) {
        var taxperc = $('#taxpercen' + i).val();
        var taxamt = (parseInt(taxperc) / 100) * disctotamt;
        $('#taxamount' + i).val(taxamt.toFixed(2));
        $('#paytax' + i).text(taxamt.toFixed(2));
        netamt += parseInt(taxamt);
    }
    var totnet = disctotamt + netamt;
//    var cgst = (9 / 100) * totamt;
//    var sgst = (9 / 100) * totamt;
    $('#tot_amount').val(disctotamt.toFixed(2));
    $('#amt-label').text('Amount (for ' + month + ' ' + mnstr + ')');
    $('#pay-amt').text(totamt.toFixed(2));
    $('#pay-disc').text(discamt.toFixed(2));
    $('#discpercent').val(discamt.toFixed(2));
    $('#pay-totamt').text(disctotamt.toFixed(2));
    $('#netprice').val(totnet.toFixed(2));
//    $('#pay-cgst').text(cgst);
//    $('#pay-sgst').text(sgst);
//    var netamt = parseInt(totamt) + parseInt(cgst) + parseInt(sgst);
    $('#pay-netamt').text(totnet.toFixed(2));
}

$(document).ready(function () {
    if (window.location.hash == "#vertical") {
        $('html, body').animate({
            scrollTop: $("#vertical-banner").offset().top - 120
        }, 1000);
    } else if (window.location.hash == "#horizontal") {
        $('html, body').animate({
            scrollTop: $("#horiz-banner").offset().top - 300
        }, 1000);
    }
});

/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :
 Description     :
 Included        :
 Last Modified   :   Aug 15,2017 / Arivarasi
 Assigned to     :
 */
/*****  Profile ecomm combo offers ****/
if ($('#ecom_combo_offer_product').length) {
    $("#ecom_combo_offer_product").select2({});
}

$(document).ready(function () {
    $("#exampleInputEmail1").focus();
});
//*********** CITY - Statewise city page **************//
$(function () {
    if (typeof citytypehead != 'undefined') {
        var cityNames = new Bloodhound({
//            datumTokenizer: function (datum) {
//                return Bloodhound.tokenizers.whitespace(datum.value);
//            },
            datumTokenizer: Bloodhound.tokenizers.obj.whitespace('city_name'),
            queryTokenizer: Bloodhound.tokenizers.whitespace,
//            prefetch: typeheadurl,
            remote: {
                wildcard: '%QUERY',
                url: typeheadurl,
                filter: function (response) {

                    // Map the remote source JSON array to a JavaScript object array
                    return $.map(response, function (item) {
                        return {
                            city_id: item.id,
                            city: item.city_name,
                            cityslug: item.city_slug,
                            countryslug: item.country_slug,
                            stateslug: item.state_slug
                        };
                    });
                }
            }
        });
//*********** CITY - Statewise city Search **************//
        cityNames.initialize();
        // Instantiate the Typeahead UI
        $('#statecitysearch').typeahead(null, {
            displayKey: 'city',
            hint: false,
            source: cityNames.ttAdapter(),
            href: URL_CITY_PATH + '/{{countryslug}}/{{stateslug}}/sellers-and-buyers-in-{{cityslug}}.html',
            templates: {
                empty: [
                    '<div class="noitems">',
                    "Search doesn't match",
                    '</div>'
                ].join('\n')
            }
        }).bind('typeahead:select', function (ev, suggestion) {
            //        console.log(suggestion);
            //        console.log('Selection: ' + JSON.stringify(suggestion));
            //            console.log(suggestion.cityslug);
            if (typeof suggestion.cityslug != 'undefined') {
                window.location.href = URL_CITY_PATH + '/' + suggestion.countryslug + '/' + suggestion.stateslug + '/sellers-and-buyers-in-' + suggestion.cityslug + '.html';
            }
        });

    }
    //
    //    $(function () {
    //        var $wrapper = $('#wrapper');
    //
    //        // theme switcher
    //        var theme_match = String(window.location).match(/[?&]theme=([a-z0-9]+)/);
    //        var theme = (theme_match && theme_match[1]) || 'default';
    //        var themes = ['default', 'legacy', 'bootstrap2', 'bootstrap3'];
    //        $('head').append('<link rel="stylesheet" href="../dist/css/selectize.' + theme + '.css">');
    //
    //        var $themes = $('<div>').addClass('theme-selector').insertAfter('h1');
    //        for (var i = 0; i < themes.length; i++) {
    //            $themes.append('<a href="?theme=' + themes[i] + '"' + (themes[i] === theme ? ' class="active"' : '') + '>' + themes[i] + '</a>');
    //        }
    //
    //        // display scripts on the page
    //        $('script', $wrapper).each(function () {
    //            var code = this.text;
    //            if (code && code.length) {
    //                var lines = code.split('\n');
    //                var indent = null;
    //
    //                for (var i = 0; i < lines.length; i++) {
    //                    if (/^[	 ]*$/.test(lines[i]))
    //                        continue;
    //                    if (!indent) {
    //                        var lineindent = lines[i].match(/^([ 	]+)/);
    //                        if (!lineindent)
    //                            break;
    //                        indent = lineindent[1];
    //                    }
    //                    lines[i] = lines[i].replace(new RegExp('^' + indent), '');
    //                }
    //
    //                var code = $.trim(lines.join('\n')).replace(/	/g, '    ');
    //                var $pre = $('<pre>').addClass('js').text(code);
    //                $pre.insertAfter(this);
    //            }
    //        });
    //
    //        // show current input values
    //        $('select.selectized,input.selectized', $wrapper).each(function () {
    //            var $container = $('<div>').addClass('value').html('Current Value: ');
    //            var $value = $('<span>').appendTo($container);
    //            var $input = $(this);
    //            var update = function (e) {
    //                $value.text(JSON.stringify($input.val()));
    //            }
    //
    //            $(this).on('change', update);
    //            update();
    //
    //            $container.insertAfter($input);
    //        });
    //    });
//************** Files upload ************//
    Dropzone.options.myDropzone = {
        init: function () {
            thisDropzone = this;
            $.get('upload.php', function (data) {
                $.each(data, function (key, value) {
                    var mockFile = {
                        name: value.name,
                        size: value.size
                    };
                    thisDropzone.options.addedfile.call(thisDropzone, mockFile);
                    thisDropzone.options.thumbnail.call(thisDropzone, mockFile, "uploads/" + value.name);
                });
            });
        }
    };
    //---------------------------------------------------
    if (typeof AtJs != 'undefined') {
        var moduletags = $('#module-tags').val();
        $.fn.atwho.debug = true
        var splittags = moduletags.split(",");
        //    console.log(splittags);
        var names = splittags;
        var names = $.map(names, function (value, i) {
            var lwrcase = value.toLowerCase();
            var uprcase = value.toUpperCase();
            return {
                'id': i,
                'name': lwrcase,
                'upname': value
            };
        });
        var emojis = $.map(emojis, function (value, i) {
            return {
                key: value,
                name: value
            }
        });

        var at_config = {
            at: "@",
            data: names,
            headerTpl: '<div class="atwho-header">Member List<small>↑&nbsp;↓&nbsp;</small></div>',
            insertTpl: '{{${name}}}',
            displayTpl: "<li>${upname} </li>",
            limit: 200
        }
        $inputor = $('.inputor').atwho(at_config);
        $inputor.caret('pos', 47);
        $inputor.focus().atwho('run');
    }
});

$(function () {
    if (typeof headqsearch != 'undefined') {
        var type = $('#type').val();
        var searchtypeheadurl = URL_MAIN_PATH + '/autosuggest?term=%QUERY&count=10&type=' + type;
        var searchNames = new Bloodhound({
            datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
            queryTokenizer: Bloodhound.tokenizers.whitespace,
            prefetch: searchtypeheadurl,
            remote: {
                wildcard: '%QUERY',
                url: searchtypeheadurl,
                filter: function (response) {
                    return $.map(response, function (item) {
                        return {
                            search: item
                        };
                    });
                }
            }
        });

        searchNames.initialize();
//*************** Header Search **********//
        $('#headqsearch').typeahead(null, {
            displayKey: 'search',
            hint: false,
            limit: 9,
            source: searchNames.ttAdapter(),
            href: URL_MAIN_PATH + '/search?q={{search}}&type=' + type
        }).bind('typeahead:select', function (ev, suggestion) {
            var text = suggestion.search;
            var searchkey = text.toLowerCase();
            var replaced = searchkey.split(' ').join('+');
            if (typeof suggestion.search != 'undefined') {
                window.location.href = URL_MAIN_PATH + '/search?q=' + replaced + '&view=1&type=' + type;
            }
            if (typeof text != 'undefined') {
                window.location.href = URL_MAIN_PATH + '/search?q=' + replaced + '&view=1&type=' + type;
            }
        });
///**********not un use header search ***************///
        $('#mobile_headqsearch').typeahead(null, {
            displayKey: 'search',
            hint: false,
            limit: 10,
            source: searchNames.ttAdapter(),
            href: URL_MAIN_PATH + '/search?q={{search}}&type=' + type
        }).bind('typeahead:select', function (ev, suggestion) {
            var text = suggestion.search;
            var searchkey = text.toLowerCase();
            var replaced = searchkey.split(' ').join('+');
            if (typeof text != 'undefined') {
                window.location.href = URL_MAIN_PATH + '/search?q=' + replaced + '&view=1&type=' + type;
            }
        });
    }
});
// ******* filter clear ******* //
$('#clearfilter, #clearfilter_ajax').click(function () {
    clearfiltters();
});
//********Refer your friend*********//
function alreadyemail_friend(email, type) {

    if (!validateEmail(email)) {
        return false;
    }
    if (email != '') {
        $.ajax({
            type: 'GET',
            url: URL_LOGIN_PATH + '/getemail',
            dataType: 'jsonp',
            data: {
                emailid: email
            },
            crossDomain: true,
        }).done(function (e) {
            var countrows = e.cntrows;
            if (countrows > 0) {
                document.getElementById(type).style.color = "red";
                $('#' + type).html('Email id already exist.');
            } else {
                document.getElementById(type).style.color = "";
                $('#' + type).html('');
            }

        }).fail(function (error) {
            console.log(error.statusText);
        });
    }
}
function clearfiltters() {
    var cururl = window.location.href;
    var refurl = cururl.split("?")[0];
    var returnUrl = $("#resetPage").val();
//      console.log(returnUrl);
    if (returnUrl != '' && returnUrl != 'Undefined')
        refurl = returnUrl;
//    console.log(refurl);
    window.location.href = refurl;
    //  location.reload(refurl);
}
//********category show more script********//
function hidecategory1(cur, next, cate) {
    $('.hidedisplay').toggle('fast');
    $('.' + cur).hide();
    $('.' + next).show('slow');
//    $('.' + cate).show();
}
//********** Profile Selloffers ***********//
function showadditionaldetail(cur, hidediv, showdiv) {
    $('.' + cur).toggle('slow');
    $('.' + hidediv).hide();
    $('.' + showdiv).show();
}
/********* Show more category in Government forms************/
function morecategory(cur, next) {
    $('.moredisplay').toggle('fast');
    $('#' + cur).hide();
    $('#' + next).show('slow');
}
//--------------------------------------------------------------
function showcatclass(showclass, showclass1, hideclass) {
    $('.' + showclass + ', .' + showclass1).show('slow');
    $('.' + hideclass).hide();
}

function hidecatclass(hideclass, hideclass1, showclass) {
    $('.' + hideclass + ', .' + hideclass1).hide('slow');
    $('.' + showclass).show();
}
/*************Business letters- pdf format***********/
function downloadincrea(letid) {
    //    this.preventDefault();

    $.ajax({
        url: '/businessletter/adddownload-count',
        data: {
            letid: letid
        },
        type: 'post',
        success: function (e) {
            //            alert(e);
            $('#custom' + letid).text(e);
        }
    });
}
/******* Profile -add and edit service page- category select  *********/
function categoryselectservice(catid, divid, typeclass, catshowval) {
    $('.categoryshowview1').hide();
    $('.categoryshowview').show();
    $('#addserve_category').css({'margin-top': '0px'});
    $('#addserve_' + divid).css({'display': 'block'});
    // if (catid != '') {
    $.ajax({
        url: '/profile/services/categorylist',
        data: {
            parentid: catid,
            classname: typeclass
        },
        type: 'post',
        success: function (e) {
            $('#addserve_' + divid).html(e);
            if (divid == 'subcategory' && catid != '') {
                $('.categoryshowview').css('display', 'block');
                $('.categoryshowview').children().html('');
            }
            if (divid == 'subsubcategory' && catid != '') {
                $('.catshowsubsubsubcategory').html('');
            }
            $('.catshow' + divid).html(catshowval);
            if (divid != 'subsubsubcategory' && e != '') {
                $('.catshow' + divid).append("<strong>>></strong>");
            }
        }
    });
    // }
}
/******* Profile -add and edit Buying need page- category select  *********/
function categoryselectbuyingneeds(catid, divid, typeclass, catshowval) {
    $('#buyer_category').css({'margin-top': '0px'});
    $('#buyer_' + divid).css({'display': 'block'});
    $('.categoryshowview').show();
    $.ajax({
        url: '/profile/buyingneeds/categorylist',
        data: {
            parentid: catid,
            classname: typeclass
        },
        type: 'post',
        success: function (e) {
            $('#buyer_' + divid).html(e);

            if (divid == 'subcategory') {
                $('.categoryshowview1').html('');
                $('.catshowsubsubcategory').html('');
                $('.catshowsubsubsubcategory').html('');
            }
            if (divid == 'subsubcategory') {
                $('.catshowsubsubsubcategory').html('');
            }
            $('.catshow' + divid).html(catshowval);
            if (divid != 'subsubsubcategory' && e != '') {
                $('.catshow' + divid).append("<strong>>></strong>");
            }
        }
    });
}
/*** category search view ***/

$(function () {
    var product_category = $('#product_category select').val();

    if (product_category == 23) {
        $('#halal_block').show();
    } else {
        $('#halal_block').hide();
        $('#halal_details').addClass('hide');
    }
});
function categoryselect(catid, divid, typeclass, catshowval) {
    $('#category_search').val('');
    $('.categoryshowview').show();
    $('#product_category').css({'margin-top': '0'});
    $('#product_' + divid).css({'display': 'block'});
    $.ajax({
        url: '/products/categorylist',
        data: {
            parentid: catid,
            classname: typeclass
        },
        type: 'post',
        success: function (e) {

            if (catid == 23) {
                if (divid == 'subcategory') {
                    $('#halal_block').show();
                    if ($('#halalproductadd').is(':checked')) {
                        $('#halal_details').show().removeClass('hide');
                    }
                } else {
                    $('#halal_block').hide();
                    $('#halal_details').hide();
                }
            } else {
                if (divid == 'subcategory') {
                    $('#halal_block').hide();
                    $('#halal_details').hide();
                }
            }

            $('#product_' + divid).html(e);

            if (divid == 'subcategory') {
                $('.categoryshowview1').html('');
                $('.catshowsubsubcategory').html('');
                $('.catshowsubsubsubcategory').html('');
            }
            if (divid == 'subsubcategory') {
                $('.catshowsubsubsubcategory').html('');
            }
            $('.catshow' + divid).html(catshowval);
            if (divid != 'subsubsubcategory' && e != '') {
                $('.catshow' + divid).append("<strong>>></strong>");
            }
        }
    });
}
/******* Profile -Service category view page- category select  *********/
function servicecategoryselect(catid, divid, typeclass, catshowval) {
    $('.categoryshowview').hide();
    $('#addserve_category').css({'margin-top': '0'});
    $('#addserve_' + divid).css({'display': 'block'});
    $.ajax({
        url: '/services/categorylist',
        data: {
            parentid: catid,
            classname: typeclass
        },
        type: 'post',
        success: function (e) {
            $('#addserve_' + divid).html(e);

            if (divid == 'subcategory') {
                $('.categoryshowview1').html('');
                $('.catshowsubsubcategory').html('');
                $('.catshowsubsubsubcategory').html('');
            }
            if (divid == 'subsubcategory') {
                $('.catshowsubsubsubcategory').html('');
            }
            $('.catshow' + divid).html(catshowval);
            if (divid != 'subsubsubcategory' && e != '') {
                $('.catshow' + divid).append("<strong>>></strong>");
            }
        }
    });
}
/*** Category select - show list ***/
function showcategorysearch() {
    $('#category').attr("required", "required");
    $('#category1').val('');
    $('#category1').removeAttr("required");
    if ($('#subcategorydiv').length) {
        $('#subcategorydiv').attr("required", "required");
    }
    if ($('#subsubcategorydiv').length) {
        $('#subsubcategorydiv').attr("required", "required");
    }
    $('.categoryshowview1').html('');
    $('.searchselectdiv').show();
    $('.searchselectdiv1').hide();
//    $('.errortext').show(0).delay(1000).hide(0);
    $('#service_choose_cat').show();
}
/*** Ecomm Product - minimum order quantity ***/
function hideminqty(id) {
    if ($('#' + id).is(":checked")) {
        $('#min_order_quantity').hide();
        $('#min_order_qty').val('');
        $('#min_order_unit').val('');
    } else {
        $('#min_order_quantity').show();
        var value = $("#production_capacity_unit").val();
        $("#min_order_unit").val(value);
    }
}
/*** Category search option in profile ***/
function productcatshowview(val, type) {
    var category1 = $('#category1').val();
    var slipt_category1 = category1.split(',');
    if (slipt_category1[0] == 23) {
        $('#halal_block').show();
        if ($('#halalproductadd').is(':checked')) {
            $('#halal_details').show().removeClass('hide');
        }
    } else {
        $('#halal_block').hide();
        $('#halal_details').hide();
    }
    if (type == 1) {
        $('.categoryshowview1').html(val);
        $('#category1').hide(100);
    }
}
/// Search category option in profile ///
function searchcategoryselect(value, divid) {
    $('#product_category').css({'margin-top': '0'});
    $('.categoryshowview').hide();
    var searchlen = value.length;
    var perload = URL_CDN_PATH + '/assets/img/prof_load.gif';

    if (searchlen >= 3) {
        $('#' + divid).html("<img src=" + perload + " />");
        $('.searchselectdiv').hide();
        $('.searchselectdiv1').show();
        $('.errortext').hide();

        $('#category').removeAttr("required");
        $('#category').val('');
        if ($('#subcategorydiv').length) {
            $('#subcategorydiv').removeAttr("required");
            $('#subcategorydiv').val('');
        }
        if ($('#subsubcategorydiv').length) {
            $('#subsubcategorydiv').removeAttr("required");
            $('#subsubcategorydiv').val('');
        }
        $.ajax({
            url: '/products/searchcategorylist',
            data: {
                searchtext: value
            },
            type: 'post',
            success: function (e) {
                if ($.trim(e.charAt(0)) == 0 && $.trim(e.charAt(0)) != '') {
                    $('.errortext').show();

                    showcategorysearch();
                } else {
                    $('#' + divid).html(e);
                    var search_catediv = $('#search_catediv').val();
                    if (search_catediv == 1)
                        $('.noresfound').css({'display': 'none'});
                    $('.errortext').hide();
                }
            }
        });
    } else {
        $('.errortext').show();
    }
}
/// profile add service category ///
function searchservicecategoryselect(value, divid) {
    $('.categoryshowview1').show();
    $('.categoryshowview').hide();
    //$('.categoryshowview').children().html('');
    var searchlen = value.length;
    var perload = URL_CDN_PATH + '/assets/img/prof_load.gif';
    if (searchlen >= 3) {
        $('#' + divid).html("<img src=" + perload + " />");
        $('.searchselectdiv').hide();
        $('.searchselectdiv1').show();
        $('.errortext').hide();

        $('#category').removeAttr("required");
        $('#category').val('');
        if ($('#subcategorydiv').length) {
            $('#subcategorydiv').removeAttr("required");
            $('#subcategorydiv').val('');
        }
        if ($('#subsubcategorydiv').length) {
            $('#subsubcategorydiv').removeAttr("required");
            $('#subsubcategorydiv').val('');
        }
        $.ajax({
            url: '/services/searchcategorylist',
            data: {
                searchtext: value
            },
            type: 'post',
            success: function (e) {
                if ($.trim(e.charAt(0)) == 0 && $.trim(e.charAt(0)) != '') {
                    $('.errortext').show();
                    showcategorysearch();
                } else {
                    $('#' + divid).html(e);
                    var search_catediv = $('#search_catediv').val();
                    if (search_catediv == 1)
                        $('.noresfound').css({'display': 'none'});
                    $('.errortext').hide();
                }
            }
        });
    } else {
        $('.errortext').show();
        $('.categoryshowview1').hide();
    }
}

/// profile Buyingneed category select ///
function searchbuyingneedscategoryselect(value, divid) {
//    $('.categoryshowview').children().html('');
    $('#buyer_category').css({'margin-top': '0'});
    $('.categoryshowview').hide();
    var searchlen = value.length;
    var perload = URL_CDN_PATH + '/assets/img/prof_load.gif';

    if (searchlen >= 3) {
        $('#' + divid).html("<img src=" + perload + " />");
        $('.searchselectdiv').hide();
        $('.searchselectdiv1').show();
        $('.errortext').hide();

        $('#category').removeAttr("required");
        $('#category').val('');
        if ($('#subcategorydiv').length) {
            $('#subcategorydiv').removeAttr("required");
            $('#subcategorydiv').val('');
        }
        if ($('#subsubcategorydiv').length) {
            $('#subsubcategorydiv').removeAttr("required");
            $('#subsubcategorydiv').val('');
        }
        $.ajax({
            url: '/profile/buyingneeds/searchcategorylist',
            data: {
                searchtext: value
            },
            type: 'post',
            success: function (e) {

                if ($.trim(e.charAt(0)) == 0 && $.trim(e.charAt(0)) != '') {
                    $('.errortext').show();

                    showcategorysearch();

                } else {
                    $('#' + divid).html(e);
                    var search_catediv = $('#search_catediv').val();
                    if (search_catediv == 1)
                        $('.noresfound').css({'display': 'none'});
                    $('.errortext').hide();
                }
            }
        });
    } else {
        $('.errortext').show();
    }
}
/**** end category search view ****/
/**** Profile - product specification*****/
function checkdupelement(val, id) {
    var taskArray = new Array();
    $('.addspecarray').each(function () {
        if (val != '') {
            taskArray.push($.trim($(this).val().toLowerCase()));
        }
    });
    taskArray.splice($.inArray($.trim(val.toLowerCase()), taskArray), 1);
    arrfound = $.inArray($.trim(val.toLowerCase()), taskArray);

    if (arrfound >= 0) {
        $('#' + id).val('');
        $('.specerror').show();
    } else {
        $('.specerror').hide();
    }
}
/**** Profile- product ecommerce *****/
function producttradecheck(val) {
    if (val == 2) {
        $('.tradeinb').show();
        $('.tradeina').hide();
        $('.tradeinb input[type="text"]').val('');
        $('.tradeinb select option').prop('selected', false);
    } else {
        $('.tradeina').show();
        $('.tradeinb').hide();
        $('.tradeina input[type="text"]').val('');
        $('.tradeina select option').prop('selected', false);
    }
}
function tradespecification(type, val) {
    var partval = +val - +1;

    if (type == 'add') {
        //        if (partval != 1) {
        $('.tradeaddspecshow' + partval).hide();
        //        }
        $('.tradespec' + val).show();
        //        $('.tradeina').hide();
    } else {
        $('.tradespec' + val).hide();
        $('.trademoqminqty' + val).val('');
        $('.tradeaddspecshow' + partval).show();
        //        $('.tradeinb').hide();
    }
}

//function complaintypelist(divid, catid) {
////    $.ajax({
////        url: URL_PRODUCTS_PATH + '/complaintcategorylist',
////        data: {
////            parentid: catid,
////        },
////        type: 'post',
////        success: function (e) {
////            $('#' + divid).html(e);
////        }
////    });
////
//    $.ajax({
//        type: 'GET',
//        url: URL_PRODUCTS_PATH + '/complaintcategorylist.html',
//        dataType: 'jsonp',
//        data: {
//            parentid: catid
//        },
//        crossDomain: true,
//    }).done(function (e) {
//       // console.log(e);
//
//        $('#' + divid).html(e);
//
//    }).fail(function (error) {
//        console.log(error.statusText);
//    });
//
//}
/*** Buyers category ****/
function getBuyersCategories(str, str1, str2, page, slug, sub_slug, country_code, country_slug) {
    $.ajax({
        type: 'post',
        url: '/buyers/getBuyersCagory',
        data: {
            catname: str,
            parent_id: str1,
            screen_type: str2,
            page: page,
            slug: slug,
            sub_slug: sub_slug,
            country_code: country_code,
            country_slug: country_slug
        },
        dataType: 'html',
        success: function (output) {
            $('#parent_category_name').html(output);
            $('#parent_category_name1').html(output);
        }
    });
}
/*** Buying needs category ****/
function getBuyingNeedsCategories(str, str1, str2, page, slug, sub_slug, country_code, country_slug) {
    $.ajax({
        type: 'post',
        url: '/buyingneeds/getBuyingNeedCagory',
        data: {
            catname: str,
            parent_id: str1,
            screen_type: str2,
            page: page,
            slug: slug,
            sub_slug: sub_slug,
            country_code: country_code,
            country_slug: country_slug
        },
        dataType: 'html',
        success: function (output) {
            $('#parent_category_name').html(output);
            $('#parent_category_name1').html(output);
        }
    });
}

function showmr_scrll() {
    $('.prod-category').animate({
        scrollTop: '+=150'
    }, 500);
}
/******* to get subcategories *****/
function getSubCategories(str) {
    $.ajax({
        type: 'post',
        url: 'getCagoryId',
        data: {
            catid: str
        },
        dataType: 'html',
        success: function (output) {
            //console.log(output);
            $('#sub_categories').html(output);
        }
    });
}
/******* to get subsubcategories *****/
function getSubSubCategories(str) {
    //console.log(str);
    $.ajax({
        type: 'post',
        url: 'getsubcagoryid',
        data: {
            catid: str
        },
        dataType: 'html',
        success: function (output) {
            $('#sub_sub_category').html(output);
        }
    });
}
/****** Show category in buyers & buying needs******/
function showcategory(str, str1) {
    $('.' + str).show();
    $('.' + str).addClass('fading in');
    // $('html body').animate({scrollTop: $('.' + str).offset().top}, 1000);
    $('.' + str1).hide();
}
/****** Hide category in  City, Business letters, Video News,Govt forms, Supplier, Service provider, Promotional videos ******/
function hidecategory(cur, next) {
    $('.hidedisplay').toggle('fast');
    $('.' + cur).hide();
    $('.' + next).show('slow');
}
/****** Hide category in buyers & buying needs******/
function hidecategorynew(str, str1) {
    $('.' + str).hide();
    $('.' + str).removeClass('fading');
    $('.' + str1).show('slow');
}
$(document).ready(function () {
//     if ($('#combooffersjson').length) {
//    var comboofferval=$('#combooffersjson').val();
//      var combojson=JSON.parse(comboofferval);
//   console.log(comboofferval);
//   console.log(combojson);

//     }
//**** Search bar with enter key option****//
// for home
    $('#category_search').keypress(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            searchcategoryselect($('#category_search').val(), 'searchcatappend');
            return false;
        }
    });
// service category
    $('#scategory_search').keypress(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            searchservicecategoryselect($('#scategory_search').val(), 'searchcatappend');
            return false;
        }
    });
// profile service category
    $('#categoryserv_search').keypress(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            searchservicecategoryselect($('#categoryserv_search').val(), 'searchcatappend');
            return false;
        }
    });
// profile Buying need category
    $('#category_buy_search').keypress(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            searchbuyingneedscategoryselect($('#category_buy_search').val(), 'searchcatappend');
            return false;
        }
    });
    $('#demo_ref').click(function () {
        window.location.reload(true);
    });
});
/**** Profile - Combo offer*****/
$(function () {
    if ($('#combooffersjson').length) {
        var comboofferval = $('#combooffersjson').val();
        var productid = $('#comboproductid').val();
        var combojson = JSON.parse(comboofferval);

        $.ajax({
            type: 'post',
            url: '/comboofferlisting',
            data: {
                comboofferid: combojson[0].id,
                productid: productid
            },
            success: function (e) {
                $('#combooffer1').html(e);
            }
        });
    }
});
function getcombooffers(offid, divid, productid) {
    $.ajax({
        type: 'post',
        url: '/comboofferlisting',
        data: {
            comboofferid: offid,
            productid: productid
        },
        success: function (e) {
            $('#combooffer' + divid).html(e);
        }
    });
}
//****** Detail view page - product zoom effect******//
if ($('#zoom_01').length) {
    var image = document.getElementById('zoom_01');
    var cuswid, cusheig;
    var imgwid = image.naturalWidth;
    var imgheg = image.naturalHeight;
    var w = window.innerWidth;
    if (w > 991) {
        var cc = imagedimension(imgwid, imgheg);
        cuswid = cc[0];
        cusheig = cc[1];
        if (imgwid > 400) {
            imagezoomerproduct(cuswid, cusheig);
            imageclick();
        } else {
            imageclick();
        }
    } else {
        $(".detpro").click(function () {
            var mainImage = $(this).attr("src"); // Find Image URL
            var imgLink = $(this).children('img').attr('rel'); // Find the image link in rel
            var imgTitle = $(this).attr('title');
            $("#det_view").html('<img id="zoom_01" src="' + mainImage + '" class="galleryThumb img-responsive" title="' + imgTitle + '" alt="' + imgTitle + '" />');
        });
    }
}
//******* detail page - product img gallery*********//
function imageclick() {
    $(".detpro").click(function () {
        var mainImage = $(this).attr("src"); // Find Image URL
        var imgLink = $(this).children('img').attr('rel'); // Find the image link in rel
        var imgTitle = $(this).attr('title');
        $("#det_view").html('<img id="zoom_01" src="' + mainImage + '" class="galleryThumb img-responsive" title="' + imgTitle + '" alt="' + imgTitle + '" />');
        var imgwid1 = $(this).children('img').prop('naturalWidth');
        var tmpImg = new Image();
        var imageWidth, imageHeight, cc;
        tmpImg.src = mainImage; //or  document.images[i].src;
        $(tmpImg).on('load', function () {
            imageWidth = tmpImg.width;
            imageHeight = tmpImg.height;
            cc = imagedimension(imageWidth, imageHeight);
            cuswid = cc[0];
            cusheig = cc[1];
            if (cuswid >= 400) {
                imagezoomerproduct(cuswid, cusheig);
            }
        });
    });
}
function imagedimension(imgwid, imgheg) {
    var cuswid, cusheig;
    if (imgwid >= 400 && imgheg >= 400) {
        cuswid = 400;
        cusheig = 400;
    } else {
        if (imgwid >= 400) {
            cuswid = 400;
        } else {
            cuswid = imgwid;
        }
        if (imgheg >= 400) {
            cusheig = 400;
        } else {
            cusheig = imgheg;
        }
    }
    return [cuswid, cusheig];
}

function imagezoomerproduct(cuswid, cusheig) {
    $("#zoom_01").ezPlus({
        gallery: 'gallery_01',
        //    tint:true,
        //    tintColour:'#000', tintOpacity:0.5,
        zoomWindowHeight: 250,
        zoomWindowWidth: 250,
        //    zoomWindowPosition:1,
        //    zoomWindowPosition: "demo-container",
        responsive: true,
        scrollZoom: true,
        borderSize: 0,
        easing: true,
        cursor: 'pointer',
        galleryActiveClass: 'active',
        imageCrossfade: true
    });
    $("#zoom_01").bind("click", function (e) {
        var ez = $('#zoom_01').data('elevateZoom');
        $.fancybox(ez.getGalleryList());
        return false;
    });
}
///////////// end of detail page-Image hover effect /////////////////
//function AddFileUpld(fname){
//    var filelist=$('#filelist').val();
//    $.ajax({
//         url: "../products/imageupload",
//        data: {
//            filelist: filelist,
//            fname: fname
//        },
//
//        type: "post",
//        success: function (e) {
//            $('#filelist').val(e);
//        //            console.log(e);
//        }
//    });
//}
///// product specification ////
function getidspec(idspec) {
    var idspeca = idspec + 1;
    $("#prodctspecdev").children().each(function (n, i) {
        var id = this.id;
    });
    //    if($('#genspec'+idspeca).length){
    //
    //    }
    //        return idspeca;
}
///// refer your friend ///
function morefriends(id, inc, id1, rid) {
    var inc1 = +inc + +1;
    var inc2 = +inc - +1;
    var cc, parentiddis, par;
    var lastid = $('#referfrnddiv').children().last().attr('id');
    var lastidnum = lastid.substr(lastid.indexOf("_") + 1);
    // console.log(lastidnum);
    if (id == 'add-more-frnd') {
        cc = +lastidnum + +1;
        $('#morefriend_' + inc1).removeClass('no-display');
        $('#remove-frnd_' + inc).removeClass('no-display');
        $('#add-more-frnd' + inc).addClass('no-display');
        if (cc <= 10) {
            $.ajax({
                type: 'post',
                url: '/addmore-friend',
                data: {
                    frnd: cc
                },
                dataType: 'html',
                success: function (output) {
                    $('#' + id + inc).hide();
                    $('#referfrnddiv').append(output);
                }
            });
        }
    } else if ((id == 'remove-frnd' && inc != 1)) {
        parentiddis = $('#remove-frnd_' + inc).parent().prev().find('.removefrndshow').attr('id');
        $('#' + id1 + inc).remove();
        par = parentiddis.substr(parentiddis.indexOf("_") + 1);
        $('#' + rid + inc2).show();
        if ($('#add-more-frnd' + lastidnum).is(':visible')) {

            $('#add-more-frnd' + par).hide();
        } else {
            $('#add-more-frnd' + lastidnum).show();
            if (lastidnum == 10) {
                $('#add-more-frnd' + lastidnum).hide();
            }
        }
        $('#' + id + inc).hide();
    }
}
////start of location calculate - layout.php ///
function cityLocation(latitude, longitude, city, divid) {
    //    console.log(divid);
    var myCenter = new google.maps.LatLng(latitude, longitude);
    var mapProp = {
        center: myCenter,
        zoom: 13,
        panControl: true,
        zoomControl: true,
        scaleControl: true,
        scrollwheel: false,
        streetViewControl: true,
        overviewMapControl: true,
        rotateControl: true,
        mapTypeControl: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById('city-location-map'), mapProp);
    var marker = new google.maps.Marker({
        position: myCenter,
    });
    marker.setMap(map);
    var infowindow = new google.maps.InfoWindow({
        content: city
    });
    google.maps.event.addListener(marker, 'click', function () {
        infowindow.open(map, marker);
    });
}

function seaLocation(latitude, longitude, seaname, divid) {
    //    console.log(divid);
    var myCenter = new google.maps.LatLng(latitude, longitude);
    var mapProp = {
        center: myCenter,
        zoom: 13,
        panControl: true,
        zoomControl: true,
        scaleControl: true,
        scrollwheel: false,
        streetViewControl: true,
        overviewMapControl: true,
        rotateControl: true,
        mapTypeControl: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById('sea-location-map'), mapProp);
    var marker = new google.maps.Marker({
        position: myCenter,
    });
    marker.setMap(map);
    var infowindow = new google.maps.InfoWindow({
        content: seaname
    });
    google.maps.event.addListener(marker, 'click', function () {
        infowindow.open(map, marker);
    });

}

function airLocation(latitude, longitude, airname, divid) {
    //    console.log(divid);
    var myCenter = new google.maps.LatLng(latitude, longitude);
    var mapProp = {
        center: myCenter,
        zoom: 13,
        panControl: true,
        zoomControl: true,
        scaleControl: true,
        scrollwheel: false,
        streetViewControl: true,
        overviewMapControl: true,
        rotateControl: true,
        mapTypeControl: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById('air-location-map'), mapProp);
    var marker = new google.maps.Marker({
        position: myCenter,
    });
    marker.setMap(map);
    var infowindow = new google.maps.InfoWindow({
        content: airname
    });
    google.maps.event.addListener(marker, 'click', function () {
        infowindow.open(map, marker);
    });
}
///////////////////// end of location /////////////
//-----------------------------------------------------------------------------------------------------
function deleteproduct(statusdelet) {
    var confirmuser = confirm('Are you sure you want to delete this');
    if (confirmuser == false) {

    } else {
        var blkstr = [];
        var blkstr1 = [];
        var cbs1 = document.getElementsByName('selectall[]');
        for (var i = 0; i < cbs1.length; i++) {
            if (cbs1[i].checked == true) {
                var cb = cbs1[i].value;
                blkstr1.push(cb);
            }
        }
        var selected_vals = blkstr1.join(",");
        $('#deleteid').val(selected_vals);
        var deleteid = $('#deleteid').val();
        var typecheck = $('#typesta').val();
        if (deleteid == '') {
            alert("Choose any one to delete");
        } else {
            $.ajax({
                url: '/profile/' + typecheck + '/deleteproduct',
                type: 'post',
                dataType: 'text',
                data: {
                    deleteid: deleteid,
                    actiondelete: 'user',
                    statusdelet: statusdelet
                },
                success: function (output) {
                    var text = output;
                    var obj = JSON.parse(text);
                    if (obj.message) {
                        $('#success_div').html(obj.message).show();
                    } else {
                        $('#success_div').html('').hide();
                    }
                }

            });
        }
    }
}
/************** Script starts for validating upload file type & size **************/

var app = app || {};

// Utils
(function ($, app) {
    'use strict';
    app.utils = {};
    app.utils.formDataSuppoerted = (function () {
        return !!('FormData' in window);
    }());
}(jQuery, app));

// Parsley validators
(function ($, app) {
    'use strict';

    window.Parsley
            .addValidator('filemaxmegabytes', {
                requirementType: 'string',
                validateString: function (value, requirement, parsleyInstance) {
                    if (!app.utils.formDataSuppoerted) {
                        return true;
                    }
                    var file = parsleyInstance.$element[0].files;

                    var maxBytes = requirement * 1048576;
                    if (file.length == 0) {
                        return true;
                    }
                    return file.length === 1 && file[0].size <= maxBytes;
                },
                messages: {
                    en: 'Upload file within %s MB'
                }
            })
            .addValidator('filemimetypes', {
                requirementType: 'string',
                validateString: function (value, requirement, parsleyInstance) {
                    if (!app.utils.formDataSuppoerted) {
                        return true;
                    }
                    var file = parsleyInstance.$element[0].files;
                    if (file.length == 0) {
                        return true;
                    }
                    var allowedMimeTypes = requirement.replace(/\s/g, "").split(',');
                    return allowedMimeTypes.indexOf(file[0].type) !== -1;
                },
                messages: {
                    en: 'Invalid File Selection'
                }
            });
}(jQuery, app));
if ($('#addapply_job').length) {
    $('#addapply_job').parsley();
}


/************** Script ends for validating upload file type & size **************/
//function getParentCategoriesProduct(str,type,parent,country,countrycode,countryslug) {
//    // console.log(str);
//    $.ajax({
//        type: 'post',
//        url: '/getCategrySearch',
//        data: {catname: str,cattype:type,parentid:parent,countrypag:country,countrycode:countrycode,countryslug:countryslug},
//        dataType: 'html',
//        success: function (output)
//        {
//            $('#categoryserchdiv').html(output);
//
//        }
//    });
//}
/******* Profile -add and edit Buying need page- category select  *********/
function categoryselectbuyingneed(catid, divid, typeclass) {
//    console.log(catid);
    $.ajax({
        url: '/categorylist',
        data: {
            parentid: catid,
            classname: typeclass
        },
        type: 'post',
        success: function (e) {
            $('#' + divid).html(e);
        }
    });
}
//******* Select city list*******//
$(function () {
    var url = URL_MAIN_PATH + '/search/api/city/press-media-search';
    $("#selectCity").select2({
        placeholder: 'Enter city name',
        multiple: false,
        selectOnClose: true,
        tokenSeparators: [","],
        delay: 250,
        ajax: {
            url: url,
            dataType: 'json',
            quietMillis: 500,
            data: function (params) {
                return {
                    city: params.term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 3
    });
});

//$(function () {
//    $('#select2-selectCity-container').bind("click", function () {
//        $('html, body').animate({
//            scrollTop: $('#scroll_city').offset().top
//        }, 'slow');
//    });
//});

$(function () {
//    console.log("country");
    var mem_country = MEMBER_COUNTRY;
    var url = URL_MAIN_PATH + '/search/api/country/search?country_code=' + mem_country;
    $("#profileCity").select2({
        placeholder: 'Type in your City',
        multiple: false,
        delay: 250,
        ajax: {
            url: url,
            dataType: 'json',
            quietMillis: 500,
            data: function (params) {
                return {
                    city: params.term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        minimumInputLength: 3
    });
});
//**** Template list view- choose Template*****//
function addtemplateuser(val) {
    $.ajax({
        url: '/create-website/templatesadd',
        type: 'post',
        data: {
            templateid: val
        },
        success: function (e) {
            $('#signupwebsite').html(e);
            if ($('#websitereg').length) {
                window.location.href = '?signup';
//                $('#websitereg').modal({backdrop: 'static'});
//                $('#websiteregform').parsley();
            } else {
                window.location.href = URL_MAIN_PATH + '/create-website/domain';
            }
        }
    });
}
//**** Template list view- Demo Template button*****//
function addtemplateuserdemo(val) {
    $.ajax({
        url: '/create-website/templatedemosadd',
        type: 'post',
        data: {
            templateid: val
        },
        success: function (e) {
            $('#signupwebsite').html(e);

            if ($('#websitereg').length) {
                window.location.href = '?signup';
//                $('#websitereg').modal({backdrop: 'static'});
//                $('#websiteregform').parsley();
            }
//            var href = $('#dem').val();
//            console.log(href);
//            window.open(href, '_blank');
//            document.location.reload(href);
        }
    });
}

//***********customised seo - for template***********
$('.make-switch .btn-toggle').click(function () {
    $(this).find('.btn').toggleClass('seoved');
    var seoid = $('#seoswitch').val();
    if (seoid == '0') {
        $('.custseo-forms').find('.custseo-overlay').addClass('disp');
    } else {
        $('.custseo-forms').find('.custseo-overlay').removeClass('disp');
    }
});

$('.make-switch .onbut').click(function () {
    $('#seoswitch').attr('value', '0');

    $.ajax({
        url: '/create-website/set_seo_default',
        data: {
            seoid: '0'
        },
        type: 'get',
        success: function (e) {
        }
    });
});
$('.make-switch .offbut').click(function () {
    $('#seoswitch').attr('value', '1');
    $.ajax({
        url: '/create-website/set_seo_default',
        data: {
            seoid: '1'
        },
        type: 'get',
        success: function (e) {
        }
    });
});

//function openWindowReload(link) {
////    var href = link.href;
////  window.open(href, '_blank');
////   window.location.href = window.open(link, '_blank');
//    document.location.reload(true);
//}
//****** Get company slug *******//
function getcompanyslug(val) {
    if (val.length > 2) {
        $.ajax({
            url: '/create-website/templatecompslug',
            type: 'post',
            data: {
                companyslug: val
            }, success: function (e) {

                $('#cmpny_slug').val(e);

            }
        });
    }
}
$(document).ready(function (e) {
    $(document).on('click', '.webxhrModal', function (e) {
        webopenAjaxModel($(this), e);
    });
    if ($('#usertypecheck').length) {
        $('#usertypecheck').modal({backdrop: 'static'});
    }
});
//*****Hidden function******//
function changeTemplate(val) {
    $.ajax({
        url: '/create-website/templatelist',
        type: 'post',
        data: {
            categoryid: val
        }, success: function (e) {

            $('#webtemplatechange').html(e);

        }
    });
}
/// shoose your template button- template.php
function destroysessionweb() {
    $.ajax({
        url: '/create-website/destroysessionweb',
        type: 'post',
        success: function (e) {

            location.reload();

        }
    });
}

function urlExists(url, id) {
//    console.log('asdf');
    $.ajax({
        url: URL_PROFILE_PATH + 'checkvalidurl',
        data: {url: url},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            var succval = output.status;
//            console.log(succval);
            if (succval == 'no') {

            } else if (succval < 400 && succval != 0) {

            } else {
                $('#defaultimagelink_' + id).val('');
                alert('invalid hyperlink');
            }
        }
    });
}
/// template cutomised banner //
function checkcustombanner(id, idnum) {
    var cusban = $('#defaultfile_' + idnum).val();
    var image = $('#defaultimage_' + idnum).val();

    if ($('#' + id).is(":checked")) {
        $('#' + id).val(1);
        $('#defaultfile_' + idnum).val('');
        $('#defaultimagelink_' + idnum).val('');
        $('#imagelinklabel').css('display', 'none');
        $('#defaultimagelink_' + idnum).css('display', 'none');
        $('#' + id).prop('checked', true);
        $('#imgview' + idnum).attr('src', image);
    } else {
        $('#' + id).val(0);
        if (cusban == '') {
            $('#' + id).val(1);
            $('#' + id).prop('checked', true);
            $('#imgview' + idnum).attr('src', image);
        }
    }
}
// template customise banner - image //
function checkcustomfileimage(idnum) {
//    var imglink = $('#defaultimagelink_' + idnum).val();
    var iSize = ($('#defaultfile_' + idnum)[0].files[0].size / 1000);
    var filename = $('#defaultfile_' + idnum)[0].files[0].name;
    var extension = filename.substr(filename.lastIndexOf('.') + 1).toLowerCase();
    if (iSize > 2000) {
        alert("Sorry! Image size exceeds 2 MB");
        $("#defaultfile_" + idnum).val('');
    } else if (extension == 'gif' || extension == 'png' || extension == 'jpeg' || extension == 'jpg' || extension == 'GIF' || extension == 'PNG' || extension == 'JPG' || extension == 'JPEG') {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgview' + idnum).attr('src', e.target.result);
        }
        reader.readAsDataURL($('#defaultfile_' + idnum)[0].files[0]);
        $('#defaultoption_' + idnum).val(0);
        $('#defaultoption_' + idnum).prop('checked', false);
//        if (imglink != '') {
        $('#imagelinklabel').css('display', 'block');
        $('#defaultimagelink_' + idnum).css('display', 'block');
//        } else {
//            $('#defaultimagelink_' + idnum).css('display', 'block');
//        }
    } else {
        alert('Invalid File Fortmat! Please upload only .gif, .png,.jpeg, .jpg');
        $("#defaultfile_" + idnum).val('');
    }
}
///// post your product form to chack email already exist /////
function emailalreadyexistsservice(emailvalue) {
    if (emailvalue != '') {
        $.ajax({
            url: URL_MAIN_PATH + '/emailalreadyexistservice',
            data: {emailvalue: emailvalue},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                var succval = output.succ_val;
                if (succval == 1) {
                    $('#already_serv_exist').html('You cannot post product as a service provider');
                    $('#oldemail').val('');
                    $('#oldemail').focus();
                    setTimeout(function () {
                        $('#already_serv_exist').html('');
                    }, 3000);
                } else {
                    $('#already_serv_exist').html('');
                }
            }
        });
    }
}
function emailalreadyexistsproducts(emailvalue) {

    if (emailvalue != '') {
        $.ajax({
            url: URL_MAIN_PATH + '/emailalreadyexistproduct',
            data: {emailvalue: emailvalue},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                var succval = output.succ_val;
                if (succval == 1) {
                    $('#already_serv_exist').html("You cannot post service as a supplier");
                    $('#oldemail').val('');
                    $('#oldemail').focus();
                    setTimeout(function () {
                        $('#already_serv_exist').html('');
                    }, 3000);
                } else {
                    $('#already_serv_exist').html('');
                }
            }
        });
    }
}
// to check email id//
function getcountryemailexist(emailvalue) {

    if (emailvalue != '') {
        $.ajax({
            url: URL_MAIN_PATH + '/getcountryemailexist',
            data: {emailvalue: emailvalue},
            dataType: 'json',
            type: 'post',
            success: function (output) {
//                console.log(output);
                var ctry_id = output.country_id;
//                var ctry_location = output.location;
                if (ctry_id == '') {
                    $('#meMCountry').show('fast');
                    $("#post_country1").attr('required', 'required');
                } else {
                    $('#meMCountry').hide('fast');
                    $("#post_country1").removeAttr('required');
                }
            }
        });
    }
}
//// press media business- attach tarrif ////
$('#attach_tarrif').change(function () {
    var filename = document.getElementById('attach_tarrif').value;
    var extension = filename.substr(filename.lastIndexOf('.') + 1).toLowerCase();
    if (extension == 'gif' || extension == 'png' || extension == 'jpeg' || extension == 'jpg' || extension == 'rtf' || extension == 'doc' || extension == 'docx' || extension == 'xlsx' || extension == 'xls' || extension == 'rtf' || extension == 'txt' || extension == 'zip' || extension == 'rar' || extension == 'pdf') {
        var iSize = ($("#attach_tarrif")[0].files[0].size / 1000);
        if (iSize > 2000) {
            alert("Sorry! File size exceeds 2MB");
            $("#attach_tarrif").val('');
            // $("#img_val").html('');
        }

        var img_value = $('#attach_tarrif').val();
        var img_name = ($('#attach_tarrif')[0].files[0].name);
        var subst_value = img_name.substr(0, 25);
        var nn = img_name.split(".");
        var img_type = nn.pop();
        var imgname = img_name.substr(0, img_name.indexOf("."));
        var img_name1 = img_name.substr(0, 5) + "....." + img_type;
        // $("#img_val").html(img_name1);

    } else if (filename == "") {
        //$("#img_val").html('');
        $("#attach_tarrif").val('');
    } else {
        alert('Upload only jpg, jpeg, png, gif, xlsx, xls, doc, docx, pdf, rtf, txt, zip, rar files are allowed. Maximum file size is 2MB.');
        // $("#img_val").html('');
        $("#attach_tarrif").val('');
    }

});

//   function unsunscribe() {
//        var redirect = $('#redirect').val();
//        if(redirect){
//       alert();

//        }
//    }
$(function () {
    if (typeof commentScroll != 'undefined') {


        $('html, body').animate({scrollTop: $(".commentSection").offset().top - 200 + 'px'}, 1500);
        //$(window).scrollTop($('.commentSection').offset().top);
        // $("html, body").animate({ scrollTop: $(document).height() }, 1000);
    }
})
function changeimage(id) {
    $('#' + id).click();
}
function readURL(input, div) {
    if (input.files.length > 0) {
        var extension = input.files[0].name.split('.').pop().toLowerCase();
        if (input.files && input.files[0] && (extension == 'jpg' || extension == 'JPG' || extension == 'jpeg' || extension == 'JPEG' || extension == 'png' || extension == 'PNG' || extension == 'gif' || extension == 'GIF')) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#' + div).attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            } else {
                if (typeof old_imgpromo != 'undefined' && old_imgpromo != '') {
                    $('#' + div).attr('src', URL_UPLOADS_PATH + '/' + old_imgpromo);
                } else {
                    $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
                }
            }
        } else {

            $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
        }
    } else {
        $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
    }
}

function readBannerImage(images, srclogo) {
    var filename = $('#' + images).val();
    var max_width = $('#banner_width').val();
    var max_height = $('#banner_height').val();
    if (filename != '') {
        var extension = filename.substr(filename.lastIndexOf('.') + 1).toLowerCase();
        if (extension == 'jpg' || extension == 'JPG' || extension == 'jpeg' || extension == 'JPEG' || extension == 'png' || extension == 'PNG' || extension == 'gif' || extension == 'GIF') {
            var iSize = ($('#' + images)[0].files[0].size / 1000);
            if (iSize <= 3000) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    var image = new Image();
                    image.src = e.target.result;
                    image.onload = function () {
                        var height = this.height;
                        var width = this.width;
//                        if (height != max_width || width != max_height) {
                        if (height < 100 || width < 100) {
                            alert("Image width and height must be above 100*100");
                            $('#' + images).val('');
                            $('#' + srclogo).attr(src, '');
                            return false;
                        } else {
                            $('#' + srclogo).attr('src', e.target.result);
                        }
                    };
                };
                reader.readAsDataURL($('#' + images)[0].files[0]);
            } else {
                alert("Sorry! Image size exceeds 3MB");
                $('#' + images).val('');
                return false;
            }
        } else {
            alert("Invalid File Fortmat! Please upload only .jpg,.jpeg,.png");
            $('#' + images).val('');
            return false;
        }
    } else {
        alert("Image is required");
        $('#' + images).val('');
        return false;
    }
}
//APJ.Abdulkalam couraousel image slider - corresponding image to show //
$(function () {
    $(".ap-smallimg").click(function () {
        var rimg = $(this).attr("src");
        $(".ap-bigimg").attr("src", rimg);
    });
});

$(function () {
    $('#selectCity').next('.select2').find('.select2-selection').one('focus', select2Focus).on('blur', function () {
        $(this).one('focus', select2Focus);
    });
    function select2Focus() {
        $(this).closest('.select2').prevAll('#selectCity').select2('open');
        $(this).closest("form").find("#ad_description").focus();
    }
});


//-------------------------------------------------------

/*
Project Title   :   Bizbilla
Version         :   3.0
Title           :   cart
Description     :   All cart functions(hidded)
Included        :   -
Last Modified   :   Aug 14,2017 / Sivagami
Assigned to     :   Daniel Sebastian
*/

//*****pincode check in product detail******
$(document).ready(function () {
    if ($('#sessIONMEMber').length) {
        // console.log("fas");
        var a = $('#pincodeTxtBox').val();
        checkPincode($('#pincodeTxtBox').val());
    }
});

$(function () {

    $('[data-toggle="tooltip2"]').tooltip();


});

//***************Add to cart Start*************
function addtocart(pro_id, type_wish, wishid)
{
    var pincode = $('#pincodeTxtBox').val();
    var type_wish = typeof type_wish !== 'undefined' ? type_wish : 0;
    var wishid = typeof wishid !== 'undefined' ? wishid : 0;

    if (wishid != 0) {
        var price_val = document.getElementById('ecompriceinp_' + wishid).value;
        var price_variant = document.getElementById('defaultvariantspec_' + wishid).value;
        var delivery_charge = document.getElementById('delivery_charge_' + wishid).value;
        var ship_json = document.getElementById('shippingdetailsjson_' + wishid).value;
        var provider = document.getElementById('hid_provider_' + wishid).value;
    } else {
        var price_val = document.getElementById('ecompriceinp').value;
        var price_variant = document.getElementById('defaultvariantspec').value;
        var delivery_charge = document.getElementById('delivery_charge').value;
        var ship_json = document.getElementById('shippingdetailsjson').value;
        var provider = document.getElementById('hid_provider').value;
    }
//    console.log(price_val);
//    console.log(price_variant);
//    console.log(ship_json);
//    console.log(delivery_charge);
    if (type_wish != 1) {
        if (pincode == '') {
            $("#picodeErrDiv").html('Enter Valid Pincode.');
            $('#pincodeTxtBox').focus();
            $('#pincodeTxtBox').select();
            $('#delivery_charge').val('0');
        } else {
            if (pincode != '' && delivery_charge == 0) {
                $("#picodeErrDiv").html('Enter Valid Pincode.');
                $('#pincodeTxtBox').focus();
                $('#pincodeTxtBox').select();
                $('#pincodeTxtBox').val('');
            } else {

                var url = URL_MAIN_PATH + '/cart/addcart';
                $.ajax({
                    type: 'get',
                    url: url,
                    dataType: 'jsonp',
                    crossDomain: true,
                    data: {
                        id: pro_id,
                        hid_amt: price_val,
                        hid_variant: price_variant,
                        delivery_charge: delivery_charge,
                        ship_json: ship_json,
                        provider: provider
                    },
                    beforeSend: function () {
                        $('.cart-preloader').show();
                    },
                    complete: function (e) {
                        // console.log();
                        $('.cart-preloader').hide();
                    },
                    success: function (e) {
                        updateCartCount();

                        if (type_wish == 1) {
                            window.location = URL_MAIN_PATH + '/cart';
                        } else if (type_wish == 2) {
                            window.location = URL_MAIN_PATH + '/placeorder';
                        } else {
                            $(".cart-fixed").fadeIn();
                            setTimeout(function () {
                                $(".cart-fixed").fadeOut();
                            }, 3000);
                            $('.cart-fixed').html(e);
                            $("#cart_" + pro_id).html('<span>Added to cart</span>');
                            $('#load_cart').load(location.href + ' #load_cart');
//                            $('#load_cart').load(document.URL +  ' #load_cart');
//                            $('#load_cart').load();
                        }
                    }
                });
            }
        }
    } else {
        var url = URL_MAIN_PATH + '/cart/addcart';
        $.ajax({
            type: 'get',
            url: url,
            dataType: 'jsonp',
            crossDomain: true,
            data: {
                id: pro_id,
                hid_amt: price_val,
                hid_variant: price_variant,
                delivery_charge: delivery_charge,
                ship_json: ship_json,
                provider: provider
            },
            beforeSend: function () {
                $('.cart-preloader').show();
            },
            complete: function (e) {
                // console.log();
                $('.cart-preloader').hide();
            },
            success: function (e) {
                updateCartCount();

                if (type_wish == 1) {
                    window.location = URL_MAIN_PATH + '/cart';
//                    $(".cart-fixed").fadeIn();
//                    setTimeout(function () {
//                        $(".cart-fixed").fadeOut();
//                    }, 3000);
//                    $('.cart-fixed').html(e);
//                    $("#cart_" + pro_id).html('<span>Added to cart</span>');
                }
            }
        });
    }
}
function updateCartCount() {
    var url = URL_MAIN_PATH + '/cart/cartcount';

    $.ajax({
        type: 'get',
        url: url,
        dataType: 'jsonp',
        success: function (e) {
            console.log(e);
            $('#cart_count').html(e);
//            $('#load_cart').load(location.href+' #load_cart');
        }
    });
}
//************Add to cart End***************

//********check variant price*********
function checkvariantprice(price, id, varid, vardiv, varactive, varobject, orgpricediv, varstock, ownmem, ecomstatus) {

    var orgprice = $('#ecompriceorg').val();
//    console.log(orgprice);
//    console.log(price);
//    console.log(varactive);

    $('.varactivecheck').removeClass('var-active');
    $('.' + varactive).addClass('var-active');

    if (price != '' && price != 0) {
        if (orgprice == price) {
            $('.listprice').show();
        } else {
            $('.listprice').hide();
        }
        $('.' + id).html(price);
        $('#ecompriceinp').val(price);

        if ($('#ecomorg').length) {
            var saveprice = orgpricediv - price;
            $('#ecomorg').html(orgpricediv);
            $('#discountoff').html(saveprice);
        }

    }
    var deli = $('#delivery_charge').val();

    if (varstock != '' && varstock != 0) {
        if (varstock <= 2) {
//            console.log(varstock + 'vivek');
            $('.instockhead').html('Only ' + varstock + ' Left In Stock.');
            $('.instockhead').removeClass('instock2');
        } else {
            $('.instockhead').html('In Stock.');
            $('.instockhead').removeClass('instock2');
        }
        $('.paraoutstock').hide();
    } else {
        $('.instockhead').html('Out of Stock!');
        $('.instockhead').addClass('instock2');
        $('.paraoutstock').show();
//        console.log(varstock + 'empty');
    }
    console.log(ecomstatus);
    console.log(deli);
    console.log(price);
    console.log(varstock);
//    if (deli != 0) {
    if (ecomstatus == 1 && price != '' && price != 0 && ownmem != 1 && varstock != '' && varstock != 0) {
//        $('.varbtncart').show();
        $('.cart-popup').prop("disabled", false);
        $('.prod-addcart-btn').removeClass("prod-disb");
        $('.buy-button').prop("disabled", false);
        $('#pincheckdiv').removeClass("d-none");
    } else {
        $('.cart-popup').prop("disabled", true);
        $('.prod-addcart-btn').addClass("prod-disb");
        $('.buy-button').prop("disabled", true);
        $('#pincheckdiv').addClass("d-none");
//        $('.varbtncart').hide();
    }
//    } else {
//        $('.cart-popup').prop("disabled", true);
//        $('.prod-addcart-btn').addClass("prod-disb");
//        $('.buy-button').prop("disabled", true);
////        $('#pincheckdiv').addClass("d-none");
//    }

    var varvalue = $('#' + varid).val();

    var varvalue1 = $('#' + vardiv).val();
//    console.log(varvalue);
//    console.log(varvalue1);
    var object = {};
    object = $.parseJSON($('#defaultvariantspec1').val());
//    console.log(object);
    object[varvalue1] = varvalue;




    var valueField = JSON.stringify(object);


    $('#defaultvariantspec').val(valueField);

//    $(varobject).addClass('var-active');

}

//**************check pincode************
function checkPincode(pincode) {
    var res;
    $('#tmPincode').val(pincode);
    $('#sendpincode').val(pincode);
    $('#picodeErrDiv').html('');
    if (!$.isNumeric(pincode)) {
        $('#picodeErrDiv').html('Enter Valid Pincode');
    } else {
        var proweightjson = $('#proweightjson').val();
        var free_shipping = $('#free_shipping').val();
        var supplierpincode = $('#supplierpincode').val();
        var pro = $('#prod_id').val();
        $.ajax({
            url: URL_MAIN_PATH + "/logistics/get/" + pincode,
            type: "get",
            data: {weightjson: proweightjson, suplierpin: supplierpincode, pro: pro},
            dataType: 'json',
            beforeSend: function () {
                $('.pin-check2').hide();
                $('.pin-check-loader').show();
            },
            complete: function (e) {
                // console.log();
                $('.pin-check-loader').hide();
            },
            success: function (result) {
                var delprice, deldays;
                if (result.trnexpectadditional != 0) {
                    deldays = result.trnexpectin + ' - ' + result.trnexpectadditional;
                } else {
                    deldays = result.trnexpectin;
                }
                delprice = result.price;
//                console.log(result);
                var shippingdetails = result.shippingdetails;
                var provider = result.provider;
                if (result.delerror_code == '') {
                    $('#picodeAvDiv').addClass('hidden');
                    if (free_shipping != 1) {
                        $('#orderdeldiv').html('Order & get it delivered in ' + deldays + ' day(s) <span> (+) Rs.' + delprice + ' </span>');
                    } else {
                        $('#orderdeldiv').html('Order & get it delivered in ' + deldays + ' day(s).');
                    }
                    $('#locationSpan').html(' ( ' + result.locationSpan + ' ). ');
                    $('#delivery_charge').val(delprice);
                    $('#shippingdetailsjson').val(shippingdetails);
                    $('#hid_provider').val(provider);
                    $('#picodeAvSuc').removeClass('hidden');
                    $("#adDCArt").removeAttr('disabled');
                    $(".prod-addcart-btn").removeClass('prod-disb');
                    $('.newvarbut').removeClass("prod-disb");
                    $("#formpost_buynow").removeAttr('disabled');
                    $("#buynowButton").removeAttr('disabled');
//                    $('#buynowButton').removeClass('prod-disb');
//                    $('#formpost_buynow').removeClass('prod-disb');
                } else if (result.delerror_code == 'ERR002') {
                    $('#picodeAvDiv').addClass('hidden');
                    $('#picodeAvFail').removeClass('hidden');
                    $('#pincodeTxtBox').val('');
                    $('#picodeErrDiv').html(result.delerror);
                    $('#delivery_charge').val('0');
                    $('.prod-addcart-btn').addClass('prod-disb');
//                    $('#adDCArt').addClass('disabled');
//                    $('#buynowButton').addClass('prod-disb');
//                    $('#buynowButton').addClass('disabled');
//                    $('#formpost_buynow').addClass('prod-disb');
                    $('#pincodeTxtBox').select();
                } else if (result.delerror_code == 'ERR001') {
//                    console.log('disabled');
                    $('#pincodeTxtBox').val('');
                    $('#picodeAvFail').removeClass('hidden');
                    $('#picodeErrDiv').html(result.delerror);
                    $('#delivery_charge').val('0');
                    $('.prod-addcart-btn').addClass('prod-disb');
//                    $('#adDCArt').addClass('disabled');
//                    $('#buynowButton').addClass('prod-disb');
//                    $('#buynowButton').addClass('disabled');
//                    $('#formpost_buynow').addClass('prod-disb');
                    $('#pincodeTxtBox').select();
                }
            }
        });
    }
}

//***********pincode hide**************
function hidePinDiv(divId) {
    $('#picodeAvDiv').removeClass('hidden');
    $('#' + divId).addClass('hidden');
    $('#pincodeTxtBox').val('');
    $('#delivery_charge').val('0');
    $('#picodeAvDiv').show();
    $('#pincodeTxtBox').attr('autofocus');
}
$.fn.pressEnter = function (fn) {
    return this.each(function () {
        $(this).bind('enterPress', fn);
        $(this).keyup(function (e) {
            if (e.keyCode == 13)
            {
                $(this).trigger("enterPress");
            }
        })
    });
};
//***********check delivery*********
$('#pincodeTxtBox').pressEnter(function () {
    checkPincode($(this).val())
});
/*
Project Title   :   Bizbilla;
Version         :   3.0;
Title           :   Blog page ;
Description     :   for blog editor page.This JS is Imported in js-fef file;
Included        :   
Last Modified   :   Aug 14,2017 / Rajapriya;
Assigned to     :   Manaobala & bageerathan;
*/


$(function () {
//    if ($('#blogeditor').length) {
//        CKEDITOR.replace('blogeditor',
//                {
//                    toolbar: 'Basic', /* this does the magic */
//                    uiColor: '#FFFFFF',
//                    autoUpdateElement: true,
//                    indent: false,
//                    breakAfterOpen: false
//                });
//    }

//    CKEDITOR.on('instanceReady', function () {
//        $.each(CKEDITOR.instances, function (instance) {
//            CKEDITOR.instances[instance].on("change", function (e) {
//                for (instance in CKEDITOR.instances)
//                    CKEDITOR.instances[instance].updateElement();
//            });
//        });
//    });
    if ($('#description').length) {
//        CKEDITOR.replace('description',
//                {
//                    toolbar: 'Basic', /* this does the magic */
//                    uiColor: '#FFFFFF',
//                    autoUpdateElement: true,
//                    indent: false,
//                    breakAfterOpen: false
//                });
    }
});
//$(function() {
//    $("form[name=magazine_form]").parsley();
//     $("form[name=magazine_form]").on('submit', function(e) {
//         console.log('sdfsdf');
//     });
//    
//});
/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :   newscript
 Description     :   home page script, country listing,search auto suggestion, page share script
 Included        :   -
 Last Modified   :   Aug 14,2017 / Sivagami
 Assigned to     :   Arivarasi, Sivagami
 */

//******country listing filter in gd module*******
$('.countrylist_filter').click(function () {

    var cc = $(this).text();
    $.ajax({
        url: 'filtercountry',
        data: {
            contch: cc
        },
        type: 'post',
        dataType: 'text',
        success: function (e) {
            var jsondata = $.parseJSON(e);
            $('.firstshow').hide();
//            alert(jsondata);
//            $(jsondata).each(function (i, val) {
//                alert("yes");
//                $.each(val, function (k, v) {
////                    alert(val);
////                    alert(v);
//                    var ccc = console.log(k + " : " + v);
//                    alert(ccc);
////                    alert(ccc);
//                });
//            });
            $('.ajax_search').append('<div class="col-xs-12" style="margin-top: 15px;border-bottom:1px solid orange"><div class="row"><span style="margin-bottom: 10px;background: #F79621;padding: 1px 9px;color: #000;border-left: solid 5px #00B2FF;margin-bottom: 10px;float: left;">' + cc + '</span></div></div>');
            for (var i = 0; i < jsondata.length; ++i)
            {
//                alert(jsondata[i].short_name);
                $('.ajax_search').append('<div class="col-lg-3" style="margin-top:10px"><a href="" id="countrylist_anchor" style="color:grey;">' + jsondata[i].short_name + '</a></div>');
            }
//            alert(obj.short_name);
//            window.location = 'view-country';
        }
    });
//    $.getJSON('/countrywise-airports/filter-country', {contch: cc}, function (data) {
//        $.each(data, function (index, element) {
//            $('body').append($('<div>', {
//                text: element.short_name
//            }));
//        });
//    });
});


//////////////////////////////////////////Latest news- news archive/////////////////////////////////////
$.fn.extend({
    treed: function (o) {

        var openedClass = 'glyphicon-folder-open';
        var closedClass = 'glyphicon-folder-close';

        if (typeof o != 'undefined') {
            if (typeof o.openedClass != 'undefined') {
                openedClass = o.openedClass;
            }
            if (typeof o.closedClass != 'undefined') {
                closedClass = o.closedClass;
            }
        }
        ;

        //initialize each of the top levels
        var tree = $(this);
        tree.addClass("tree");
        tree.find('li').has("ul").each(function () {
            var branch = $(this); //li with children ul
            branch.prepend("<i class='indicator glyphicon " + closedClass + "'></i>");
            branch.addClass('branch');
            branch.on('click', function (e) {
                console.log(e);
                if (this == e.target) {
                    var icon = $(this).children('i:first');
                    icon.toggleClass(openedClass + " " + closedClass);
                    $(this).children().children().toggle();
                }
            })
            branch.children().children().toggle();
        });
        //fire event from the dynamically added icon
        tree.find('.branch .indicator').each(function () {
            $(this).on('click', function () {
                $(this).closest('li').click();
            });
        });
//        //fire event to open branch if the li contains an anchor instead of text
//        tree.find('.brancha').each(function () {
//            $(this).on('click', function (e) {
//                $(this).closest('li').click();
//                e.preventDefault();
//            });
//        });
        //fire event to open branch if the li contains a button instead of text
        tree.find('.branch>button').each(function () {
            $(this).on('click', function (e) {
                $(this).closest('li').click();
                e.preventDefault();
            });
        });
    }
});

//Initialization of treeviews

$('#lat-news-arch-tree').treed();
//////////////////////////////////End of latest news archive////////////////////////////////////////////
/************Trending category Home page************/
$('#trend_categ_carousel').carousel('pause');

//************List and Grid view display for Search view*************
$(document).ready(function () {
    var search_view = $('#listgrid').val();
    if (search_view == 0) {
        $('.pro-block').removeClass('grid-block');
        $(this).addClass('view-active');
        $('.grid-trigger').removeClass('view-active');
        $('.list-trigger').addClass('view-active');
    } else if (search_view == 1) {
        $('.pro-block').addClass('grid-block');
        $(this).addClass('view-active');
        $('.grid-trigger').addClass('view-active');
        $('.list-trigger').removeClass('view-active');
    }
});

//*********** Auto keyword display for search*****************
if (document.querySelector('.key_form') !== null) {
    var count = 1;
    var group = document.getElementById('search_autokey');
    var list_group = group.querySelector('ul');
    var list_array = group.querySelectorAll('ul li a');
    var search = group.getElementsByTagName('input')[0];

    search.addEventListener('input', function (e) {
        for (var i = 0; i < list_array.length; i++) {
            matching(list_array[i]);
        }
        show_list(list_group);
        key_up_down();
    });

    search.addEventListener('click', function (e) {

        init_list();
        show_list(list_group);
        key_up_down();
        hideerror();
    });
    search.addEventListener('keypress', function (e) {
        if (e.keyCode == 13) {
            e.target.value = list_group.querySelector('[data-highlight="true"]').innerHTML;
        }
        hide_list(list_group);
        init_list();
    });

    function matching(item) {
        var str = new RegExp(search.value, 'gi');
        if (item.innerHTML.match(str)) {
            item.dataset.display = 'true';
        } else {
            item.dataset.display = 'false';
            item.dataset.highlight = 'false';
            count = 0;
        }
    }
    function hideerror() {
        $('.key_form .parsley-errors-list').css({"display": "none"});
    }
    function displayerror() {
        $('.key_form .parsley-errors-list').css({"display": "block"});
    }

    function init_list() {
        count = 0;
        for (var i = 0; i < list_array.length; i++) {
            init_item(list_array[i]);
            list_array[i].addEventListener('click', copy_paste);
        }
    }

    function init_item(item) {
        item.dataset.display = 'true';
        item.dataset.highlight = 'false';
    }

    function copy_paste() {
        search.value = this.innerHTML;
        init_list();
        hide_list(list_group);
    }

    function hide_list(ele) {
        ele.dataset.toggle = 'false';
    }

    function show_list(ele) {
        ele.dataset.toggle = 'true';
    }

    function key_up_down() {

        var items = group.querySelectorAll('li a[data-display="true"]');
        var last = items[items.length - 1];
        var first = items[0];

        search.onkeydown = function (e) {

            if (e.keyCode === 38) {
                count--;
                count = count <= 0 ? items.length : count;
                items[count - 1].dataset.highlight = items[count - 1] ? 'true' : 'false';
                if (items[count]) {
                    items[count].dataset.highlight = 'false';
                } else {
                    first.dataset.highlight = 'false';
                }
            }

            if (e.keyCode === 40) {
                items[count].dataset.highlight = items[count] ? 'true' : 'false';
                if (items[count - 1]) {
                    items[count - 1].dataset.highlight = 'false';
                } else {
                    last.dataset.highlight = 'false';
                }
                count++;
                count = count >= items.length ? 0 : count;
            }
            if (e.keyCode === 13) {
                list_group.dataset.toggle = 'false';
                displayerror();
            }
        };
    }

    group.addEventListener('mouseleave', function (event) {
        if (event.target != list_group && event.target.parentNode != list_group) {
            list_group.dataset.toggle = 'false';
        }
    });
}
function closeHis() {
    $('.search-hist').slideUp();
}
function hisSearchOpen() {
    $('.search-hist').slideToggle();
}
//***************************Share Script*************
$(document).ready(function () {
var s=0;
    $(".share-responsive-close-menu").click(function () {
        if (s == 0) {
            $(".share_icons").animate({'right': '0px'});
            s = 1;
        } else {
            $(".share_icons").animate({'right': '-500px'});
            s = 0;
        }
    });
});
function close_share() {
    $('.share_full_page').css({"display": "none", "transition": "1s"});
}
function share_full_open() {
    $('.share_full_page').css({"display": "block", "transition": "1s"});
}
function loadMore() {
    $('.more_icons').css({"display": "block", "transition": "1s"});
    $('.load_more button').css({"display": "none", "transition": "1s"});
}
$("#srch").keyup(function () {
    if ($(this).val() == "") {
        $('.more_icons').css({"display": "none", "transition": "1s"});
        $('.load_more button').css({"display": "inline-block", "transition": "1s"});
    }
});
onkeydown = function (e) {
    if (e.keyCode === 27) {
        $('.share_full_page').css({"display": "none", "transition": "1s"});
    }
};
//***************full page share filter script*********************
$('#no_share').hide();
var quickFilter = function (srchInput, srchSel) {

    $(srchInput).on('change keyup paste mouseup', function () {
        var s = $(this).val();
        filter(s);

        var ulemp = $('#myul > li:visible').length;
        var ulmoreemp = $('#mymoreul > li:visible').length;
        if (ulemp == 0 && ulmoreemp == 0) {
            $('#no_share').show();
        }
        if (ulemp == 0) {
            $('.top_icons h3').hide();
            $('.more_border').hide();
        } else {
            $('.top_icons h3').show();
            $('.more_border').show();
        }
    });

    var filter = function (s) {
        $(srchSel).each(function () {
            var $this = $(this);
            var txt = $this.text();
            if (txt.toLowerCase().indexOf(s.toLowerCase()) < 0) {
                $this.hide();
            } else {
                $this.show();
                $('#no_share').hide();
            }
        });
    };
};
quickFilter('#srch', '#srchbody li');

//-----------profile add forms------------
var specialKeys = new Array();
specialKeys.push(8);

function IsNumeric(e) {
    var msg = "Input digits (0 - 9)";
    var keyCode = e.which ? e.which : e.keyCode
    var ret = ((keyCode == 45 || keyCode == 43) || (keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
    return ret;
}

function getproduct_category() {
    $('.searchselectdiv').css({'display': 'block'});
    $('#product_category').css({'display': 'block', 'margin-top': '30px'});
    $('#product_subcategory').css({'display': 'none'});
    $('#product_subsubcategory').css({'display': 'none'});
    $('#category1').css({'display': 'none'});
    $('.result_found').css({'display': 'none'});
    $('#category_search').val('');
}

function getbuyer_category() {
    $('.searchselectdiv').css({'display': 'block'});
    $('#buyer_category').css({'display': 'block', 'margin-top': '30px'});
    $('#buyer_subcategory').css({'display': 'none'});
    $('#buyer_subsubcategory').css({'display': 'none'});
    $('#category1').css({'display': 'none'});
    $('.result_found').css({'display': 'none'});
}

function getservice_category() {
    $('.searchselectdiv').css({'display': 'block'});
    $('#addserve_category').css({'display': 'block'});
    $('#addserve_subcategory').css({'display': 'none'});
    $('#addserve_subsubcategory').css({'display': 'none'});
    $('#category1').css({'display': 'none'});
    $('.result_found').css({'display': 'none'});
}

var get_prodid = $('#get_productid').val();
if (get_prodid != '')
    $('#product_category').css({'display': 'block'});

var get_buyingid = $('#get_buyingid').val();
if (get_buyingid != '')
    $('#buyer_category').css({'display': 'block'});

$(document).ready(function () {
//    $('#product_category').css({'display': 'none'});
});

$('#proforms').on('submit', function () {
    if (($('#category1').not(':visible')) && ($('#product_category').not(':visible'))) {
        $('#product_category').css({'display': 'block'});
    }
});

$('#add_buyingneed').on('submit', function () {
    if (($('#category1').not(':visible')) && ($('#buyer_category').not(':visible'))) {
        $('#buyer_category').css({'display': 'block'});
    }
});

$('#addserviceform').on('submit', function () {
    if (($('#category1').not(':visible')) && ($('#addserve_category').not(':visible'))) {
        $('#addserve_category').css({'display': 'block'});
    }
});

function gethomebuyer_category() {
    $('.searchselectdiv').css({'display': 'block'});
    $('#product_category').css({'display': 'block'});
    $('#product_subcategory').css({'display': 'none'});
    $('#product_subsubcategory').css({'display': 'none'});
    $('#category1').css({'display': 'none'});
    $('.result_found').css({'display': 'none'});
    $('#category_search').val('');
}

$('#postBuyingRequirementForm').on('submit', function () {
    if (($('#category1').not(':visible')) && ($('.searchselectdiv').not(':visible'))) {
        $('.searchselectdiv').css({'display': 'block'});
    }
//    var description = $('#description').val();
//    var desc = description.replace(/[\|\^\=\@\<\>\{\}\[\]\#\~\/\\]/g, '');
//    $('#description').val(desc);
});

$('#abide_btn').click(function () {
    if ($(this).is(':checked')) {
        $('#buyingadd').removeAttr('disabled');
    } else {
        $('#buyingadd').attr('disabled', true);
    }
});

/*
Project Title   :   Bizbilla
Version         :   3.0
Title           :   gdb-cript
Description     :   Global database scripts, product and buying need detail page scripts
Included        :   -
Last Modified   :   Aug 15,2017 / Sivagami
Assigned to     :   Kalaivanan,Bhuvaneshwari,Vidhya,Aravind,Vivek
*/

//**************search letter-country listing in gd modules*******
$(function () {
    $('.search-letter li').click(function () {
        $(this).addClass('active');
        $(this).prevAll('li').removeClass('active');
        $(this).nextAll('li').removeClass('active');
        $('.countrylist .border').addClass('border-none');
    });
    $('.search-letter .all').click(function () {
        $('.countrylist .border').addClass('border-block');
    });

//*****tradeshow organiser owl carousel in tradeshow index page*******
    var owl3 = $('.trade-org');
    owl3.owlCarousel({
        items: 4,
//        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            500: {
                items: 2
            },
            770: {
                items: 3
            },
            990: {
                items: 5
            }
        },
        autoplay: false,
        autoplayTimeout: 1000,
        autoplayHoverPause: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ]
    });
    $('.play').on('click', function () {
        owl3.trigger('autoplay.play.owl', [1000]);
    });
    $('.stop').on('click', function () {
        owl3.trigger('autoplay.stop.owl');
    });

//    ******choose template(hidded)******
    var owl3 = $('.choose-template1');
    owl3.owlCarousel({
        items: 1,
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            500: {
                items: 1
            },
            770: {
                items: 1
            },
            990: {
                items: 1
            }
        },
        autoplay: false,
        autoplayTimeout: 1000,
        autoplayHoverPause: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ]
    });
    $('.play').on('click', function () {
        owl3.trigger('autoplay.play.owl', [1000]);
    });
    $('.stop').on('click', function () {
        owl3.trigger('autoplay.stop.owl');
    });
});
//******success story heading desin(hidded)****
$(window).load(function () {
//    if ($('.gdp-all-details').length) {
//        $('html,body').animate({scrollTop: $('.gdp-all-details').offset().top - 200}, 500);
//    }
    $('.suc-1 h2 a, .suc-2 h2 a, .suc-3 h2 a, .suc-4 h2 a,.suc-5 h2 a').each(function () {
        var word = $(this).html();
        var index = word.indexOf(' ');
        if (index === -1) {
            index = word.length;
        }
//        $(this).html('<span class="first-word">' + word.substring(0, index) + '</span>' + word.substring(index, word.length));
    });

});

/**********GD Billionaires-menu**********/



//$(window).scroll(function () {
//    var ad = $(window).scrollTop();
//    var wd = 50;
//
//    if (ad > wd) {
//        $('.side-addban').css({'right': '25px'});
//    } else if (ad < wd) {
//        $('.side-addban').css({'right': '-500px'});
//    }
//
//});

$(function () {
    setTimeout(function () {
        $('#at_hide').hide('slow');
    }, 4000);
});

$('.top-fixed-menu .byyear').click(function () {
    $(this).children('.yearlist').stop().slideToggle();
//    $(this).nextAll().stop().slideToggle(100);
});

$(function () {
    $('.scroll').click(function () {
        var scr = $(this).attr('href');
        var ss = $(scr).offset().top - 120;
        $('html,body').animate({scrollTop: ss}, 500);
        return false;
    });
//******trade magazine home page owl carousel******
    var owl = $('.latest-trade-magazine, .other-buyers');
    owl.owlCarousel({
        items: 4,
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            500: {
                items: 2
            },
            770: {
                items: 3
            },
            990: {
                items: 4
            }
        },
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ]
    });
    $('.play').on('click', function () {
        owl.trigger('autoplay.play.owl', [1000]);
    });
    $('.stop').on('click', function () {
        owl.trigger('autoplay.stop.owl');
    });
//****gd Billionaires tab menu*****
    $('.all').click(function () {
        $('html,body').animate({scrollTop: $('#main-wrapper').offset().top - 140 + 'px'}, 1000);
    });
    $('.bycountry').click(function () {
        $('html,body').animate({scrollTop: $('#by-country').offset().top - 140 + 'px'}, 1000);
    });
    $('.byyoung').click(function () {
        $('html,body').animate({scrollTop: $('#by-young').offset().top - 140 + 'px'}, 1000);
    });
    $('.bywomen').click(function () {
        $('html,body').animate({scrollTop: $('#by-women').offset().top - 140 + 'px'}, 1000);
    });
    $('.byold').click(function () {
        $('html,body').animate({scrollTop: $('#by-old').offset().top - 140 + 'px'}, 1000);
    });


    $('.carousel').carousel({
        interval: 3000
    });
//*****Billionaires owl carousel****
    var owl2 = $('.billionaires');
    owl2.owlCarousel({
        items: 4,
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            500: {
                items: 2
            },
            770: {
                items: 3
            },
            990: {
                items: 4
            }
        },
        autoplay: true,
        autoplayTimeout: 2000,
        autoplayHoverPause: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ]
    });
    $('.play').on('click', function () {
        owl2.trigger('autoplay.play.owl', [1000]);
    });
    $('.stop').on('click', function () {
        owl2.trigger('autoplay.stop.owl');
    });
//




    /********GD Hscode***********/

    $('.hscode-list li a').click(function () {
        $('html,body').animate({scrollTop: $('.hscode-detail').offset().top - 100 + 'px'}, 500);
    });

//    $('.forum-cont .edit-icon').click(function () {
////        $(this).parent().children('.edit-list').stop().slideToggle();
//        $(this).nextAll().stop().slideToggle(100);
//    });

//    $('.forum-cont .edit-icon').focusin(function (){
//        $(this).parent().children('.edit-list').css({'display' : 'block'});
//    });
//    $('.forum-cont .edit-icon').focusout(function (){
//        $(this).parent().children('.edit-list').css({'display' : 'none'});
//    });

    $('.promo-category2 h3').click(function () {
        $(this).parent().children('.category-list').stop().slideToggle(500);
    });

    $('.friends-form input').focusin(function () {
        $(this).parent().css({'border-color': '#296FB7'});
        $(this).parent().children('span').css({'background': '#296FB7', 'color': '#fff', 'transition': 'all linear 0.2s'});
        $(this).parent().children('span').children('i').css({'border': 'none'});
    });
    $('.friends-form input').focusout(function () {
        $(this).parent().css({'border-color': '#ccc'});
        $(this).parent().children('span').css({'background': '#fff', 'color': '#666'});
        $(this).parent().children('span').children('i').css({'border-right': '1px solid #ccc'});
    });
//    $('.blog-searchform input').focusin(function () {
//        $(this).css({'padding-left': '15px'});
//        $(this).next('label').css({'left': '-50px'});
//    });
//    $('.blog-searchform input').focusout(function () {
//        $(this).css({'padding-left': '55px'});
//        $(this).next('label').css({'left': '0px'});
//    });

//******select city in add,edit service form********
    $(function () {
        $('#seacrchcity').next('.parsley-errors-list').css({'width': '100px'});
    });

    /**********Login modal & contact modal************/

//    $('.signin-link .btn-login').click(function () {
//        $('.common-fade').addClass('signin-wrap');
//    });
//    $('.common-fade .close').click(function (){
//        $('.common-fade').removeClass('signin-wrap');
//    });
//    $('.login-link .btn-singin').click(function () {
//        $('.common-fade').addClass('signin-wrap');
//    });
//    $('.inquiryModal').click(function () {
//        $('.common-fade').addClass('inquiry-wrap');
//    });
//
//    $('.common-fade .close').click(function () {
//        $('.common-fade').removeClass('inquiry-wrap');
//    });
//    $('.common-fade').click(function () {
//        $('.common-fade').removeClass('inquiry-wrap');
//    });
//    $('.common-fade .close').click(function (){
//        $('.common-fade').removeClass('nonimage-wrap');
//    });
//    $('.common-fade').click(function (){
//        $('.common-fade').removeClass('nonimage-wrap');
//    });
//******product inquiry form width******
    $('.prod-inquiry').parent('.modal-dialog').css({'width': '900' + 'px'});

    $('#myTabs a').click(function (e) {
        e.preventDefault();
        $(this).tab('show');
    });

});

//****product detail page height determination****
$(function () {
    var gallcaro2 = $('#othergallimg').val();
    if (gallcaro2 > 1) {
        var h = $('.prod-detailed-b1').outerHeight();
        $('.prod-detail-img-wrap').css({'min-height': h + 'px'});
    } else {
        $('.prod-detailed-b1').css({'min-height': '450px'});
        var hi = $('.prod-detailed-b1').outerHeight();
        $('.prod-detail-img-wrap').css({'min-height': hi + 'px'});
    }
});
//****buyingneed detail page height determination****
$(function () {
    var gallcaro2 = $('#buygallimg').val();
    if (gallcaro2 > 1) {
        $('.bigdetailwrap').css({'min-height': '420px'});
        var h = $('.bigdetailwrap').outerHeight();
        $('.bigimgwrap').css({'min-height': h + 'px'});
    } else {
        $('.bigdetailwrap').css({'min-height': '320px'});
        var hi = $('.bigdetailwrap').outerHeight();
        $('.bigimgwrap').css({'min-height': hi + 'px'});
    }
});

$(function () {
    var ih = $('.formcontainer').outerHeight();
    $('.prod-cont-wrap').css({'min-height': ih + 'px'});
});
//*****payment options in cart(hidded)*****
function check_credit() {
    $('#check-credit').toggle(300);
    $('#check-debit').hide(300);
    $('#check-netbank').hide(300);
    clearPayForm();
}
function check_debit() {
    $('#check-debit').toggle(300);
    $('#check-credit').hide(300);
    $('#check-netbank').hide(300);
    clearPayForm();
}
function check_netbank() {
    $('#check-debit').hide(300);
    $('#check-credit').hide(300);
    $('#check-netbank').toggle(300);
    clearPayForm();
}
function clearPayForm() {
    $('#payform-net').html('');
    $('#payform-deb').html('');
    $('#payform-crd').html('');
    $("input:radio[name='pay']").each(function (i) {
        this.checked = false;
    });
}

function pay_ccselect(varselect, varpay, divid, gateway) {
//    console.log(now());
    $('.' + varselect).removeClass('pay-select2');
    $(varpay).addClass('pay-select2');
    $('#' + divid + gateway).prop("checked", true);
    var payJSON = $('#paymentJSON').val();
//    alert(payJSON);
    $.ajax({
        url: '/payment/form',
        data: {
            gateway: gateway, payment: payJSON
        },
        type: 'post',
        success: function (e) {
//            console.log(e);
            $('#payform-' + divid).html(e);
        }
    });
}

/********End**********/

/********************************product detail page owl********************/

var owl6 = $('.prod-owl-img');
var gallcaro = $('#othergallimg').val();
if (gallcaro < 5) {
    $('#galldiv').find(".owl-nav").css('display', 'none');
}


owl6.owlCarousel({
    items: 3,
    loop: false,
    margin: 10,
    nav: true,
    responsive: {
        0: {
            items: 2
        },
        500: {
            items: 3
        },
        770: {
            items: 4
        },
        990: {
            items: 5
        }
    },
    autoplay: false,
    autoplayTimeout: 1000,
    autoplayHoverPause: true,
    navText: [
        "<i class='fa fa-angle-left'></i>",
        "<i class='fa fa-angle-right'></i>"
    ]


});
$('.play').on('click', function () {
    owl6.trigger('autoplay.play.owl', [1000]);
});
$('.stop').on('click', function () {
    owl6.trigger('autoplay.stop.owl');
});



var owl2 = $('.prod-other-owl-img');
var countsubpro = $('#otherprocount').val();

if (countsubpro < 6) {
    $('#otherdiv').find(".owl-nav").css('display', 'none');
}
owl2.owlCarousel({
    items: 3,
    loop: false,
    margin: 10,
    stagePadding: 10,
    nav: true,
    responsive: {
        0: {
            items: 1
        },
        500: {
            items: 3
        },
        770: {
            items: 4
        },
        990: {
            items: 5
        },
        1200: {
            items: 6
        }
    },
    autoplay: true,
    autoplayTimeout: 2000,
    rewind: true,
    animateOut: true,
    autoplayHoverPause: true,
    navText: [
        "<i class='fa fa-angle-left'></i>",
        "<i class='fa fa-angle-right'></i>"
    ]
});
$('.play').on('click', function () {
    owl2.trigger('autoplay.play.owl', [1000]);
});
$('.stop').on('click', function () {
    owl2.trigger('autoplay.stop.owl');
});

var owl2 = $('.prod-subother-owl-img');
var countsubpro = $('#relatedprocount').val();
if (countsubpro < 6) {
    $('.relateddiv').find(".owl-nav").css('display', 'none');
}
owl2.owlCarousel({
    items: 3,
    loop: false,
    margin: 10,
    stagePadding: 10,
    nav: true,
    responsive: {
        0: {
            items: 1
        },
        500: {
            items: 3
        },
        770: {
            items: 4
        },
        990: {
            items: 5
        },
        1200: {
            items: 6
        }

    },
    autoplay: true,
    rewind: true,
    animateOut: true,
    autoplayTimeout: 2000,
    autoplayHoverPause: true,
    navText: [
        "<i class='fa fa-angle-left'></i>",
        "<i class='fa fa-angle-right'></i>"
    ]
});
$('.play').on('click', function () {
    owl2.trigger('autoplay.play.owl', [1000]);
});
$('.stop').on('click', function () {
    owl2.trigger('autoplay.stop.owl');
});
/****End*****/

/*******Dangerous symbols********/

$(window).scroll(function () {
    var st = $(window).scrollTop();
    var ds = 600;

    if (st > ds) {
        $('.danger-menu').addClass('fixed');
    } else if (st < ds) {
        $('.danger-menu').removeClass('fixed');
    }
    var st = $(window).scrollTop();
    var ds = 400;

    if (st > ds) {
        $('.business-sub-menu').addClass('menu-fixed');
    } else if (st < ds) {
        $('.business-sub-menu').removeClass('menu-fixed');
    }
    var aa = $(window).scrollTop();
    var hn = 200;

    if (aa > hn) {
        $('.menu-container').addClass('hot-menu-fixed');
    } else if (aa < hn) {
        $('.menu-container').removeClass('hot-menu-fixed');
    }
});
/*********Dangerous symbol End*********/

//*****Gd country profile menu in detail page*****
$(window).scroll(function () {

    if ($(window).scrollTop() > 200) {
        $(".con-nav").addClass('stiky-co-nav');
    } else {
        $(".con-nav").removeClass('stiky-co-nav');
    }
});


//    var scr = $(window).scrollTop() > 700;
//    var ex = $("#country-geo").offset().top - 150;
//    var ex1 = $("#country-people").offset().top - 150;
//    var ex2 = $("#country-govn").offset().top - 150;
//    var ex3 = $("#country-econ").offset().top - 150;
//    var ex4 = $("#country-enegry").offset().top - 150;
//    var ex5 = $("#country-comm").offset().top - 150;
//    var ex6 = $("#country-trans").offset().top - 150;
//    var ex7 = $("#country-milit").offset().top - 150;
//    var ex8 = $("#country-trans-issue").offset().top - 150;
//
//
//    if (scr >= ex && scr <= ex1) {
//        $(".country-geo").addClass("active");
//    } else {
//        $(".country-geo").removeClass("active");
//    }
//    if (scr >= ex1 && scr <= ex2) {
//        $(".country-people").addClass("active");
//    } else {
//        $(".country-people").removeClass("active");
//    }
//    if (scr >= ex2 && scr <= ex3) {
//        $(".country-govn").addClass("active");
//    } else {
//        $(".country-govn").removeClass("active");
//    }
//    if (scr >= ex3 && scr <= ex4) {
//        $(".country-econ").addClass("active");
//    } else {
//        $(".country-econ").removeClass("active");
//    }
//    if (scr >= ex4 && scr <= ex5) {
//        $(".country-enegry").addClass("active");
//    } else {
//        $(".country-enegry").removeClass("active");
//    }
//    if (scr >= ex5 && scr <= ex6) {
//        $(".country-comm").addClass("active");
//    } else {
//        $(".country-comm").removeClass("active");
//    }
//    if (scr >= ex6 && scr <= ex7) {
//        $(".country-trans").addClass("active");
//    } else {
//        $(".country-trans").removeClass("active");
//    }
//    if (scr >= ex7 && scr <= ex8) {
//        $(".country-milit").addClass("active");
//    } else {
//        $(".country-milit").removeClass("active");
//    }
//    if (scr > ex8) {
//        $(".country-trans-issue").addClass("active");
//    } else {
//        $(".country-trans-issue").removeClass("active");
//    }

//******quotes sticky menu******
$(function () {
    $('.quotesmenu').sticky('.quotes-content'); // Initialize the sticky scrolling on an item
    //    ****business-blogs*****//
    $('.side-menu').sticky('.blog-whole'); // Initialize the sticky scrolling on an item
//    $('.side-menu1').sticky('.block-for-stky'); // Initialize the sticky scrolling on an item

    $('.buiness-menu-list').sticky('.business-menu'); // Initialize the sticky scrolling on an item
    $('.top-menu').sticky('.blog-whole');
    $('.menuquotes-mobile').sticky('.quotes-content');
});

//**************sticky function******
(function ($, window, undefined) {

    "use strict";

    /**
     * Sticky Element constructor
     * @param elm
     * @param par
     * @param options
     * @constructor
     */
    var Sticky = function (elm, par, options) {
        this.element = elm;
        this.parent = par;
        this._frozen = false;
        this.options = $.extend({
            animate: false,
            useFixed: true,
            animTime: 100
        }, options);
        this.init();
    };

    Sticky.prototype.init = function () {
        this.element.addClass("sticky-scroll");
        this.update();
    };

    Sticky.prototype.update = function () {
        //This will handle any resizing of the container the sticky scroll is in and update the boundaries if necessary
        this.setBoundaries();
        this.moveIt();
    };

    Sticky.prototype.moveIt = function () {
        // This will decide whether to move the stickied item
        var scrollTop = $(window).scrollTop();
        var height = this.element.outerHeight(true);
        var realStop = this._stop - height;

        if (this._parentHeight - this._offset > height && !this._frozen) {
            if (scrollTop >= this._start && scrollTop <= realStop) {
                if (this.options.useFixed) {
                    this.element.css({'position': 'fixed', 'top': 100, 'left': this.element.offset().left});
                } else {
                    this.updateOffset(scrollTop - this._start);
                }
            } else {
                this.element.css({'position': 'relative', 'left': 0});
                if (scrollTop < this._start) {
                    this.updateOffset(0);
                } else if (scrollTop > realStop) {
                    this.updateOffset(this._parentHeight - height - this._offset);
                }
            }
        }
    };

    Sticky.prototype.setBoundaries = function () {
        // This will set the boundaries the stickied item can move between and it's left position
        this._offset = this.element.position().top;
        this._start = this.parent.offset().top + this._offset;
        this._parentHeight = this.parent.outerHeight();
        this._stop = this._start + this._parentHeight - this._offset;
    };

    /**
     * Update Stickied Element's offset
     * @param yOffset
     */
    Sticky.prototype.updateOffset = function (yOffset) {
        if (!this._lastPosition !== yOffset) {
            // This moves the item
            if (this.animate) {
                this.element.stop().animate({
                    'top': yOffset
                }, this.animTime);
            } else {
                this.element.css('top', yOffset);
            }
            this._lastPosition = yOffset;
        }
    };

    Sticky.prototype.toggleFreeze = function () {
        // This will freeze the stickied item in place wherever it is
        this._frozen = !this._frozen;
    };

    $.fn.sticky = function (par, options) {
        var method, args, ret = false;
        if (typeof options === "string") {
            args = [].slice.call(arguments, 0);
        }

        this.each(function () {
            var self = $(this);
            var parent = par;
            if (parent) {
                parent = self.parent().closest(parent);
            } else {
                parent = self.parent();
            }
            parent.css({'position': 'relative'}); // Set parent position to relative
            self.css({'position': 'relative'}); // Set item position to relative
            var instance = self.data("stickyInstance");

            if (instance && options) {
                if (typeof options === "object") {
                    ret = $.extend(instance.options, options);
                } else if (options === "options") {
                    ret = instance.options;
                } else if (typeof instance[options] === "function") {
                    ret = instance[options].apply(instance, args.slice(1));
                } else {
                    throw new Error("Sticky Element has no option/method named " + method);
                }
            } else {
                instance = new Sticky(self, parent, options || {});
                self.data("stickyInstance", instance);
                $.fn.sticky._instances.push(instance);
            }
        });
        return ret || this;
    };

    $.fn.sticky._instances = [];

    $(window).on({
        'resize': function (e) {
            // Update the position/offset changed on resize and move
            $.each($.fn.sticky._instances, function () {
                this.update();
            });
        },
        'scroll': function () {
            // Move all those suckers on scroll
            $.each($.fn.sticky._instances, function () {
                if (!this._frozen) {
                    this.moveIt();
                }
            });
        }
    });
}(jQuery, window));


//$(window).scroll(function () {
//    var aa = $(window).scrollTop();
//    var ab = $('.top-banner,.wrap-margin,.whole-hot-news,.industri-newss-banner').offset().top;
//    if (aa >= ab) {
//        $('.menu-container').addClass('hot-menu-fixed');
//
//    } else {
//        $('.menu-container').removeClass('hot-menu-fixed');
//
//    }
//});

//$(function () {
//    $('.side-sub-menu').sticky('.blog-position'); // Initialize the sticky scrolling on an item
//});

//*******wmbox for video(hidded)*******
(function ($) {
    $.wmBox = function () {
        $('body').prepend('<div class="wmBox_overlay_video"><div class="wmBox_centerWrap"><div class="wmBox_centerer">');
    };
    $('[data-popup]').click(function (e) {
        e.preventDefault();
        $('.wmBox_overlay_video').fadeIn(750);
        var mySrc = $(this).attr('data-popup');
        $('.wmBox_overlay_video .wmBox_centerer').html('<div class="wmBox_contentWrap"><div class="wmBox_scaleWrap"><div class="wmBox_closeBtn"><p>x</p></div><iframe src="' + mySrc + '">');

        $('.wmBox_overlay_video iframe').click(function (e) {
            e.stopPropagation();
        });
        $('.wmBox_overlay_video').click(function (e) {
            e.preventDefault();
            $('.wmBox_overlay_video').fadeOut(750);
        });
    });
}(jQuery));
///********************* go-to-top script *********
$(window).scroll(function () {
    var st = $(window).scrollTop();
    var mw = 300;

    if (st > mw) {
        $('.ad_sky1,.ad_sky2').css({'opacity': '1','visibility':'visible'}),100;
        $('.top-fixed').css({'z-index': '10'});
        $('.top-fixed-menu').css({'opacity': '1'});
        $('.go-top').css({'right': '20px'});
        
    } else if (st < mw) {
        $('.ad_sky1,.ad_sky2').css({'opacity': '0','visibility':'hidden'}),100;
        $('.top-fixed').css({'z-index': '-1'});
        $('.top-fixed-menu').css({'opacity': '0'});
        $('.go-top').css({'right': '-40px'});
    }
});
//**************************** ad banner success page **************
$("#bnpay_suc").on("click", function () {
    $('#view_bnsucc').css('display', 'block');
    $('.view_succ_btsec').css('display', 'none');
});
$('#bnpay_fail').on("click", function () {
    $('#view_bnfail').css('display', 'block');
    $('.view_succ_btsec').css('display', 'none');
});
$('#view_bnclose,#view_bnclose1').on("click", function () {
    $('#view_bnsucc').css('display', 'none');
    $('#view_bnfail').css('display', 'none');
    $('.view_succ_btsec').css('display', 'block');
});
/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :   Blog,B2B, B2C, 
 Description     :   Blog scripts
 Included        :   
 Last Modified   :   Aug 14,2017 / Arivarasi
 Assigned to     :   Vidhya
 */
////// to check blog name already assigned or not, based on email//

$("#mem_location").select2({
    placeholder: 'Choose country',
    selectOnClose: true,
    matcher: function (params, data) {
        return matchStart(params, data);
    }
});
$("#txtcountry").select2({
    placeholder: 'Choose country',
    selectOnClose: true,
    matcher: function (params, data) {
        return matchStart(params, data);
    }
});

$(function () {
    $('#mem_location').next('.select2').find('.select2-selection').one('focus', select2Focus).on('blur', function () {
        $(this).one('focus', select2Focus);
    });
    $('#txtcountry').next('.select2').find('.select2-selection').one('focus', select2Focus).on('blur', function () {
        $(this).one('focus', select2Focus);
    });

    function select2Focus() {
        $(this).closest('.select2').prevAll('#mem_location').select2('open');
        $(this).closest('.select2').prevAll('#txtcountry').select2('open');
    }
});

$(".toggle-password").click(function () {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
});


function alreadyemail_user(email, type) {
    if (!validateEmail(email)) {
        return false;
    }
    if (email !== '') {
        $.ajax({
            type: 'GET',
            url: URL_LOGIN_PATH + '/getemail',
            dataType: 'jsonp',
            data: {
                emailid: email
            },
            crossDomain: true
        }).done(function (e) {
            var countrows = e.cntrows;
            var blog_title = e.blog_title;

            if (countrows > 0) {
                document.getElementById("alreadymail").style.color = "red";
                $('#alreadymail').html('Email id already exist');
                $('#blog_title_already').val('');
                $('#signupbtn').attr('disabled', 'disabled');

                setTimeout(function () {
                    if (blog_title === '' && email !== '') {
                        $('#newblog_title').show('fast');
                    } else {
                        $('#blog_title_already').val(blog_title);
                        $('#newblog_title').hide('fast');
                    }

                    $('#newemail').val('');
                    $('#alreadymail').html('');
                    $('#newemail').focus();
                    $('#oldemail').val(email);
                }, 2000);

            } else {

                /* sign-up form purpose */
                $('#signupbtn').removeAttr('disabled');
                /* ends */
//                document.getElementById("alreadymail").style.color = "";
                $('#alreadymail').html('');
//                document.getElementById("emaildoes").style.color = "red";
                $('#emaildoes').html('Email does not exist');
                $('#oldemail').focus();
                if (blog_title === '' && email !== '') {
                    $('#newblog_title').show('fast');
                } else {
                    $('#blog_title_already').val(blog_title);
                    $('#newblog_title').hide('fast');
                }
                setTimeout(function () {
                    $('#emaildoes').html('');
                    $('#oldemail').val('');
                }, 2000);
            }

        }).fail(function (error) {
            console.log(error.statusText);
        });
    }
}
/// user details view for suspicious activity ///
function suspicious_alreadyemail_user(email, type) {
    if (!validateEmail(email)) {
        return false;
    }
    if (email !== '') {
        $.ajax({
            type: 'GET',
            url: URL_LOGIN_PATH + '/getemail',
            dataType: 'jsonp',
            data: {
                emailid: email
            },
            crossDomain: true
        }).done(function (e) {
            var countrows = e.cntrows;
            if (countrows > 0) {
                document.getElementById("getalreadymail").style.color = "red";
                $('#getalreadymail').html('Email id already exist');
                $('#signupbtn').attr('disabled', 'disabled');

                setTimeout(function () {
                    $('#getnewemail').val('');
                    $('#getalreadymail').html('');
                    $('#getoldemail').val(email);
                }, 2000);

            } else {

                /* sign-up form purpose */
                $('#signupbtn').removeAttr('disabled');
                /* ends */
                document.getElementById("getalreadymail").style.color = "";
                $('#getalreadymail').html('');
                document.getElementById("getemaildoes").style.color = "red";
                $('#getemaildoes').html('Email does not exist');
                $('#getoldemail').focus();
                setTimeout(function () {
                    $('#getemaildoes').html('');
                    $('#getoldemail').val('');
                }, 2000);
            }

        }).fail(function (error) {
            console.log(error.statusText);
        });
    }
}
/// email validation ///
function validateEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}
///To check mobile number already exist or not ///
function alreadymobile_user(mobile) {
    if (mobile !== '') {
        $.ajax({
            type: 'GET',
            url: URL_LOGIN_PATH + '/getmobile',
            dataType: 'jsonp',
            data: {
                mobileno: mobile
            },
            crossDomain: true
        }).done(function (e) {
            var countrows = e.cntrows;
            if (countrows > 0) {
                document.getElementById("alreadymobile").style.color = "red";
                $('#alreadymobile').html('Mobile number is already exist');

                setTimeout(function () {
                    $('#alreadymobile').html('');
                    $('#mobile').val('');
                }, 2000);
            } else {
                document.getElementById("alreadymobile").style.color = "";
                $('#alreadymobile').html('');
            }

        }).fail(function (error) {
            console.log(error.statusText);
        });
    }
}
///////// not used /////////////
function CheckallCheckbox(source, formname) {
    checkboxes = document[formname].getElementsByTagName('input');
    for (var i in checkboxes)
        checkboxes[i].checked = source.checked;
}
//// blog theme color settings ////
$(function () {
    $('.blogTheme').click(function () {
        $(this).siblings('input:checkbox').prop('checked', false);
    });
    $('#remove-spec_1').click(function () {
        $('#gen_spec1').val('');
        $("#gen_spec_function1").select2("val", "");
    });
});
/*
 Project Title   :   Bizbilla;
 Version         :   3.0;
 Title           :   user dashboard pages ;
 Description     :   for user dashboard profile scripts are here.This JS is Imported in js-fef file;
 Included        :   
 Last Modified   :   Aug 15,2017 / Rajapriya;
 Assigned to     :   kalaivanan,Bhuvana,Aravind;
 */



$(document).ready(function () {
    

    /*----------- add country in company profile form --------------*/

    $('#profilecountry').change(function () {
        var country = $('#profilecountry').val();
//        console.log(country);
        $.ajax({
            url: 'selectstate',
            data: {country: country},
            dataType: 'json',
            type: 'post',
            success: function (output) {
//                var jsondata = $.parseJSON(output);
//                for (var i = 0; i < jsondata.length; ++i)
//                {
//                    console.log(jsondata[i].ascii_name);
//                    $('#profilestate').html('<option value=' + jsondata[i].admin_code + '>' + jsondata[i].ascii_name + '</option>');
//                }
                $('#profilestate').html('');
                $.each(output, function (i, value) {
                    $('#profilestate').append($('<option>').text(value.ascii_name).attr('value', value.admin_code));
                });
            }
        });
    });

    /* ---------company profile slect state-----------  */
    $('#profilestate').change(function () {
        var country = $('#profilecountry').val();
        var state = $('#profilestate').val();
//        console.log(country);
        $.ajax({
            url: 'selectcity',
            data: {country: country, state: state},
            dataType: 'json',
            type: 'post',
            success: function (output) {
//                var jsondata = $.parseJSON(output);
//                for (var i = 0; i < jsondata.length; ++i)
//                {
//                    console.log(jsondata[i].ascii_name);
//                    $('#profilestate').html('<option value=' + jsondata[i].admin_code + '>' + jsondata[i].ascii_name + '</option>');
//                }
                $('#profile_city').html('');
                $.each(output, function (i, value) {
                    $('#profile_city').append($('<option>').text(value.asciiname).attr('value', value.id));
                });
            }
        });
    });
    /* company profile form for product comparition */

    $('#compare')
            .click(function () {
                $('#errormsg')
                        .html('');
                var count = $("[type='checkbox'][name='product_id[]']:checked")
                        .length;
                var val = [];
                $(':checkbox:checked').each(function (i) {
                    val[i] = $(this).val();
                });
                if (count < 2) {
                    $('#errormsg')
                            .html('<div class="alert alert-info text-center">Please select minimum two products to compare</div>');
                    //                    alert('Please select minimum two products to compare')
                } else if (count >= 5) {
                    $('#errormsg')
                            .html('<div class="alert alert-info text-center">You can compare four products only at a time</div>');
                    //                    alert('You can compare four products only at a time');
                } else {
                    alert(val);
                    $('#errormsg')
                            .html('');
                    window.location = '/profile/inquirycart-compare?productid=' + val;
                }

            });
    /////////////////////company profile- auto adjust textarea/////////////////////
    $('.comp-pf-txtarea').each(function () {
        this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;min-height:50px;');
    }).on('input', function () {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
    ///////////////////////////////////////////////////
});

/* ---------remove fields for halal product and manange prodcut-----------*/
function removefields(nonactive, profactive) {
    console.log("remove");
    $('.' + nonactive).removeClass('active');
    $(profactive).addClass('active');
}
/* ---------add fields for halal product and manange prodcut-----------*/
function addfields(nonactive, profactive) {
    console.log("add");
    $('.' + nonactive).removeClass('active');
    $(profactive).addClass('active');
}
/* ------------- add prodcuts inquiry   ---------------*/
function addInquiryCart(e) {
    // $("#cart_" + e).html("");
    var t = e;
    $.ajax({
        url: "cartinsert",
        data: {
            product_id: t
        },
        type: "POST",
        success: function (e) {

            $('#cartcount').html(e);
            // $('#cartcount').text(e);
            //  $("#inqiry-icon_" + t).addClass('no-display');
            // $("#already-icon_" + t).show();
            //            $("#already-icon_" + t).show();
            //  $("#cart_" + t).html('<span style="color:#fff;cursor:default" class="prolist-headname prolist-compname normal-font col-lg-12 col-md-6 col-sm-8 col-xs-6 padding0">Added to cart</span>');
            // $("#inquiry_cart_" + t).hide()

        }
    })
}
/*  inquiry for compare product */

function enqcompvalid() {
    var chks = document.getElementsByName('product_id[]');
    var hasChecked = false;
    for (var i = 0; i < chks.length; i++) {
        if (chks[i].checked) {
            hasChecked = true;
            break;
        }
    }
    if (hasChecked == false) {
        alert("Please select atleast one Product.");
        return false;
    } else {
//        $('#enquirycart_compare')
//        .submit();
    }
}







$(document).ready(function () {
//**********************************  compose mail light box ***************************************
//
//*************************************    end compose mail  *******************************
//***************************** message full-screen ********************************

    var c = 0;
    $('.menu-icon').click(function () {
        if (c == 0) {
            $('.slide-out').animate({'left': '0px'});
            c = 1;
        } else {
            $('.slide-out').animate({'left': '-300px'});
            c = 0;
        }
    });
///////////////////////////// end message full-screen  ///////////////
    $('.profile-search-icon').click(function () {
        $('.profile-search-div').css({'display': 'block', 'transition': 'all linear 200ms'});
    });
    $('.profile-search-close').click(function () {
        $('.profile-search-div').css({'display': 'none', 'transition': 'all linear 200ms'});
    });

// Collapse Panels

    (function ($, window, document) {
        var panelSelector = '[data-perform="panel-collapse"]';

        $(panelSelector).each(function () {
            var $this = $(this),
                    parent = $this.closest('.panel'),
                    wrapper = parent.find('.panel-wrapper'),
                    collapseOpts = {toggle: false};

            if (!wrapper.length) {
                wrapper =
                        parent.children('.panel-heading').nextAll()
                        .wrapAll('<div/>')
                        .parent()
                        .addClass('panel-wrapper');
                collapseOpts = {};
            }
            wrapper
                    .collapse(collapseOpts)
                    .on('hide.bs.collapse', function () {
                        $this.children('i').removeClass('fa fa-minus').addClass('fa fa-plus');
                    })
                    .on('show.bs.collapse', function () {
                        $this.children('i').removeClass('fa fa-plus').addClass('fa fa-minus');
                    });
        });
        $(document).on('click', panelSelector, function (e) {
            e.preventDefault();
            var parent = $(this).closest('.panel');
            var wrapper = parent.find('.panel-wrapper');
            wrapper.collapse('toggle');
        });
    }(jQuery, window, document));

    // Remove Panels

    (function ($, window, document) {
        var panelSelector = '[data-perform="panel-dismiss"]';
        $(document).on('click', panelSelector, function (e) {
            e.preventDefault();
            var parent = $(this).closest('.panel');
            removeElement();

            function removeElement() {
                var col = parent.parent();
                parent.remove();
                col.filter(function () {
                    var el = $(this);
                    return (el.is('[class*="col-"]') && el.children('*').length === 0);
                }).remove();
            }
        });
    }(jQuery, window, document));

});

//        ...............



//common form



//$('input,select,textarea').on('focusin', function () {
//    $(this).parent().find('label').addClass('active');
//});
//$('input,select,textarea').on('focusout', function () {
//    if (!this.value) {
//        $(this).parent().find('label').removeClass('active');
//    }
//});
//
//$('input,select,textarea').on('focusin', function () {
//    $(this).parent().find('input,textarea,select').addClass('active-border');
//});
//$('input,select,textarea').on('focusout', function () {
//    if (!this.value) {
//        $(this).parent().find('input,textarea,select').removeClass('active-border');
//    }
//});
/////////////
//$('input,select,textarea').on('load', function () {
//    if ($(this).val() != '')
//        $(this).parent().find('label').addClass('active');
//});


//var server_validate = $('#server_validate').val();
//
//if (server_validate === 1) {
////    $('#hotel_form').validate({
//      $('input,select,textarea').on('validate', function () {
//        $(this).parent().find('label').addClass('active');
//    });
//    $('input,select,textarea').load(function () {
//    $(this).parent().find('label').addClass('active');
//});
////    });
//
//}

//$('input,select,textarea').on('validate', function () {
//    $(this).parent().find('label').addClass('active');
//});
//$('input,select,textarea').load(function () {
//    $(this).parent().find('label').addClass('active');
//});
//$('input,select,textarea').on('invalid', function () {
//    if (!this.value) {
//        $(this).parent().find('label').removeClass('active');
//    }
//});


//function myFunction() {
//    var inpObj = document.getElementByClass(".form-control");
//    if (inpObj.checkValidity() == false) {
//        document.getElementByClass("demo").innerHTML = inpObj.validationMessage;
//        $(this).parent().find('label').addClass('active');
//    }
//}









//////////////////////////////////////////////////////////////////



$(document).ready(function ($) {

//    $(".btn-mail-keys").click(function () {
//        $(".msg-full-view").addClass("msg-fullscreen");
//    });
//    $(".close").click(function () {
//        $(".msg-full-view").removeClass("msg-fullscreen");
////        $(".msg-full-view").addClass("close");
//    });

    /*--------for full screen message view (old design)-------------*/
    var s = 1;
    $('#fullscreen').click(function () {
        if (s == 1)
        {
            $(".mail_listing").addClass("msg-fullscreen");
            $('#fullscreen').children('span').removeClass('fa fa-arrows-alt').addClass('fa fa-expand');
            s = 0;
        } else {
            $('.mail_listing').removeClass('msg-fullscreen');
            $('#fullscreen').children('span').removeClass('fa fa-expand').addClass('fa fa-arrows-alt');
            s = 1;
        }
    });




    $('.bann-search-box').focusin(function () {
        $(this).parent('.border').addClass('shadow-active');
    });
    $('.bann-search-box').focusout(function () {
        $(this).parent('.border').removeClass('shadow-active');
    });


    var owl = $('.bcc-owl');
    owl.owlCarousel({
        loop: true,
        nav: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
        margin: 10,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 3
            },
            960: {
                items: 5
            },
            1200: {
                items: 7
            }
        }
    });
//    owl.on('mousewheel', '.owl-stage', function (e) {
//        if (e.deltaY > 0) {
//            owl.trigger('next.owl');
//        } else {
//            owl.trigger('prev.owl');
//        }
//        e.preventDefault();
//    });

});
$(document).ready(function () {
    var c = 1;
    $('.hide-open-form').click(function () {
        if (c == 1)
        {
            $('.cat-nav').animate({
                'bottom': '0px'
            });
            $('.menu-icon').addClass('open');
            c = 0;
        } else {
            $('.cat-nav').animate({
                'bottom': '-170px'
            });
            $('.menu-icon').removeClass('open');
            c = 1;
        }
    });


//----------------------------------------Classifieds company profile form----------------------------------

//    var navListItems = $('div.setup-panel div a'),
//            allWells = $('.setup-content'),
//            allNextBtn = $('.nextBtn'),
//            allPrevBtn = $('.prevBtn');
//
//    allWells.hide();
//
//    navListItems.click(function (e) {
//        e.preventDefault();
//        var $target = $($(this).attr('href')),
//                $item = $(this);
//
//        if (!$item.hasClass('disabled')) {
//            navListItems.removeClass('btn-prim').addClass('btn-def');
//            $item.addClass('btn-prim');
//            allWells.hide();
//            $target.show();
//            $target.find('input:eq(0)').focus();
//        }
//    });
//
//    allPrevBtn.click(function () {
//        var curStep = $(this).closest(".setup-content"),
//                curStepBtn = curStep.attr("id"),
//                prevStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a");
//
//        prevStepWizard.trigger('click');
//    });
//
//    allNextBtn.click(function () {
//        var curStep = $(this).closest(".setup-content"),
//                curStepBtn = curStep.attr("id"),
//                nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
//                curInputs = curStep.find("input[type='text'],input[type='url']"),
//                isValid = true;
//
//        $(".form-group").removeClass("has-error");
//        for (var i = 0; i < curInputs.length; i++) {
//            if (!curInputs[i].validity.valid) {
//                isValid = false;
//                $(curInputs[i]).closest(".form-group").addClass("has-error");
//            }
//        }
//
//        if (isValid)
//            nextStepWizard.removeAttr('disabled').trigger('click');
//    });
//
//    $('div.setup-panel div a.btn-prim').trigger('click');

//--------------------------------------------END OF CLASSIFIEDS COMPANY PROFILE FORM-----------------------------------------


});

//accordian for profilemenu & helpdesk

$(function () {

    var Accordion = function (el, multiple) {
        this.el = el || {};
        this.multiple = multiple || false;
        // Variables privadas
        var links = this.el.find('.link');
        // Evento
        links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown);
    };
    Accordion.prototype.dropdown = function (e) {
        var $el = e.data.el;
        $this = $(this),
                $next = $this.next();
        $next.slideToggle();
        $this.parent().toggleClass('open');
        if (!e.data.multiple) {
            $el.find('.helpdesk-submenu').not($next).slideUp().parent().removeClass('open');
        }
    };
    var accordion = new Accordion($('#helpdesk-accordion'), false);

//    ***************  message view ****************************
});





//$(function () {
//    $('.profile-pic-box .member-data').click(function () {
//        $('.profile-data').stop().slideToggle();
//        $(this).children('span').toggleClass('open');
//    });
//});


//
//var bscurl = $('#bscurl').val();
//$('#subcategory').multiselect({
//    maxHeight: '300',
//});
//function getbscsubcategory(cats) {
//    if (cats !== '') {
//        $('#subcategory').multiselect('destroy');
//        var catdet = cats.split('|*');
//        var catid = catdet[0];
//        $.ajax({
//            url: bscurl + '/gethelps',
//            data: {action: 'getSubCategory', catid: catid},
//            dataType: 'json',
//            type: 'POST',
//            success: function (data) {
////               var output = '<option value="">--Select Subcategory--</option>';
//                var output;
//                $.each(data, function (index, data) {
//                    var id = data.id;
//                    var name = data.name;
//                    var slug = data.slug;
//                    var allval = id + "|*" + name + "|*" + slug;
//                    output += "<option value='" + allval + "'>" + name + "</option>";
//                });
//
//                $('#subcategory').attr('multiple', 'multiple');
//                $('#subcategory').html(output);
//                $('#subcategory').multiselect({
//                    maxHeight: '300'
//                });
//            }
//        });
//    }
//}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* Set Progress | jQuery
 ======================================*/
/*
 $(document).ready(function(){
 var max = 150.72259521484375;
 $.each($('.progress'), function( index, value ){
 percent = $(value).data('progress');
 $(value).children($('.fill')).attr('style', 'stroke-dashoffset: ' + ((100 - percent) / 100) * max);
 $(value).children($('.value')).text(percent + '%');
 });
 });
 */


var forEach = function (array, callback, scope) {
    for (var i = 0; i < array.length; i++) {
        callback.call(scope, i, array[i]);
    }
};
window.onload = function () {
    var max = -219.99078369140625;
    forEach(document.querySelectorAll('.progress-cir'), function (index, value) {
        percent = value.getAttribute('data-progress');
        value.querySelector('.fill').setAttribute('style', 'stroke-dashoffset: ' + ((100 - percent) / 100) * max);
        value.querySelector('.value').innerHTML = percent + '%';
    });
}



/*
 
 Used to calc the variable 'max'
 and set 'stroke-dasharray' and
 'stroke-dashoffset' in the css
 
 
 console.log(document.querySelector('.fill').getTotalLength());
 
 */
///////////////////////////////////////////////////////////////////////////////////////////////////

//
//$(document).ready(function () {
//    $(".progress-bar").loading();
//    $('input').on('click', function () {
//        $(".progress-bar").loading();
//    });
//});
//
//(function ($) {
//    $.fn.loading = function () {
//        var DEFAULTS = {
//            backgroundColor: '#b3cef6',
//            progressColor: '#4b86db',
//            percent: 79,
//            duration: 2000
//        };
//
//        $(this).each(function () {
//            var $target = $(this);
//
//            var opts = {
//                backgroundColor: $target.data('color') ? $target.data('color').split(',')[0] : DEFAULTS.backgroundColor,
//                progressColor: $target.data('color') ? $target.data('color').split(',')[1] : DEFAULTS.progressColor,
//                percent: $target.data('percent') ? $target.data('percent') : DEFAULTS.percent,
//                duration: $target.data('duration') ? $target.data('duration') : DEFAULTS.duration
//            };
//            // console.log(opts);
//
//            $target.append('<div class="background"></div><div class="rotate"></div><div class="left"></div><div class="right"></div><div class=""><span>' + opts.percent + '%</span></div>');
//
//            $target.find('.background').css('background-color', opts.backgroundColor);
//            $target.find('.left').css('background-color', opts.backgroundColor);
//            $target.find('.rotate').css('background-color', opts.progressColor);
//            $target.find('.right').css('background-color', opts.progressColor);
//
//            var $rotate = $target.find('.rotate');
//            setTimeout(function () {
//                $rotate.css({
//                    'transition': 'transform ' + opts.duration + 'ms linear',
//                    'transform': 'rotate(' + opts.percent * 3.6 + 'deg)'
//                });
//            }, 1);
//
//            if (opts.percent > 50) {
//                var animationRight = 'toggle ' + (opts.duration / opts.percent * 50) + 'ms step-end';
//                var animationLeft = 'toggle ' + (opts.duration / opts.percent * 50) + 'ms step-start';
//                $target.find('.right').css({
//                    animation: animationRight,
//                    opacity: 1
//                });
//                $target.find('.left').css({
//                    animation: animationLeft,
//                    opacity: 0
//                });
//            }
//        });
//    }
//})(jQuery);



////////////////////////////////////////////////////////////////////////////

(function ($) {
    $.fn.progress = function () {
        var percent = this.data("percent");
        this.css("width", percent + "%");
    };
}(jQuery));

$(document).ready(function () {
    $(".bar-one .bar").progress();
    $(".bar-two .bar").progress();
    $(".bar-three .bar").progress();
    $(".bar-fore .bar").progress();
});

//////////////////////////////////////////////////////////////////////////////
//***************************Order page***********************
$(document).ready(function () {
    $('.track-button').click(function () {
        $('.o-right-fixed').animate({"right": "0px"});
        $('.order-overlay').css("display", "block");
        $('.profile-secnd-wrap').css("position", "fixed");
    });
    $('.order-overlay').click(function () {
        $('.o-right-fixed').animate({"right": "-400px"});
        $('.order-overlay').css("display", "none");
        $('.profile-secnd-wrap').css("position", "static");
    });
    $('.ecommer-overlay, .ecom-order button, .ecom-close').click(function () {
        $('.modal-ecom-order').css("display", "none");
        $('.ecommer-overlay').css("display", "none");
        $('.profile-secnd-wrap').css("position", "static");
    });
});
function order_close() {
    $('.o-right-fixed').animate({"right": "-400px"});
    $('.order-overlay').css("display", "none");
    $('.profile-secnd-wrap').css("position", "static");
}
//***************************Order page end***********************

//$( window ).load(function() {
$(document).ready(function () {
    $(".line1").delay(300).addClass('anim-1');
    $(".line2").delay(600).addClass('anim-2');
    $(".line3").delay(900).addClass('anim-3');
});


//*************************** wizard step*******************

$(document).ready(function () {

    var navListItems = $('div.setup-panel div a'),
            allWells = $('.setup-content'),
            allNextBtn = $('.nextBtn'),
            allPrevBtn = $('.prevBtn');

    allWells.hide();

    navListItems.click(function (e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
                $item = $(this);

        if (!$item.hasClass('disabled')) {
            navListItems.removeClass('btn-primary').addClass('btn-default');
            $item.addClass('btn-primary');
            allWells.hide();
            $target.show();
            $target.find('input:eq(0)').focus();
        }
    });

    allNextBtn.click(function () {
        var curStep = $(this).closest(".setup-content"),
                curStepBtn = curStep.attr("id"),
                nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
                curInputs = curStep.find("input[type='text'],input[type='url']"),
                isValid = true;

        $(".form-group").removeClass("has-error");
        for (var i = 0; i < curInputs.length; i++) {
            if (!curInputs[i].validity.valid) {
                isValid = false;
                $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
        }

        if (isValid)
            nextStepWizard.removeAttr('disabled').trigger('click');
    });

    allPrevBtn.click(function () {
        var curStep = $(this).closest(".setup-content"),
                curStepBtn = curStep.attr("id"),
                prevStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a");

        $(".form-group").removeClass("has-error");
        prevStepWizard.removeAttr('disabled').trigger('click');
    });

    $('div.setup-panel div a.btn-primary').trigger('click');
});


//*************************** wizard step*******************

$(function () {
//    $('a[title]').tooltip();

    $('.btn-submit').on('click', function (e) {

        var formname = $(this).attr('name');
        var tabname = $(this).attr('href');

        if ($('#' + formname)[0].checkValidity()) { /* Only works in Firefox/Chrome need polyfill for IE9, Safari. http://afarkas.github.io/webshim/demos/ */
            e.preventDefault();
            $('ul.nav li a[href="' + tabname + '"]').parent().removeClass('disabled');
            $('ul.nav li a[href="' + tabname + '"]').trigger('click');
        }

    });

    $('ul.nav li a').on('click', function (e) {
//        console.log("yes");
        if ($(this).hasClass('enabled')) {
            e.preventDefault();
            return false;
        }
    });


});
function emailalreadyexistsval(emailvalue) {

    if (emailvalue != '') {
        $.ajax({
            url: URL_MAIN_PATH + '/emailalreadyexist',
            data: {emailvalue: emailvalue},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                var succval = output.succ_val;
                if (succval == 1) {
                    $('#alreadyexist').show();
                    $('#new_email').val('');
                } else {
                    $('#alreadyexist').hide();
                }
            }
        });
    }
}
function mobilealreadyexist(mobilevalue) {
    if (mobilevalue != '') {
        $.ajax({
            url: URL_MAIN_PATH + '/mobilealreadyexist',
            data: {mobilevalue: mobilevalue},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                var succval = output.succ_val;
                if (succval == 1) {
                    $('#alreadymobexist').show();
                    $('#new_mobile').val('');
                } else {
                    $('#alreadymobexist').hide();
                }
            }
        });
    }
}
//function order_unit(orderunit) {
////    $('#min_order_unit option[value="' + orderunit + '"]').prop('selected', true);
////    $('#production_capacity_unit option[value="' + orderunit + '"]').prop('selected', true);
//
//}

//////////////////////////////////////profile tab/////////////////////////////////////////

$(document).ready(function () {
    $(".resp-search").click(function () {
        $(".menu-search").slideToggle("100");
    });
//    $('.nd-whole').css({'display': 'none'});
});

//***************Profile Product Quantity********
//$(document).ready(function () {
//    var maxvalue = 4;
//
//    // Add button click handler
//    $('#surveyForm')
//            .on('click', '.addButton', function () {
//                var $template = $('#optionTemplate'),
//                        $clone = $template
//                        .clone()
//                        .removeClass('hide')
//                        .removeAttr('id')
//                        .insertBefore($template),
//                        $option = $clone.find('[name="option[]"]');
//            })
//
//            // Remove button click handler
//            .on('click', '.qtyremove', function () {
//                var $row = $(this).parents('.hide_field'),
//                        $option = $row.find('[name="option[]"]');
//                $row.remove();
//            })
//
//            // Called after adding new field
//            .on('click', '.addButton', function (e, data) {
//                //  stockunitchangeone();
//                $dafield = $('#surveyForm').find('.hide_field').attr("name");
//
//                if ($dafield === 'add_num') {
//                    if ($('#surveyForm').find(':visible[name="add_num"]').length >= maxvalue) {
//                        $('#surveyForm').find('.addButton').attr('disabled', 'disabled');
//                    }
//                }
//                stockunitchangeone();
//            })
//
//            // Called after removing the field
//            .on('click', '.qtyremove', function (e, data) {
//                if ($dafield === 'add_num') {
//                    if ($('#surveyForm').find(':visible[name="add_num"]').length < maxvalue) {
//                        $('#surveyForm').find('.addButton').removeAttr('disabled');
//                    }
//                }
//            });
//
//});

/*------------ basic form hover effect -----------*/
$(document).ready(function () {                            
//    $("#radio_1, #radio_2", "#radio_3").change(function () {
//        if ($("#radio_1").is(":checked")) {
//            $('#div1').show();
//        }
//        else if ($("#radio_2").is(":checked")) {
//            $('#div2').show();
//        }
//        else 
//            $('#div3').show();
//    }); 
    
//    var forma_pago = $("input[name=mem_type]:radio").val();
//      console.log(forma_pago);
//if (forma_pago == undefined) {
//        $('.nd-whole').css({'display': 'block'});
//    } else {
//        $('.nd-whole').css({'display': 'none'});
//      
//    }
       
});


$(document).ready(function() {
    $("div.pf-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.pf-tab>div.pf-tab-content").removeClass("active");
        $("div.pf-tab>div.pf-tab-content").eq(index).addClass("active");
    });
});
/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :   Tradeshows, Business classifieds
 Description     :   Tradeshows & Business classifieds scripts are in this file.
 Included        :   
 Last Modified   :   Aug 15,2017 / Arivarasi
 Assigned to     :   Ramesh Kumar
 */
$(document).ready(function () {
    //   $('#trade_subcategory').select2();
    // date scripts for starting date //
//    console.log(ConvertTimeZone);

    $('#from_date').datepicker({
//                startDate: 'now',
        startDate: new Date(ConvertTimeZone),
        autoclose: true
    });

    $('#from_date')
            .on('changeDate', function (e) {
                var x = $('#from_date')
                        .val();
                $('#from_date')
                        .val(x);
                $('#to_date')
                        .datepicker('setStartDate', x)
                        .datepicker('update');
                $('#from_date')
                        .parent()
                        .addClass('has-success');
                $('#from_date')
                        .parent()
                        .removeClass('has-error');
                $('#from_date')
                        .addClass('valid');
                $('#from_date')
                        .removeClass('error');
                $('.help-block')
                        .empty();
                $('.valid')
                        .css({
                            'border-color': '#3c763d'
                        });
            });
    // date scripts for Ending date //
    $('#to_date')
            .datepicker({
//                startDate: 'now',
                startDate: new Date(ConvertTimeZone),
                autoclose: true
            });
    $('#to_date')
            .on('changeDate', function (e) {
                var x = $('#to_date')
                        .val();
                $('#from_date')
                        .datepicker('setEndDate', x)
                        .datepicker('update');
                $('#to_date')
                        .parent()
                        .addClass('has-success');
                $('#to_date')
                        .parent()
                        .removeClass('has-error');
                $('#to_date')
                        .addClass('valid');
                $('#to_date')
                        .removeClass('error');
                $('.help-block')
                        .empty();
                $('.valid')
                        .css({
                            'border-color': '#3c763d'
                        });
            });
    // function used in date of issue //
    $('#onlinefrom_date')
            .datepicker({
                endDate: 'now',
                autoclose: true,
                todayHighlight: true
            });
    // function to select country //
    $('#txtcountry').change(function () {
        var country = $('#txtcountry').val();
        var countrycode = country.split(",");
        var countryid = countrycode[0];
        $.ajax({
            url: 'selectstate',
            data: {country: countrycode},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                $('#state').html('<option value="">--Select State--</option>');
                $.each(output, function (i, value) {
                    $('#state').append($('<option>').text(value.ascii_name).attr('value', value.admin_code));
                });
            }
        });
    });
    /// addbanner for hotel- to select country ///
    $('#txtcountryhotel').change(function () {
        var country = $('#txtcountryhotel').val();
        var countrycode = country.split(",");
        var countryid = countrycode[0];
        $.ajax({
            url: 'selecthotelcity',
            data: 'country=' + country,
            dataType: 'json',
            type: 'post',
            success: function (output) {
                $('#cityhotel').html('<option class="hidden" value="">--Select city--</option>');
                $.each(output, function (i, value) {
                    console.log(value);
                    $('#cityhotel').append($('<option>').text(value.city).attr('value', value.city));
                });
            }
        });
    });
    // to select country in tradeshow post form //
    $('#txthomecountry').change(function () {
        var country = $('#txthomecountry').val();
        var countrycode = country.split(",");
        var countryid = countrycode[0];
        $.ajax({
            url: 'selectstate',
            data: {country: countrycode},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                $('#state').html('');
                $('#state').html('<option value="">--Select State--</option>');
                $.each(output, function (i, value) {
                    $('#state').append($('<option>').text(value.ascii_name).attr('value', value.admin_code));
                });
            }
        });
    });
    // to select country in tradeshow promotional tools //
    $('#org_country').change(function () {
        var country = $('#org_country').val();
        var countrycode = country.split(",");
        var countryid = countrycode[0];
        $.ajax({
            url: 'selectstate',
            data: {country: countrycode},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                $('#org_state').html('');
                $.each(output, function (i, value) {
                    $('#org_state').append($('<option>').text(value.ascii_name).attr('value', value.admin_code));
                });
            }
        });
    });

//            $('#main_category').change(function () {
//                var cat = $('#main_category').val();
//                console.log(cat);
//                $.ajax({
//                    url: 'tradesubcat',
//                    data: {catid: cat},
//                    dataType: 'html',
//                    type: 'post',
//                    success: function (output) {
//
//                        $('#subb_category').html(output);
//
////$('#sub_category').multiselect();
//
//                        $('#sub_category').multiselect({
////    selectAllValue: 'multiselect-all',
////    enableCaseInsensitiveFiltering: true,
////    enableFiltering: true,
//                            maxHeight: '300',
//                            buttonWidth: '235',
//                            onChange: function (element, checked) {
//                                var brands = $('#sub_category option:selected');
//                                var selected = [];
//                                $(brands).each(function (index, brand) {
//                                    selected.push([$(this).val()]);
//                                });
//                                $('#subcatid').attr('value', selected);
//                                //console.log(selected);
//                            }
//                        });
//                    }
//                });
//
//            });
    if (typeof js_selected_categories !== 'undefined') {
        var catids = js_selected_categories;
//                var dataarray = catids.split(",");
        // $('#sub_category').multiselect('select', dataarray);
        $('#trade_subcategory').select2();
    }
});
/// function used in refer to friend of tradeshow detail page
function removealert() {
    $('.alert').remove();
}
//// date script 
$("#from_date").on("changeDate", function (event) {
    $("#hidden_from_date")
            .val(
                    $("#from_date")
                    .datepicker('getFormattedDate')
                    );
});
$("#onlinefrom_date").on("changeDate", function (event) {
    $("#hiddenonlinefrom_date")
            .val(
                    $("#onlinefrom_date")
                    .datepicker('getFormattedDate')
                    );
});
/// select subcategory of tradeshow ///
function getTradesubcategory(cats) {
    if (cats !== '') {
        var bscurl = $('#bscurl').val();
        var catdet = cats.split(',');
        var catid = catdet[0];
        $.ajax({
            url: bscurl + 'getTradeSubCategory',
            data: {catid: catid},
            dataType: 'json',
            type: 'POST',
            success: function (data) {
//               var output = '<option value="">--Select Subcategory--</option>';
                var output;
                $.each(data, function (index, data) {
                    var id = data.id;
                    var name = data.name;
                    // var slug = data.slug;
                    //  var allval = id + "|*" + name + "|*" + slug;
                    output += "<option value='" + id + "'>" + name + "</option>";
                });
                $('#trade_subcategory').attr('multiple', 'multiple');
                $('#trade_subcategory').html(output);
                $('#trade_subcategory').select2();
            }
        });
    } else {
        $("#trade_subcategory").select2('destroy');
        $('#trade_subcategory').removeAttr('multiple');
        $("#trade_subcategory").html('<option value="">-- Select --</option>');
    }
}
// adbanner for GD-Hotels in tradeshow //
function searchHotel() {
    var con = $('#txtcountryhotel').val();
    var city = $('#cityhotel').val();
    var domain = $('#domainname').val();
    if (con == '' && city == '')
        alert('Select Country & City');
    else if (city == '')
        alert('Select City');
    else
        window.open(domain + '/hotel-details/hotels_list.php?country_code=' + con + '&city_name=' + city, '_blank')
    // window.location.href = domain + '/hotel-details/hotels_list.php?country_code=' + con + '&city_name=' + city;
}
// search option in banner of Tradeshow by Industry page ///
function searchTradeshow(value, type) {
    var term = '';
    if ($("#search_by_country").val() !== '') {
        term = term + '&coun=' + $("#search_by_country").val();
    }
    if ($("#search_by_category").val() !== '') {
        term = term + '&cate=' + $("#search_by_category").val();
    }
    if ($("#search_by_month").val() !== '') {
        term = term + '&month=' + $("#search_by_month").val().toLowerCase();
    }
    window.location.href = 'tradeshow-search.php?trade=trade' + term;
}
function isSet(name) { // Like isset function in PHP
    var ret = false;
    if (typeof name != "undefined")
        ret = true;
    return ret;
}
/// tradeshow filter used in tradeshow ///
function refineSearchTrade(val, type) {
    var t = [];
    var c = [];
    var m = [];
    var n = $('input:checkbox[name="country[]"]');
    t = n.filter(":checked").map(function () {
        return this.value
    }).get();
    var cat = $('input:checkbox[name="category[]"]');
    c = cat.filter(":checked").map(function () {
        return this.value
    }).get();
    var month = $('input:checkbox[name="month[]"]');
    m = month.filter(":checked").map(function () {
        return this.value
    }).get();
    var queries = {};
    $.each(document.location.search.substr(1).split('&'), function (c, q) {
        var i = q.split('=');
        queries[i[0].toString()] = i[1].toString();
    });
    if (type == 'country') {
        if (isSet(queries['country']) && queries['country'].indexOf(val) != -1) {
            var tstr = t.toString();
            t = removeFilterValue(tstr, val, ',');
        }
        querySt = getSearchUrlQueries(queries, type, t);
    }
    if (type == 'category') {
        if (isSet(queries['category']) && queries['category'].indexOf(val) != -1) {
            var cstr = c.toString();
            c = removeFilterValue(cstr, val, ',');
        }
        querySt = getSearchUrlQueries(queries, type, c);
    }
    if (type == 'month') {
        if (isSet(queries['month']) && queries['month'].indexOf(val) != -1) {
            var mstr = m.toString();
            m = removeFilterValue(mstr, val, ',');
        }
        querySt = getSearchUrlQueries(queries, type, m);
    }
    window.location.href = URL_TRADESHOW_PATH + '/search?' + querySt;
}
function getSearchUrlQueries(queries, name, setvalue) {
    var qarray = {};
    var querySt = '';
    var querySt = qarray['q'] = qarray['category'] = qarray['country'] = qarray['month'] = '';
    if (isSet(queries['q']) && queries['q'] != '') {
        qarray['q'] = 'q=' + queries['q'];
    }
    if (isSet(queries['category']) && queries['category'] != '') {
        qarray['category'] = 'category=' + queries['category'];
    }
    if (isSet(queries['month']) && queries['month'] != '') {
        qarray['month'] = 'month=' + queries['month'];
    }
    if (isSet(queries['country']) && queries['country'] != '') {
        qarray['country'] = 'country=' + queries['country'];
    }
    if (qarray['q'] != '' && name != 'q')
        querySt += (querySt != '' ? '&' : '') + qarray['q']
    if (qarray['month'] != '' && name != 'month')
        querySt += (querySt != '' ? '&' : '') + qarray['month']
    if (qarray['category'] != '' && name != 'category')
        querySt += (querySt != '' ? '&' : '') + qarray['category']
    if (qarray['country'] != '' && name != 'country')
        querySt += (querySt != '' ? '&' : '') + qarray['country']
    if (setvalue != '')
        querySt += '&' + name + '=' + setvalue;
    return querySt;
}
function getFilterUrlQueries(queries, name, setvalue) {
    var qarray = {};
    var querySt = '';
    var querySt = qarray['trade'] = qarray['cate'] = qarray['coun'] = qarray['month'] = '';
    if (isSet(queries['trade']) && queries['trade'] != '') {
        qarray['trade'] = 'trade=' + queries['trade'];
    }
    if (isSet(queries['cate']) && queries['cate'] != '') {
        qarray['cate'] = 'cate=' + queries['cate'];
    }
    if (isSet(queries['month']) && queries['month'] != '') {
        qarray['month'] = 'month=' + queries['month'];
    }
    if (isSet(queries['coun']) && queries['coun'] != '') {
        qarray['coun'] = 'coun=' + queries['coun'];
    }
    if (qarray['trade'] != '' && name != 'trade')
        querySt += (querySt != '' ? '&' : '') + qarray['trade']
    if (qarray['month'] != '' && name != 'month')
        querySt += (querySt != '' ? '&' : '') + qarray['month']
    if (qarray['cate'] != '' && name != 'cate')
        querySt += (querySt != '' ? '&' : '') + qarray['cate']
    if (qarray['coun'] != '' && name != 'coun')
        querySt += (querySt != '' ? '&' : '') + qarray['coun']
    if (setvalue != '')
        querySt += '&' + name + '=' + setvalue;
    return querySt;
}
function removeFilterValue(list, value, separator) {
    separator = separator || ",";
    var values = list.split(separator);
    for (var i = 0; i < values.length; i++) {
        if (values[i] == value) {
            values.splice(i, 1);
            return values.join(separator);
        }
    }
    return list;
}
//tradeshow filter - viewall_tradeshow.php//
function refineTrade(val, type) {
    $('.nomore').hide();
    $('#view_count').remove();
    $(document).scrollTop(0);
    $(window).scrollTop(0);
    var clkval = val;
//    var t = [];
//    var c = [];
//    var m = [];
//    var n = $('input:checkbox[name="country[]"]');
//    t = n.filter(":checked").map(function () {
//        return this.value
//    }).get();
//    var cat = $('input:checkbox[name="category[]"]');
//    c = cat.filter(":checked").map(function () {
//        return this.value
//    }).get();
//    var month = $('input:checkbox[name="month[]"]');
//
//    m = month.filter(":checked").map(function () {
//        return this.value
//    }).get();
//    console.log(t);
    var queries = {};
    var mt = mc = mm = '';
    $('input:checkbox[name=country]:checked').each(function ()
    {
        if (this.checked) {
            if (mt != '')
                mt = mt + ',' + $(this).val();
            else
                mt = $(this).val();
        }
    });
    $('input:checkbox[name=category]:checked').each(function ()
    {
        if (this.checked) {
            if (mc != '')
                mc = mc + ',' + $(this).val();
            else
                mc = $(this).val();
        }
    });
    $('input:checkbox[name=month]:checked').each(function ()
    {
        if (this.checked) {
            if (mm != '')
                mm = mm + ',' + $(this).val();
            else
                mm = $(this).val();
        }
    });
    console.log('dsfdsf' + mt);
    $.each(document.location.search.substr(1).split('&'), function (c, q) {
        var i = q.split('=');
        queries[i[0].toString()] = i[1].toString();
    });
    mt = mt.split(',').filter(function (allItems, i, a) {
        return i == a.indexOf(allItems);
    }).join(',');
    mc = mc.split(',').filter(function (allItems, i, a) {
        return i == a.indexOf(allItems);
    }).join(',');
    mm = mm.split(',').filter(function (allItems, i, a) {
        return i == a.indexOf(allItems);
    }).join(',');
//    if (isSet(queries['coun']) && queries['coun'].indexOf(clkval) != -1)
//    {
//        t = removeFilterValue(t, clkval, ',');
//    }
    if (type == 'coun') {
        if (isSet(queries['coun']) && queries['coun'].indexOf(clkval) != -1)
            mt = removeFilterValue(mt, clkval, ',');
        querySt = getFilterUrlQueries(queries, type, mt);
    }
    if (type == 'cate') {
        if (isSet(queries['cate']) && queries['cate'].indexOf(clkval) != -1)
            mc = removeFilterValue(mc, clkval, ',');
        querySt = getFilterUrlQueries(queries, type, mc);
    }
    if (type == 'month') {
        if (isSet(queries['month']) && queries['month'].indexOf(clkval) != -1)
            mt = removeFilterValue(mt, clkval, ',');
        querySt = getFilterUrlQueries(queries, type, mm);
    }

    window.location.href = URL_TRADESHOW_PATH + '/tradeshow-search.php?' + querySt;
//    $.ajax({
//        url: 'getrefineresult',
//        data: {
//            view_country: t,
//            view_category: c,
//            view_month: m,
//            coun: coun,
//            cate: cate,
//            mont: mont
//        },
//        type: 'post',
//        success: function (output) {
//            $('#view_results').html(output);
//            $(document).resize();
//            $(window).resize();
//
//
//        }
//    });
}
// Business classifieds //
/// for map functions- to calculate latitude & longitude
$(document).ready(function () {
    if ($('#map').length) {
        var country = $('#countryname').val();
        // console.log(country);
        var state = $('#state_name').val();
        var city = $('#cityname').val();
        var latitude = $('#latitude').val();
        var longitude = $('#longitude').val();
        if (state != '') {
            myCenter = latitude + ', ' + longitude + state + ', ' + country;
        } else {
            myCenter = latitude + ', ' + longitude + ' , ' + country;
        }
        var lat = latitude;
        var lang = longitude;
        var geocoder;
        var map;
        if (city != '')
            var address = city + ',' + state + ',' + country;
        else
            var address = state + ',' + country;
        geocoder = new google.maps.Geocoder();
        if (lat != 0) {
            var latlng = new google.maps.LatLng(-34.397, 150.644);
            var myOptions = {
                zoom: 14, // set the zoom level manually
                zoomControl: true,
                scaleControl: false,
                scrollwheel: false,
                draggable: true,
                disableClickZoom: true,
                center: latlng,
                mapTypeControl: false,
                mapTypeControlOptions: {
                    style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
                },
                navigationControl: false,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById("map"), myOptions);
            var latlng = new google.maps.LatLng(lat, lang, address);
            map.setCenter(latlng);
            var infowindow = new google.maps.InfoWindow(
                    {
                        content: '<b>' + address + '</b>',
                        size: new google.maps.Size(150, 50)
                    });
            var marker = new google.maps.Marker({
                position: latlng,
                map: map,
                title: address
            });
            google.maps.event.addListener(marker, 'click', function () {
                infowindow.open(map, marker);
            });
        } else {
            //  console.log('else');
            var myOptions = {
                zoom: 14, // set the zoom level manually
                zoomControl: true,
                scaleControl: false,
                scrollwheel: false,
                draggable: true,
                disableClickZoom: true,
                center: latlng,
                mapTypeControl: false,
                mapTypeControlOptions: {
                    style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
                },
                navigationControl: false,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById("map"), myOptions);
            if (geocoder) {
                geocoder.geocode({
                    'address': address
                }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {

                        if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
                            map.setCenter(results[0].geometry.location);
                            var infowindow = new google.maps.InfoWindow(
                                    {
                                        content: '<b>' + address + '</b>',
                                        size: new google.maps.Size(150, 50)
                                    });
                            var marker = new google.maps.Marker({
                                position: results[0].geometry.location,
                                map: map,
                                title: address
                            });
                            google.maps.event.addListener(marker, 'click', function () {
                                infowindow.open(map, marker);
                            });
                            google.maps.event.addListener(map, 'click', function (event) {

                                document.getElementById('Lattitude').value = event.latLng.lat()
                                document.getElementById('Longitude').value = event.latLng.lng()
                            })
                        } else {
                            // alert("No results found");
                        }
                    } else {
                        // alert("Geocode was not successful for the following reason: " + status);
                    }
                });
            }
        }
    }
});
/// category search used in business classifieds //
function filtertradeshow_catlist(element, serachid) {
    var value = $(element).val();
    var length = $(element).val().length;
    if (length > 0) {
        $("." + serachid + " li").each(function () {
            if ($(this).text().search(new RegExp(value, "i")) > -1) {
                $(this).show();
                $('#noresult_cat,.noresult_cat').hide('fast');
                $('.more-btn').hide();
                $('.hidedisplay').show();
            } else {
                $(this).hide();
                $('#noresult_cat,.noresult_cat').show();
                $('.more-btn').hide();
            }
        });
    } else {
        $("." + serachid + " li").show();
        $('.hidedisplay').hide();
        $('.more-btn').show();
        $('.hideshowdiv').show();
    }
}

$('.trade_submitting').on('click', function (e) {
    $('#tradeshoWForm').parsley().validate("first");
    if ($('#tradeshoWForm').parsley().isValid()) {
        var phone, phone_txt, temp_phone, email, website, website_txt;
        email = /\b(\w)+\@(\w)+\.(\w)+\b/g;
        temp_phone = /\d{10}/;
        phone = /[\s]?[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}?[ .\s]?$/;
        phone_txt = /[\s]?[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}?[ .\s]+\b/g;
        website = /[\s]?(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
        website_txt = /[\s]?(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?[\s]+\b/g;
        var val_text = $('#txtmsg').val();
        var desc = val_text.replace(/[\|\^\=\<\>\{\}\[\]\#]/g, '');
        $('#txtmsg').val(desc);
        if (email.test(val_text) || temp_phone.test(val_text) || phone_txt.test(val_text) || phone.test(val_text) || website.test(val_text) || website_txt.test(val_text)) {
            alert("As per our security policy, we don't allow any contact information to share through enquiry.");
            e.preventDefault();
        }
    }
});
/// promotional tools -tradeshows subcategory //
$(function () {
    $('#trade_subcategory').on('select2:selecting', function (e) {
        $('#addtradeshow_form').parsley().destroy();
        $('#trade_subcategory').attr('data-parsley-required', 'false');
        $('#addtradeshow_form').parsley();
    });
});


/*
Project Title   :   Bizbilla
Version         :   3.0
Title           :   Question
Description     :   Answer page, new/existing user form validation in all module
Included        :   -
Last Modified   :   Aug 15,2017 / Sivagami
Assigned to     :   Aravind
*/
//----------------------Answer page-------------------------------
$(document).ready(function () {
//    ****ask question form****
    $('#usertypenew').hide();
//    *****for new user***
    $('#new_user').click(function () {

        $('#usertypenew').show();
        $('#usertypeold').hide();
    });
//****for old user***
    $('#already_user').click(function () {
        $('#usertypenew').hide();
        $('#usertypeold').show();
    });
//***for clear form****
    $('#form_clear').click(function () {
        $('#usertypenew').hide();
        $('#usertypeold').show();
    });
//****user required field validation in all form********
    var newuser = $('#usertypenew');
    newuser.find('input').prop('required', false);
    $("input[name=usertype]").on('click', function () {
        var newuser = $('#usertypenew');
        var olduser = $('#usertypeold');

        if ($(this).val() == 'new') {
//            console.log('new');
            newuser.show();
            newuser.find('input').prop('required', true);
            olduser.hide();
            olduser.find('input').prop('required', false);
            $("#post_country1").removeAttr('required');
            $("#post_country").attr('required', 'required');
        } else {
//            console.log('old');
            newuser.hide();
            newuser.find('input').prop('required', false);
            $("#post_country").removeAttr('required');
            $("#post_country1").attr('required', 'required');
            olduser.show();
            olduser.find('input').prop('required', true);
        }
    });

});

//*********report suspicious activity form validation*******

$(document).ready(function () {

    $('#product_new_member').hide();
    $('#product_new_user').click(function () {

        $('#product_new_member').show();
        $('#product_old_member').hide();
    });
//
    $('#product_already_user').click(function () {
        $('#product_new_member').hide();
        $('#product_old_member').show();
    });


    var newuser = $('#product_new_member');
    newuser.find('input').prop('required', false);

    $("input[name=usertype]").on('click', function () {
        var newuser = $('#product_new_member');
        var olduser = $('#product_old_member');
        if ($(this).val() == 'new') {
//            console.log('new');
            newuser.show();
            newuser.find('input').prop('required', true);
            olduser.hide();
            olduser.find('input').prop('required', false);
            $("#post_country1").removeAttr('required');
            $("#post_country").attr('required', 'required');
        } else {
//            console.log('old');
            newuser.hide();
            newuser.find('input').prop('required', false);
            $("#post_country").removeAttr('required');
            $("#post_country1").attr('required', 'required');
            olduser.show();
            olduser.find('input').prop('required', true);
        }
    });
    $('#deliverynew').hide();
    $('#delivery_new_user').click(function () {

        $('#deliverynew').show();
        $('#deliveryold').hide();
    });
//
    $('#delivery_old_user').click(function () {
        $('#deliverynew').hide();
        $('#deliveryold').show();
    });
    var newuser = $('#deliverynew');
    newuser.find('input').prop('required', false);
    $("input[name=usertype]").on('click', function () {
        var newuser = $('#deliverynew');
        var olduser = $('#deliveryold');
        if ($(this).val() == 'new') {
//            console.log('new');
            newuser.show();
            newuser.find('input').prop('required', true);
            olduser.hide();
            olduser.find('input').prop('required', false);
            $("#post_country1").removeAttr('required');
            $("#post_country").attr('required', 'required');
        } else {
//            console.log('old');
            newuser.hide();
            newuser.find('input').prop('required', false);
            $("#post_country").removeAttr('required');
            $("#post_country1").attr('required', 'required');
            olduser.show();
            olduser.find('input').prop('required', true);
        }
    });

});
//*******close form in ask question*****
$(".quefrm_close").click(function () {
    $('#question_form').trigger("reset");
    $('#question_form').parsley().reset();

    $('#usertypenew').hide();
    $('#usertypeold').show();
});
//********add image in ask question form*******
function ques_readURL(input, div) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        var extension = input.files[0].name.split('.').pop().toLowerCase();
        reader.onload = function (e) {
            if (extension == 'jpg' || extension == 'jpeg' || extension == 'png') {
                $('#' + div)
                        .attr('src', e.target.result)
                        .width(110)
                        .height(110);
            } else {
                var filenoimage = URL_CDN_PATH + '/assets/img/noimage.png';
                $('#' + div)
                        .attr('src', filenoimage)
                        .width(110)
                        .height(110);
            }
        };

        reader.readAsDataURL(input.files[0]);
    }
}
//auto hide of alert messages within 3 sec in inquiry
$(function () {
    setTimeout(function () {
        $('#inq_mode_mesg .alert').fadeOut('slow');
    }, 3000);
});
/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :   service profile
 Description     :   Profile dashboard scripts
 Included        :   -
 Last Modified   :   Aug 18,2017 / Sivagami
 Assigned to     :   Kalaivanan,manobalan
 */
//*** select option in profile forms****
$("#seacrchcities,#serviceon,#indiv_bus_type,.stand_sertify_name,.qa_sertify_name,#sales_currency,#purchase_currency,#profilestate,#profile_city,#seacrchcity,#seacrchcity2,#business_type,#services_type,#mem_state,#registered_state,#mem_country").select2({});
$(function () {
//    ***product specification form validation*******

    $('.addproducttagspecfic').select2({
        tags: true,
        selectOnBlur: true,
//        selectOnClose: true,
        placeholder: 'e.g red',
        tokenSeparators: [',', ';', '\t', '\n'],
        language: {
            noResults: ''
        },
        maximumSelectionLength: 10
    }).on('select2:open', function (e) {
        selectOnTab(e);
    });
    $(".my_requirement").select2({
        tags: true,
        placeholder: 'Enter your requirements',
        tokenSeparators: [",", "\t"],
        language: {
            noResults: ''
        },
        maximumSelectionLength: 20
    }).on('select2:open', function (e) {
        selectOnTab(e);
    });
    $(".shipping_terms").select2({
        tags: true,
        placeholder: 'Select shipping terms',
        tokenSeparators: [",", "\t"],
        language: {
            noResults: ''
        },
        maximumSelectionLength: 4
    }).on('select2:open', function (e) {
        selectOnTab(e);
    });
    function selectOnTab(event) {

        var $selected_id_field = $(event.target);
        $(".select2-search__field").on('keydown', function (e) {
            if (e.which === 9) {
                var highlighted = $('.select2-results__option--highlighted');
                if (highlighted) {
                    var data = highlighted.data('data');
                    var vals = $selected_id_field.val();
                    if (vals === null) {
                        vals = [];
                    }
                    vals.push(data.id);
                    $selected_id_field.val(vals).trigger("change");
                }
            }
        });
    }

//    $('.my_requirement').select2({
//        tags: true,
//        placeholder: 'Enter your requirements',
//        tokenSeparators: [",", "\t"],
//        language: {
//            noResults: ''
//        },
//        maximumSelectionLength: 5
//    });
    $('#country_name').select2({
        placeholder: 'Choose country',
        maximumSelectionLength: 6
    });
    $('#cat_name').select2({
        placeholder: 'Choose category',
        maximumSelectionLength: 6
    });
//    ******mobile size category view in service and service provider*****
    $(".service-maincat-title h2").click(function () {
        $(".service-main-cat-blk").toggleClass('letter-accordion', 1000);
        $(".serv-accord").toggleClass('letter-accord-down', 1000);
    });
});
//*******verified membership form******
$('#registered_state').select2({
    placeholder: 'Choose state'
});
$('#bus_type').select2({
    minimumResultsForSearch: 0,
    placeholder: 'Choose your business types',
    maximumSelectionLength: 4

});
$('#serv_type').select2({
    minimumResultsForSearch: 0,
    placeholder: 'Choose your service types',
    maximumSelectionLength: 4

});
$('#indiv_bus_type').select2({
    placeholder: 'Choose your business types'
//    maximumSelectionLength: 4
});
//$('#mem_city').select2({
//    placeholder: 'Choose your business types',
//    maximumSelectionLength: 4
//});
//$('#mem_country').select2({
//    placeholder: 'Select member country'
//})
function matchStart(params, data) {
    params.term = params.term || '';
    if (data.text.toUpperCase().indexOf(params.term.toUpperCase()) == 0) {
        return data;
    }
    return false;
}

$("#mem_country").select2({
    placeholder: 'Choose country',
    matcher: function (params, data) {
        return matchStart(params, data);
    }
});
//$('#profile_city').select2({
//    placeholder: 'Choose your city'
//});
//***date picker****
$('#remitance_date,#bank_date,#postal_date,#dd_date').datepicker({
//    startDate: 'now',
    endDate: 'now',
    autoclose: true

});
$(".nav-tabs a").click(function () {
    $(this).tab('show');
});
$('#myTabs a').click(function (e) {
    e.preventDefault();
    $(this).tab('show');
});
function selectAll(source) {
    checkboxes = document.getElementsByName('selectall[]');
    for (var i in checkboxes)
        checkboxes[i].checked = source.checked;
}
$('#bizbut').click(function () {
    $('#bizbillamemdiv').slideDown().show();
});
//******B2B,B2C member type in profile index(hidded)****
function membershipstatus(rid) {
    if (rid == 'b2bmember' || rid == 'b2cmember') {
        $('#member_type').removeAttr('required');
        $('#bizbillamemdiv').hide();
    } else {
        $('#member_type').attr('required', 'required');
        $('#bizbillamemdiv').show();
    }
}

function formatRepo(repo) {
    if (repo.loading)
        return repo.text;
    var markup = repo.city_name;
//    if (repo.description) {
//        markup += '<div>' + repo.description + '</div>';
//    }
//    markup += '</div></div>';
    return markup;
}

function formatRepoSelection(repo) {
    return repo.city_name;
}

var countryid = $('#memcountry_id').val();
//$('#mem_city').select2({
//    ajax: {
//        url: URL_MAIN_PATH + '/search/api/city/state-search?country_id=in',
//        dataType: 'json',
//        delay: 250,
//        data: function (params) {
//            return {
//                city: params.term, // search term
//                page: params.page
//            };
//        },
//        processResults: function (data, params) {
//            var array = $.map(data, function (value, index) {
//                return value;
//            });
//            console.log(array);
//            params.page = params.page || 1;
//            return {
//                results: array,
//                pagination: {
//                    more: (params.page * 30) < data.total
//                }
//            };
//
//        },
//        cache: true
//    },
//    escapeMarkup: function (markup) {
//        return markup;
//    },
//    minimumInputLength: 1,
//    templateResult: formatRepo,
//    templateSelection: formatRepoSelection
//});


//$(document).ready(function () {
////    console.log(SERVICECITY);
////    console.log(SERVICECITIES);
//    var servicecity = SERVICECITY;
//
//    var servicecountry = SERVICECITIES;
//    // console.log(servicecountry);
//    if (servicecity == '1') {
//
//        $("#seacrchcity").select2({
//            ajax: {
//                url: URL_MAIN_PATH + '/search/api/city/state-search?country_id=' + servicecountry,
//                dataType: 'json',
//                delay: 250,
//                data: function (params) {
//                    return {
//                        city: params.term, // search term
//                        page: params.page
//                    };
//                },
//                processResults: function (data, params) {
//                    var array = $.map(data, function (value, index) {
//                        return value;
//                    });
////                console.log(data);
//                    params.page = params.page || 1;
//                    return {
//                        results: array,
//                        pagination: {
//                            more: (params.page * 30) < data.total
//                        }
//                    };
//                },
//                cache: true
//            },
//            escapeMarkup: function (markup) {
//                return markup;
//            },
//            minimumInputLength: 1,
//            templateResult: formatRepo,
//            templateSelection: formatRepoSelection
//
//        });
//    }
//});

//*****select country in services offered*****

function selectcountry(scountry) {
    $('#country_id').val('');
    $('#country_id').val(scountry);
    $reset = $("#seacrchcity").select2();
    $reset.val(null).trigger("change");
    var country_id = scountry;
    $("#seacrchcity").select2({
        ajax: {
            url: URL_MAIN_PATH + '/search/api/city/state-search?country_id=' + country_id,
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    city: params.term, // search term
                    page: params.page
                };
            },
            processResults: function (data, params) {
                var array = $.map(data, function (value, index) {
                    return value;
                });
                params.page = params.page || 1;
                return {
                    results: array,
                    pagination: {
                        more: (params.page * 30) < data.total
                    }
                };
            },
            cache: true
        },
        escapeMarkup: function (markup) {
            return markup;
        },
        minimumInputLength: 1,
        selectOnClose: true,
        templateResult: formatRepo,
        templateSelection: formatRepoSelection

    });
}

var country_id = $('#memcountry_id').val();
if (country_id != '') {
    selectcity(country_id);
}
//****select city in basic profile form*****
function selectcity(scountry) {
    var country_id = scountry;
    $('#membasic_country').val(country_id);
    var country_id = $('#membasic_country').val();
    $("#mem_city").select2({
        ajax: {
            url: URL_MAIN_PATH + '/search/api/country/search?country_code=' + country_id,
            dataType: 'json',
            quietMillis: 500,
            data: function (params) {
                return {
                    city: params.term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        },
        placeholder: 'Eg: City, State',
        selectOnClose: true,
        minimumInputLength: 3
    });
}
var memberselectcity = MEMSELECTCITY;
if (memberselectcity == 1) {
    $(function () {

        var country_id = $('#membasic_country').val();
        $("#mem_city").select2({
            ajax: {
                url: URL_MAIN_PATH + '/search/api/country/search?country_code=' + country_id,
                dataType: 'json',
                quietMillis: 500,
                data: function (params) {
                    return {
                        city: params.term
                    };
                },
                processResults: function (data) {
                    return {
                        results: data
                    };
                },
                cache: true
            },
            placeholder: 'Eg: City, State',
            selectOnClose: true,
            minimumInputLength: 3
        });
    });
}
function deleteall(statusdelet) {
    var confirmuser = confirm('Are you sure do you want to delete this service?');
    if (confirmuser == false) {

    } else {
        var blkstr = [];
        var blkstr1 = [];
        var cbs1 = document.getElementsByName('selectall[]');
        for (var i = 0; i < cbs1.length; i++)
        {
            if (cbs1[i].checked == true)
            {
                var cb = cbs1[i].value;
                blkstr1.push(cb);
            }
        }
        var selected_vals = blkstr1.join(",");
        $('#deleteid').val(selected_vals);
        var deleteid = $('#deleteid').val();
        if (deleteid == '') {
            alert("Choose any one service to delete");
        } else {
            $.ajax({
                url: '/profile/deleteser',
                type: 'post',
                dataType: 'text',
                data: {deleteid: deleteid, actiondelete: 'user', statusdelet: statusdelet},
                success: function (output) {
                    var text = output;
                    var obj = JSON.parse(text);
                    if (obj.message) {
                        $('#success_div').html(obj.message).show();
                    } else {
                        $('#success_div').html('').hide();
                    }
                }

            });
        }
    }
}
function initialize()
{
    var lat = $('#lattitude').val();
    var statename = $('#state-select option:selected').text();
    var address = '<?php echo $cityname; ?>,' + statename + ',<?php echo $countryname; ?>';
    var lang = $('#longtitude').val();
    if (lat != '0' && lang != '0') {


        var geocoder;
        var map;
        geocoder = new google.maps.Geocoder();
        var latlng = new google.maps.LatLng(-34.397, 150.644);
        var myOptions = {
            zoom: 14, // set the zoom level manually
            zoomControl: true,
            scaleControl: false,
            scrollwheel: true,
            disableClickZoom: true,
            center: latlng,
            mapTypeControl: true,
            mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
            navigationControl: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById("mapdiv"), myOptions);
        var latlng = new google.maps.LatLng(lat, lang);
        map.setCenter(latlng);
        var infowindow = new google.maps.InfoWindow(
                {content: '<b>' + address + '</b>',
                    size: new google.maps.Size(150, 50)
                });
        var marker = new google.maps.Marker({
            position: latlng,
            map: map,
            title: address
        });
        google.maps.event.addListener(marker, 'click', function () {
            infowindow.open(map, marker);
        });
        google.maps.event.addListener(map, 'click', function (event) {

            document.getElementById('Lattitude1').value = event.latLng.lat()
            document.getElementById('Longitude1').value = event.latLng.lng()
        });
    } else {


        var geocoder;
        var map;
        geocoder = new google.maps.Geocoder();
        var latlng = new google.maps.LatLng(-34.397, 150.644);
        var myOptions = {
            zoom: 14, // set the zoom level manually
            zoomControl: true,
            scaleControl: false,
            scrollwheel: true,
            disableClickZoom: true,
            center: latlng,
            mapTypeControl: true,
            mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
            navigationControl: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById("mapdiv"), myOptions);
        if (geocoder) {
            geocoder.geocode({'address': address}, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
                        map.setCenter(results[0].geometry.location);
                        var infowindow = new google.maps.InfoWindow(
                                {content: '<b>' + address + '</b>',
                                    size: new google.maps.Size(150, 50)
                                });
                        var marker = new google.maps.Marker({
                            position: results[0].geometry.location,
                            map: map,
                            title: address
                        });
                        google.maps.event.addListener(marker, 'click', function () {
                            infowindow.open(map, marker);
                        });
                        google.maps.event.addListener(map, 'click', function (event) {

                            document.getElementById('Lattitude1').value = event.latLng.lat()
                            document.getElementById('Longitude1').value = event.latLng.lng()
                        });
                    } else {
                        alert("No results found");
                    }
                } else {
//alert("Geocode was not successful for the following reason: " + status);
                }
            });
        }
    }
//                {
//                    var geocoder;
//                    var map;
//
//                    geocoder = new google.maps.Geocoder();
//                    var latlng = new google.maps.LatLng(-34.397, 150.644);
//                    var myOptions = {
//                        zoom: 14, // set the zoom level manually
//                        zoomControl: true,
//                        scaleControl: false,
//                        scrollwheel: true,
//                        disableClickZoom: true,
//                        center: latlng,
//                        mapTypeControl: true,
//                        mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
//                        navigationControl: true,
//                        mapTypeId: google.maps.MapTypeId.ROADMAP
//                    };
//                    map = new google.maps.Map(document.getElementById("mapdiv"), myOptions);
////alert(address);
//                    if (geocoder) {
//
//                        geocoder.geocode({'address': address}, function(results, status) {
//
//                            if (status == google.maps.GeocoderStatus.OK) {
//                                if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
//                                    var latlng = new google.maps.LatLng(lat, lang);
//                                    var marker = new google.maps.Marker({
//                                        position: results[0].geometry.location,
//                                        map: map,
//                                        title: address
//                                    });
//                                    google.maps.event.addListener(marker, 'click', function() {
//                                        infowindow.open(map, marker);
//                                    });
//                                    map.setCenter(results[0].geometry.location);
//                                    var currentCenter = results[0].geometry.location;
//                                    map.setCenter(currentCenter);
//                                    google.maps.event.addListener(map, 'click', function(event) {
//                                        document.getElementById('Lattitude1').value = event.latLng.lat()
//                                        document.getElementById('Longitude1').value = event.latLng.lng()
//                                    });
//                                } else {
//                                    alert("No results found");
//                                }
//                            } else {
//                                alert("Geocode was not successful for the following reason: " + status);
//                            }
//                        });
//                    }
//
//                }
}

//*****image upload in profile****
$('#image_file').click(function () {
    $('#crop_img').removeAttr('class', 'hide');
});
$(document).ready(function () {
    $('#button_upload').click(function () {
        var img_value = $('#image_file').val();
        if (img_value == "") {
            alert("Please choose an image");
            return false;
        }
    });
});
function changeFile() {
    $(".def_image").hide();
    $('#image_file').click();
}
$('#defimage').click(function () {
    $(".error1").hide();
    $('#crop_img').hide();
    $("#image_div").hide();
    $(".def_image").show();
    $(".def_image").html('<img src="' + URL_CDN_PATH + '/assets/img/noimage.png"/>');
    $("#def_submit").click();
});
function validate1() {
    var filename = document.getElementById('image_file').value;
    var extension = filename.substr(filename.lastIndexOf('.') + 1).toLowerCase();
    if (extension == 'jpeg' || extension == 'jpg' || extension == 'JPG' || extension == 'JPEG' || extension == 'png' || extension == 'PNG') {
        return true;
    } else {
        alert('Invalid File Format! Please upload only .jpeg, .jpg,.png');
        document.getElementById('image_file').value = "";
    }
}
$('#image_fille').click(function () {
    $('#crop_img').show();
});
//*****profile left menu*****
function PopupCenter(pageURL, title, w, h) {
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2);
    var targetWin = window.open(pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
}
//Make global variables for selected image for further usage
var selectImgWidth, selectImgHeight, jcrop_api, boundx, boundy, isError = false;
$(document).ready(function () {
    $("#image_file").change(function () {
        var previewId = document.getElementById('load_img');
        var thumbId = document.getElementById('thumb');
        previewId.src = '';
        $('#image_div').hide();
        var flag = 0;
        // Get selected file parameters
        var selectedImg = $('#image_file')[0].files[0];
        //Check the select file is JPG,PNG,JOEG image
        var regex = /^(image\/jpeg|image\/png)$/i;
        if (!regex.test(selectedImg.type)) {
            $('.error1').html('Please select a valid image file (jpg,jpeg and png are allowed)').fadeIn(500);
            $("#image_file").val('');
            flag++;
            isError = true;
            //            $('#image_file').val('');
        }

// Check the size of selected image if it is greater than 250 kb or not
        else if (selectedImg.size > 1024 * 1024) {

            $('.error1').html('The file you selected is too big. Max file size is 1 MB').fadeIn(500);
            $("#image_file").val('');
            $('#crop_img').hide();
            flag++;
            isError = true;
        }

        if (flag == 0) {
            isError = false;
            $('.error1').hide(); //if file is correct then hide the error message


            // Preview the selected image with object of HTML5 FileReader class
            // Make the HTML5 FileReader Object
            var oReader = new FileReader();
            oReader.onload = function (e) {

                // e.target.result is the DataURL (temporary source of the image)
                thumbId.src = previewId.src = e.target.result;
                // FileReader onload event handler
                previewId.onload = function () {

                    // display the image with fading effect
                    $('#image_div').fadeIn(500);
                    selectImgWidth = previewId.naturalWidth; //set the global image width
                    selectImgHeight = previewId.naturalHeight; //set the global image height

                    // Create variables (in this scope) to hold the Jcrop API and image size

                    // destroy Jcrop if it is already existed
                    if (typeof jcrop_api != 'undefined')
                        jcrop_api.destroy();
                    // initialize Jcrop Plugin on the selected image
                    $('#load_img').Jcrop({
                        minSize: [32, 32], // min crop size
                        aspectRatio: 1, // keep aspect ratio 1:1
                        bgFade: true, // use fade effect
                        bgOpacity: .3, // fade opacity
                        onChange: showThumbnail,
                        onSelect: showThumbnail,
                        //                        onRelease: clearInfo,
                        setSelect: [0, 0, 150, 180],
                        boxWidth: 800,
                        boxHeight: 800,
                        allowMove: true,
                        allowResize: true,
                        allowSelect: true


                    }, function () {

                        // use the Jcrop API to get the real image size
                        var bounds = this.getBounds();
                        boundx = bounds[0];
                        boundy = bounds[1];
                        // Store the Jcrop API in the jcrop_api variable
                        jcrop_api = this;
                    });
                };
            };
            // read selected file as DataURL
            oReader.readAsDataURL(selectedImg);
        }
    });
    function showThumbnail(e)
    {
        var rx = 155 / e.w; //155 is the width of outer div of your profile pic
        var ry = 190 / e.h; //190 is the height of outer div of your profile pic
        $('#w').val(e.w);
        $('#h').val(e.h);
        $('#w1').val(e.w);
        $('#h1').val(e.h);
        $('#x1').val(e.x);
        $('#y1').val(e.y);
        $('#x2').val(e.x2);
        $('#y2').val(e.y2);
        $('#thumb').css({
            width: Math.round(rx * selectImgWidth) + 'px',
            height: Math.round(ry * selectImgHeight) + 'px',
            marginLeft: '-' + Math.round(rx * e.x) + 'px',
            marginTop: '-' + Math.round(ry * e.y) + 'px'
        });
    }
});
//function basicinfodetails() {
//    var company_name = $('#company_name').val();
//    var business_type = $('#businesstype').val();
//    if (company_name == '' && (business_type == 'null')) {
//        $('#parsley-id-cmpny').show();
//        $('#parsley-id-bstype').show();
//        return false;
//    } else if (company_name == '') {
//        $('#parsley-id-cmpny').show();
//        $('#parsley-id-bstype').hide();
//        return false;
//    } else if (business_type == '') {
//        $('#parsley-id-cmpny').hide();
//        $('#parsley-id-bstype').show();
//        return false;
//    } else {
//        if (business_type != 'null' && company_name != '') {
//            $.ajax({
//                url: URL_PROFILE_PATH + 'addbasicinfo',
//                data: {company_name: company_name, business_type: business_type, action: 'basic_info'},
//                dataType: 'json',
//                type: 'post',
//                success: function (output) {
//                    var successmessage = output.success;
//                    if (successmessage == 1) {
//                        if (company_name == '' || business_type == '') {
//                            $('.contacta').attr('href', 'javascript:void(0)');
//                        } else {
//                            document.getElementById("contacta").href = "#contact";
//                        }
//                        $('.basic_details').hide();
//                        $('.address_details').hide();
//                        $('.contact_details').show();
//                        $('#basic_success').show();
//                        window.location = '#contact';
//                    }
//                }
//            });
//        }
//    }
//}
//function contactinfodetails() {
//    var contact_name = $('#contact_name').val();
//    var mem_country = $('#mem_country').val();
//    var mobile_number = $('#mobile_number').val();
//    var mobile_code = $('#mobile_code').val();
//    if (contact_name == '' && mem_country == '' && mobile_number == '') {
//        $('#parsley-id-cntname').show();
//        $('#parsley-id-country').show();
//        $('#parsley-id-mble').show();
//        return false;
//    } else if (contact_name == '') {
//        $('#parsley-id-cntname').show();
//        $('#parsley-id-country').hide();
//        $('#parsley-id-mble').hide();
//        return false;
//    } else if (mem_country == '') {
//        $('#parsley-id-cntname').hide();
//        $('#parsley-id-country').show();
//        $('#parsley-id-mble').hide();
//        return false;
//    } else if (mobile_number == '') {
//        $('#parsley-id-cntname').hide();
//        $('#parsley-id-country').hide();
//        $('#parsley-id-mble').show();
//        return false;
//    } else {
//        if (contact_name != '' && mem_country != '' && mobile_number != '') {
//            $.ajax({
//                url: URL_PROFILE_PATH + 'addbasicinfo',
//                data: {contact_name: contact_name, mobile_code: mobile_code, mem_country: mem_country, mobile_number: mobile_number, action: 'contact_info'},
//                dataType: 'json',
//                type: 'post',
//                success: function (output) {
//                    var successmessage = output.success;
//                    if (successmessage == 1) {
//                        if (mobile_number == '' || contact_name == '' || mem_country == '') {
//                            $('.addressa').attr('href', 'javascript:void(0)');
//                        } else {
//                            document.getElementById("addressa").href = "#address";
//                        }
//                        $('.basic_details').hide();
//                        $('.address_details').show();
//                        $('.contact_details').hide();
//                        $('#contact_success').show();
//                        window.location = '#address';
//                    }
//                }
//            });
//        }
//    }
//}
//function addressinfodetails() {
//    var mem_address = $('#mem_address').val();
//    var mem_city = $('#mem_city').val();
//    var mem_pincode = $('#mem_pincode').val();
//
//    if (mem_address == '' && mem_city == '' && mem_pincode == '') {
//        $('#parsley-id-address').show();
//        $('#parsley-id-city').show();
//        $('#parsley-id-pincode').show();
//        return false;
//    } else if (mem_address == '') {
//        $('#parsley-id-address').show();
//        $('#parsley-id-city').hide();
//        $('#parsley-id-pincode').hide();
//        return false;
//    } else if (mem_city == '') {
//        $('#parsley-id-address').hide();
//        $('#parsley-id-city').show();
//        $('#parsley-id-pincode').hide();
//        return false;
//    } else if (mem_pincode == '') {
//        $('#parsley-id-address').hide();
//        $('#parsley-id-city').hide();
//        $('#parsley-id-pincode').show();
//        return false;
//    } else {
//        if (mem_address != '' && mem_city != '' && mem_pincode != '') {
//            $.ajax({
//                url: URL_PROFILE_PATH + 'addbasicinfo',
//                data: {mem_address: mem_address, mem_city: mem_city, mem_pincode: mem_pincode, action: 'address_info'},
//                dataType: 'json',
//                type: 'post',
//                success: function (output) {
//                    var successmessage = output.success;
//                    if (successmessage == 1) {
////                    if (mem_address == '' || mem_city == '' || mem_pincode == '') {
////                        $('.addressa').attr('href', 'javascript:void(0)');
////                    } else {
////                        document.getElementById("addressa").href = "#address";
////                    }
//
//                        window.location = URL_PROFILE_PATH;
//                    } else {
//                        document.getElementById("addressa").href = "#address";
//                    }
//                }
//            });
//        }
//    }
//}

//*****welcome user page starts(line 795-1706)*****

$(document).ready(function () {
    $('#basic_info_processing').css({'display': 'none'});
    $('#contact_info_processing').css({'display': 'none'});
    $('#basic_processing').css({'display': 'none'});
    $('#contact_processing').css({'display': 'none'});
    $('#addcertify_processing').css({'display': 'none'});
});
function compbasic_processing() {
    $('#basiccompany_form').parsley().validate("first");
    if ($('#basiccompany_form').parsley().isValid()) {
        $('#basic_processing').css({'display': 'block'});
        $('#basic_submitting').css({'display': 'none'});
    }
}

function contact_processing() {
    $('#contactcompany_form').parsley().validate("first");
    if ($('#contactcompany_form').parsley().isValid()) {
        $('#contact_processing').css({'display': 'block'});
        $('#contact_submitting').css({'display': 'none'});
    }
}

function compaddition_processing() {

//    var video_url = $('#video_url').val();
//    var sales_currency = $('#sales_currency').val();
//    var total_sales = $('#total_sales').val();
//    var purchase_currency = $('#purchase_currency').val();
//    var total_purchases = $('#total_purchases').val();
//    var register_capital = $('#register_capital').val();
//    var import_percent = $('#import_percent').val();
//    var export_percent = $('#export_percent').val();
//    var ieolicence_no = $('#ieolicence_no').val();
//    var no_of_employ = $('#no_of_employ').val();
//    var manufact_unit = $('#manufact_unit').val();
//    var trade_name = $('#trade_name').val();
//    var dZUploadBro = $('#dZUploadBro').val();
//    var dZUpload = $('#dZUpload').val();
//    var facebook_link = $('#facebook_link').val();
//    var twitter_link = $('#twitter_link').val();
//    var google_link = $('#google_link').val();
//    var youtube_link = $('#youtube_link').val();
//    var linkedin_link = $('#linkedin_link').val();
//    var pinterest_link = $('#pinterest_link').val();

    $('#companyadditional_form').parsley().validate("first");
    if ($('#companyadditional_form').parsley().isValid()) {
        $('#compaddition_processing').css({'display': 'block'});
        $('#compaddition_submitting').css({'display': 'none'});
    }
}

function addproduct_processing() {
    $('#proforms').parsley().validate("first");
    if ($('#proforms').parsley().isValid()) {
        $('#product_processing').css({'display': 'block'});
        $('#product_submitting').css({'display': 'none'});
    }
}



function addbuyer_processing() {
    $('#add_buyingneed').parsley().validate("first");
    if ($('#add_buyingneed').parsley().isValid()) {
        $('#buyer_processing').css({'display': 'block'});
        $('#buyer_submitting').css({'display': 'none'});
    }
}

//var select2Instance = $('#industrytype').data('select2');
//select2Instance.on('results:message', function(params){
//  this.dropdown._resizeDropdown();
//  this.dropdown._positionDropdown();
//});

function basic_back_btn(val) {
    $("#contact_name").focus();
    $("#cmpny_name").focus();
    $('.basic_details').show();
    $('.contact_details').hide();
    $('.payment_details').hide();
    $('.basica').attr('class', 'active');
    $('.contacta').removeAttr('class', 'active');
    $('.paymenta').removeAttr('class', 'active');
    $('.basica').attr('href', '#basic');
    $('.contacta').attr('href', '#contact');
    $('.paymenta').attr('href', '#payment');
    window.location = '#basic';
}

function contact_back_btn() {
    var company_name = $('#company_name').val();
    var mem_address = $('#mem_address').val();
    if (company_name != '' && mem_address != '') {
        $('.basic_details').hide();
        $('.contact_details').show();
        $('.payment_details').hide();
        $('.basica').removeAttr('class', 'active');
        $('.contacta').attr('class', 'active');
        $('.paymenta').removeAttr('class', 'active');
        $('.basica').attr('href', '#basic');
        $('.contacta').attr('href', '#contact');
        $('.paymenta').attr('href', '#payment');
        window.location = '#contact';
    }
}

function payment_back_btn() {
    var company_name = $('#company_name').val();
    var mem_address = $('#mem_address').val();
    if (company_name != '' && mem_address != '') {
        $('.basic_details').hide();
        $('.contact_details').hide();
        $('.payment_details').show();
        $('.basica').removeAttr('class', 'active');
        $('.contacta').removeAttr('class', 'active');
        $('.paymenta').attr('class', 'active');
        $('.basica').attr('href', '#basic');
        $('.contacta').attr('href', '#contact');
        $('.paymenta').attr('href', '#payment');
        window.location = '#payment';
    }
}

function comp_back_btn(val) {
    window.location.href = URL_PROFILE_PATH + val;
}

$(document).ready(function () {
    var memtyp = $('#memsel_type').val();
    if (memtyp == 0) {
        $('input[name="mem_type"]').attr('checked', false);
    }
    if (memtyp == 0 || memtyp != 3) {
        $('#basic_business_type').show();
        $('#basic_industires_type').show();
        $('#basic_service_type').hide();
        $('#servicestype').val('');
        $('#check_buser_type').val(1);
        $('#basic_business_type select').attr('required', true);
        $('#basic_industires_type select').attr('required', true);
        $('#basic_buyer_type select').attr('required', true);
        $('#basic_service_type select').removeAttr('required');
        $('#businesstype').select2({
            tags: true,
            tokenSeparators: ['\t', '\n'],
            //    selectOnClose: true,
            closeOnSelect: true,
            unselect: true,
            placeholder: 'Choose your business types',
            maximumSelectionLength: 4
        });
        $('#industrytype').select2({
            tags: false,
            selectOnBlur: true,
            //    selectOnClose: true,
            closeOnSelect: true,
//            positionDropdown: true,
//            dropdownPosition: 'down',
            tokenSeparators: ['\t', '\n'],
            placeholder: 'Choose your industry types',
            maximumSelectionLength: 4
        });
    } else {
        $('#basic_business_type').hide();
        $('#basic_industires_type').hide();
        $('#basic_service_type').show();
        $('#businesstype').val('');
        $('#check_buser_type').val(0);
        $('#validate_uType').css({'display': 'none'});
        $('#basic_service_type select').attr('required', true);
        $('#basic_buyer_type select').attr('required', true);
        $('#basic_business_type select').removeAttr('required');
        $('#basic_industires_type select').removeAttr('required');
        $('#servicestype').select2({
            tags: true,
            tokenSeparators: ['\t', '\n'],
            //    selectOnClose: true,
            closeOnSelect: false,
            unselect: true,
            placeholder: 'Choose your service types',
            maximumSelectionLength: 4
        });
    }
});
$('#mem_bustype_sel').click(function () {
    $('#basic_business_type').show();
    $('#basic_industires_type').show();
    $('#basic_service_type').hide();
    $('#servicestype').val('');
    $('#check_buser_type').val(1);
    $('#validate_uType').css({'display': 'none'});
    $('#basic_business_type select').attr('required', true);
    $('#basic_industires_type select').attr('required', true);
    $('#basic_buyer_type select').attr('required', true);
    $('#basic_service_type select').removeAttr('required');
    $('#reload_selType').slideUp();
//    $('#reload_selType').animate({'height': '0','display': 'none'}, "slow" );
    $('.small-select .small-optbox p').html('I am a Supplier & Buyer');
//    $('.serv-opt').addClass('col-xs-12 col-sm-6 col-md-6');

    $('#businesstype').select2({
        tags: true,
        selectOnBlur: true,
        //    selectOnClose: true,
        tokenSeparators: ['\t', '\n'],
        placeholder: 'Choose your business types',
        maximumSelectionLength: 4
    });
    $('#industrytype').select2({
        tags: false,
        selectOnBlur: true,
        //    selectOnClose: true,
        tokenSeparators: ['\t', '\n'],
        placeholder: 'Choose your industry types',
        maximumSelectionLength: 4
                //dropdownCss: {display:'none'}
    });
});
$('#mem_servtype_sel').click(function () {
    $('#basic_business_type').hide();
    $('#basic_industires_type').hide();
    $('#basic_service_type').show();
    $('#businesstype').val('');
    $('#check_buser_type').val(0);
    $('#validate_uType').css({'display': 'none'});
    $('#basic_service_type select').attr('required', true);
    $('#basic_buyer_type select').attr('required', true);
    $('#basic_business_type select').removeAttr('required');
    $('#basic_industires_type select').removeAttr('required');
    $('#reload_selType').slideUp();
//     $('#reload_selType').animate({'height': '0','display': 'none'}, "slow" );
    $('.small-select .small-optbox p').html('I am a Service Provider');
//    $('.serv-opt').addClass('col-xs-12');
//    $('.serv-opt').removeClass('col-sm-6 col-md-6');

    $('#servicestype').select2({
        tags: true,
        selectOnBlur: true,
        //    selectOnClose: true,
        tokenSeparators: ['\t', '\n'],
        placeholder: 'Choose your service types',
        maximumSelectionLength: 4
    });
});
if ($('#basic_form').length) {
    $('#basic_form').parsley();
}

$(".my_requirement").on("select2:select select2:unselect", function (e) {
    var items = $(this).val();
    $("#require_items").val(items);
});
//$('#basica').click(function () {
//    alert('s');
//    window.location = '#basic';
//});
//$('#contacta').click(function () {
//    alert('d');
//    window.location = '#contact';
//});

//$("#basic_info").on('click', function () {
//    var cond = $('input[name=mem_type]:checked').val();
//    if (cond == undefined) {
//        $('#validate_uType').css({'display': 'block'});
//    } else {
//        $('#validate_uType').css({'display': 'none'});
//        $('#basic_form').parsley().validate("first");
//        if ($('#basic_form').parsley().isValid()) {
//            $('#basic_info_processing').css({'display': 'block'});
//            $('#basic_info_submit').css({'display': 'none'});
//            var mem_type = $("input[name=mem_type]:checked").val();
//            var about_company = $("#about_company").val();
//            var company_name = $('#company_name').val();
//            var buy_require = $("#require_items").val();
//            if (buy_require == '') {
//                buy_require = $("#ext_require_items").val();
//            }
////            var logo = $('#companylogo').val();
//            var business_type = '';
//            var industry_type = '';
//            var check_type = $('#check_buser_type').val();
//            if (check_type == 1) {
//                business_type = $('#businesstype').val();
//                industry_type = $('#industrytype').val();
//            } else {
//                business_type = $('#servicestype').val();
//            }
//
////            var fileInput = document.getElementById('companylogo');
////            var file = fileInput.files[0];
////            var formData =  new FormData(this);
////            formData.append('file', file);
////            var data = new FormData();
////            for (var x = 0; x < files.length; x++) {
////                data.append("file" + x, files[x]);
////            }
//
//
//            $.ajax({
//                url: URL_MAIN_PATH + '/addbasicinfo',
//                data: {mem_type: mem_type, about_company: about_company, company_name: company_name, business_type: business_type, industry_type: industry_type, buy_require: buy_require, action: 'basic_info'},
////                data: fd,
//                dataType: 'json',
//                type: 'post',
//                success: function (output) {
//                    var successmessage = output.success;
//                    if (successmessage) {
//                        $('#basic_li').load(location.href + ' #basic_li');
//                        if (company_name == '' || business_type == '') {
//                            $('.addressa').attr('href', 'javascript:void(0)');
//                        } else {
//                            document.getElementById("contacta").href = "#contact";
//                        }
//                        $('.basic_details').hide();
//                        $('.contact_details').show();
//                        $('.payment_details').hide();
//                        $('#basic_info_processing').css({'display': 'none'});
//                        $('#basic_info_submit').css({'display': 'block'});
//                        $('.basica').attr('href', '#basic');
//                        $('.contacta').attr('href', '#contact');
//                        $('#basic_li').removeAttr('class', 'active');
//                        $('#contact_li').attr('class', 'active');
//                        $('#payment_li').removeAttr('class', 'active');
////                        $('#reload_selType').load(location.href + ' #reload_selType');
//                        window.location = '#contact';
//                        $("#company_website").focus();
//                        $('#retain_memtype').load(location.href + ' #retain_memtype');
//                    }
//                }
//            });
//        }
//
//    }
//});
$("#basic_info").on('click', function () {
    var cond = $('input[name=mem_type]:checked').val();
    if (cond == undefined) {
        $('#validate_uType').css({'display': 'block'});
    } else {
        $('#validate_uType').css({'display': 'none'});
        $('#basic_form').parsley().validate("first");
        if ($('#basic_form').parsley().isValid()) {
            $('#basic_info_processing').css({'display': 'block'});
            $('#basic_info_submit').css({'display': 'none'});
            var mem_type = $("input[name=mem_type]:checked").val();
            var about_company = $("#about_company").val();
            var company_name = $('#company_name').val();
            var buy_require = $("#require_items").val();
            if (buy_require == '') {
                buy_require = $("#ext_require_items").val();
            }
//            var logo = $('#companylogo').val();
            var business_type = '';
            var industry_type = '';
            var check_type = $('#check_buser_type').val();
            if (check_type == 1) {
                business_type = $('#businesstype').val();
                industry_type = $('#industrytype').val();
            } else {
                business_type = $('#servicestype').val();
            }

//            var fileInput = document.getElementById('companylogo');
//            var file = fileInput.files[0];
//            var formData =  new FormData(this);
//            formData.append('file', file);
//            var data = new FormData();
//            for (var x = 0; x < files.length; x++) {
//                data.append("file" + x, files[x]);
//            }


            $.ajax({
                url: URL_MAIN_PATH + '/addbasicinfo',
                data: {mem_type: mem_type, about_company: about_company, company_name: company_name, business_type: business_type, industry_type: industry_type, buy_require: buy_require, action: 'basic_info'},
//                data: fd,
                dataType: 'json',
                type: 'post',
                success: function (output) {
                    var successmessage = output.success;
                    if (successmessage) {
                        $('#basic_li').load(location.href + ' #basic_li');
                        if (company_name == '' || business_type == '') {
                            $('.addressa').attr('href', 'javascript:void(0)');
                        } else {
                            document.getElementById("contacta").href = "#contact";
                        }
                        $('.basic_details').hide();
                        $('.contact_details').show();
                        $('.payment_details').hide();
                        $('#basic_info_processing').css({'display': 'none'});
                        $('#basic_info_submit').css({'display': 'block'});
                        $('.basica').attr('href', '#basic');
                        $('.contacta').attr('href', '#contact');
                        $('#basic_li').removeAttr('class', 'active');
                        $('#contact_li').attr('class', 'active');
                        $('#payment_li').removeAttr('class', 'active');
//                        $('#reload_selType').load(location.href + ' #reload_selType');
                        window.location = '#contact';
                        $("#company_website").focus();
                        $('#retain_memtype').load(location.href + ' #retain_memtype');
                    }
                }
            });
        }

    }
});
if ($('#contact_form').length) {
    $('#contact_form').parsley();
}
$("#contact_info").on('click', function () {
    var mem_country = $('#mem_country').val();
//    var mobile_number = $('#mobile_number').val();
//    console.log(mem_country);
//    if(mem_country == 'in') {
//        var mlen = mobile_number.length;
//    } else {
//
//    }

    $('#contact_form').parsley().validate("first");
    if ($('#contact_form').parsley().isValid()) {
        var contact_name = $('#contact_name').val();
        var mem_country = $('#mem_country').val();
        var mem_website = $('#company_website').val();
        var mobile_number = $('#mobile_number').val();
        var mobile_code = $('#mobile_code').val();
        var mem_telephone = $('#telephone_number').val();
        var mem_address = $('#mem_address').val();
        var mem_city = $('#mem_city').val();
        var mem_pincode = $('#mem_pincode').val();
        if (mobile_number != '') {
            $.ajax({
                url: URL_MAIN_PATH + '/checkmobilevalid',
                type: 'post',
                dataType: 'json',
                data: {mobileval: mobile_number, mem_country: mem_country},
                success: function (output) {
                    var successval = output.errorval;
                    var successerr = output.err;
                    if (successval == '1') {
                        $('#mobile_number').val('');
                        if (successerr == '3') {
                            $('#error_valnw').show();
                        } else {
                            $('#error_val').show();
                        }
                        setInterval(function () {
                            $('#error_val').hide();
                            $('#error_valnw').hide();
                        }, 6000);
                        return false;
                    } else {
                        $('#error_val').hide();
                        $('#error_valnw').hide();
                        $('#contact_info_processing').css({'display': 'block'});
                        $('#contact_info_submit').css({'display': 'none'});
                        $.ajax({
                            url: URL_MAIN_PATH + '/addbasicinfo',
                            data: {contact_name: contact_name, mem_country: mem_country, mem_website: mem_website, mobile_code: mobile_code, mobile_number: mobile_number, mem_telephone: mem_telephone, mem_address: mem_address, mem_city: mem_city, mem_pincode: mem_pincode, action: 'contact_info'},
                            dataType: 'json',
                            type: 'post',
                            success: function (output) {
                                var successmessage = output.success;
                                if (successmessage) {
                                    $('#contact_li').load(location.href + ' #contact_li');
                                    if (mobile_number == '' || contact_name == '' || mem_country == '') {
                                        $('.paymenta').attr('href', 'javascript:void(0)');
                                    } else {
                                        document.getElementById("paymenta").href = "#payment";
                                    }
                                    if (mem_country == 'in') {
                                        $('#countrymobilediv1').show();
                                    } else {
                                        $('#countrymobilediv1').hide();
                                    }
                                    $('.basic_details').hide();
                                    $('.contact_details').hide();
                                    $('.payment_details').show();
                                    $('#contact_info_processing').css({'display': 'none'});
                                    $('#contact_info_submit').css({'display': 'block'});
                                    $('.basica').attr('href', '#basic');
                                    $('.contacta').attr('href', '#contact');
                                    $('.paymenta').attr('href', '#payment');
                                    $('#basic_li').removeAttr('class', 'active');
                                    $('#contact_li').removeAttr('class', 'active');
                                    $('#payment_li').attr('class', 'active');
                                    window.location = '#payment';
                                }
                            }
                        });
                    }

                }
            });
        }
    }

});
$("#verification_info").on('click', function () {
    window.location = '#payment';
    location.reload();
});
$("#free_paybtn").on('click', function () {
    var payment_status = 1;
    $.ajax({
        url: URL_MAIN_PATH + '/addbasicinfo',
        data: {payment_status: payment_status, action: 'payment'},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            var successmessage = output.success;
            if (successmessage == 1) {
                window.location.href = URL_PROFILE_PATH;
            }
        }
    });
    return false;
});
$("#premium_paybtn").on('click', function () {
    var payment_status = 2;
    $.ajax({
        url: URL_MAIN_PATH + '/addbasicinfo',
        data: {payment_status: payment_status, action: 'payment'},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            var successmessage = output.success;
            if (successmessage) {
                window.location.href = URL_PROFILE_PATH + 'addons/upgrade-membership.php';
            }
        }
    });
    return false;
});
if ($('#emailverify_form').length) {
    $('#emailverify_form').parsley();
}

if ($('#mobile_form').length) {
    $('#mobile_form').parsley();
}

$("#verifymobile_button").on('click', function () {
    $('#mobile_form').parsley().validate("first");
    if ($('#mobile_form').parsley().isValid()) {
        $('#verifymobile_button').attr('disabled', 'true');
        $('#verifymobile_button').val('Loading....');
        var mobilevalue = $('#verify_mobile').val();
        var mobotpval = $('#mobotpval').val();
        var otp_pass = $('#otp_pass').val();
        if (mobotpval == 1) {
            var actionval = 'send_otp';
        } else {
            actionval = 'otp_check';
        }
        $.ajax({
            url: URL_MAIN_PATH + '/mobileverified',
            data: {action: actionval, mobilevalue: "9944668971", otp_pass: otp_pass},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                var successmessage = output.success;
                if (successmessage) {
                    if (successmessage == 1 && mobotpval == 1) {
                        $('#otp_pass').attr('required', 'required');
                        $('#verifya').attr('href', '#verification');
                        $('#mobotpval').val(2);
                        $('.basic_details').hide();
                        $('.contact_details').hide();
                        $('#mobile_verify').show();
                        $('#mobile_div').css('display', 'none');
                        $('#otp_div').css('display', 'block');
                        $('.verification_details').show();
                        $('.payment_details').hide();
                        $('#verifymobile_button').removeAttr('disabled');
                        $('#verifymobile_button').val('Activate Mobile Number');
                        window.location = '#verification';
//                    window.location = URL_PROFILE_PATH;
                    } else {
                        if (successmessage == 0) {
                            $('#mobotpval').val(1);
                            $('#mobile_alert').text('Your Verification Code is Expired. Resend Verification Code And Activate Your Mobile Number').show();
                            $('#otp_pass').removeAttr('required');
                            $('#verifya').attr('href', '#verification');
                            $('#basic_li').removeAttr('class', 'active');
                            $('#contact_li').removeAttr('class', 'active');
                            $('#verify_li').attr('class', 'active');
                            $('.basic_details').hide();
                            $('.contact_details').hide();
                            $('#mobile_verify').show();
                            $('#mobile_div').css('display', 'block');
                            $('#otp_div').css('display', 'none');
                            $('.verification_details').show();
                            $('.payment_details').hide();
                            $('#verifymobile_button').removeAttr('disabled');
                            $('#verifymobile_button').val('Activate Mobile Number');
                            window.location = '#verification';
                        } else {
                            $('#mobile_alert').hide();
//                            window.location = URL_PROFILE_PATH;
                            window.location = '#verification';
                        }
                    }
                } else {
//                    document.getElementById("verifya").href = "#verification";
                    $('#verifya').attr('href', '#verification');
                }
            }
        });
    }
});
if ($('#mobile_form1').length) {
    $('#mobile_form1').parsley();
}

$("#verifymobile_button1").on('click', function () {
    $('#mobile_form1').parsley().validate("first");
    if ($('#mobile_form1').parsley().isValid()) {
        $('#verifymobile_button1').attr('disabled', 'true');
        $('#verifymobile_button1').val('Loading....');
        var mobilevalue = $('#verify_mobile1').val();
        var mobotpval = $('#mobotpval1').val();
        var otp_pass = $('#otp_pass1').val();
        if (mobotpval == 1) {
            var actionval = 'send_otp';
        } else {
            actionval = 'otp_check';
        }

        $.ajax({
            url: URL_MAIN_PATH + '/mobileverified',
            data: {action: actionval, mobile_value: mobilevalue, otp_pass: otp_pass},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                var successmessage = output.success;
                if (successmessage == 1 && mobotpval == 1) {
                    $('#otp_pass1').attr('required', 'required');
                    $('#verifya').attr('href', '#verification');
                    $('#mobotpval1').val(2);
                    $('.basic_details').hide();
                    $('.address_details').hide();
                    $('.contact_details').hide();
                    $('#mobile_verify1').show();
                    $('#mobile_div1').css('display', 'none');
                    $('#otp_div1').css('display', 'block');
                    $('.verification_details').show();
                    $('.payment_details').hide();
                    $('#verifymobile_button1').removeAttr('disabled');
                    $('#verifymobile_button1').val('Activate Mobile Number');
                    $('#otp_text').text('Enter Your OTP Password');
                    $('#otp_pass1').val('');
                    window.location = '#verification';
//                    window.location = URL_PROFILE_PATH;
                } else {
                    if (successmessage == 0) {
                        $('#mobotpval1').val(1);
                        $('#mobile_alert1').text('OTP password is wrong. Please try again').show();
                        $('#otp_pass1').removeAttr('required');
                        document.getElementById("verifya").href = "#verification";
                        $('.basic_details').hide();
                        $('.address_details').hide();
                        $('.contact_details').hide();
                        $('#mobile_verify1').show();
                        $('#mobile_div1').css('display', 'block');
                        $('#otp_div1').css('display', 'none');
                        $('.verification_details').show();
                        $('.payment_details').hide();
                        $('#verifymobile_button1').removeAttr('disabled');
                        $('#verifymobile_button1').val('Activate Mobile Number');
                        $('#otp_text').text('Verify your mobile number');
                        window.location = '#verification';
                    } else if (successmessage == 2) {
                        $('#mobotpval1').val(1);
                        $('#mobile_alert1').text('Mobile number is already exist').show();
                        $('#otp_pass1').removeAttr('required');
                        document.getElementById("verifya").href = "#verification";
                        $('.basic_details').hide();
                        $('.address_details').hide();
                        $('.contact_details').hide();
                        $('#mobile_verify1').show();
                        $('#mobile_div1').css('display', 'block');
                        $('#otp_div1').css('display', 'none');
                        $('.verification_details').show();
                        $('.payment_details').hide();
                        $('#verifymobile_button1').removeAttr('disabled');
                        $('#verifymobile_button1').val('Send OTP Password');
                        window.location = '#verification';
                    } else {
                        $('#mobile_alert1').hide();
                        window.location = URL_PROFILE_PATH;
//                        window.location = '#payment';
                    }
                }

            }
        });
    }
});
//$(function () {
//    $('#basic_form').parsley().on('field:validated', function () {
//        var ok = $('.parsley-error').length === 0;
//        $('.bs-callout-info').toggleClass('hidden', !ok);
//        $('.bs-callout-warning').toggleClass('hidden', ok);
//    })
//            .on('form:submit', function () {
//                return false; // Don't submit form for this demo
//            });
//});
$(document).ready(function () {
    var hashValue = location.hash;
    hashData = hashValue.replace(/^#/, '');
    var busb2mem_type = $('#busb2mem_type').val();
    var bus_country = $('#bus_country').val();
    if (busb2mem_type == 4 || busb2mem_type == 5) {
        $('#verification_details').show();
    }

    var company_name = $('#company_name').val();
    var check_type = $('#check_buser_type').val();
    var business_type;
    if (check_type == 1)
        business_type = $('#businesstype').val();
    else
        business_type = $('#servicestype').val();
    var mem_country = $('#mem_country').val();
    var contact_name = $('#contact_name').val();
    var mobile_number = $('#mobile_number').val();
    var mem_address = $('#mem_address').val();
    var mem_city = $('#mem_city').val();
    var mem_pincode = $('#mem_pincode').val();
    if (hashValue == '#basic') {
        $('#basic_li').attr('class', 'active');
        $('#contact_li').removeAttr('class', 'active');
        $('#payment_li').removeAttr('class', 'active');
    } else if (hashValue == '#contact') {
        $('#basic_li').removeAttr('class', 'active');
        $('#contact_li').attr('class', 'active');
        $('#payment_li').removeAttr('class', 'active');
    } else if (hashValue == '#payment') {
        $('#basic_li').removeAttr('class', 'active');
        $('#contact_li').removeAttr('class', 'active');
        $('#payment_li').attr('class', 'active');
    } else {
        $('#basic_li').attr('class', 'active');
        $('#contact_li').removeAttr('class', 'active');
        $('#payment_li').removeAttr('class', 'active');
    }
    if (busb2mem_type != 4 && busb2mem_type != 5) {
        $('#verify_mobile1').val(mobile_number);
    }
    if (mem_country == 'in' || bus_country == 'in') {
        $('#countrymobilediv1').show();
    } else {
        $('#countrymobilediv1').hide();
    }
//    if (company_name == '' || businesstype == '') {
//        $('.contacta').attr('href', 'javascript:void(0)');
//    } else {
//        document.getElementById("contacta").href = "#contact";
//    }
//    if (mobile_number == '' || contact_name == '' || mem_country == '') {
//        $('.addressa').attr('href', 'javascript:void(0)');
//    } else {
//        document.getElementById("addressa").href = "#address";
//    }
//    if (mem_address == '' || mem_city == '' || mem_pincode == '') {
//        $('.addressa').attr('href', 'javascript:void(0)');
//    } else {
//        document.getElementById("addressa").href = "#address";
//    }

    if ((hashData == 'basic')) {
        $('.basic_details').show();
        $('.contact_details').hide();
        $('.payment_details').hide();
        $('.basica').attr('href', '#basic');
    } else if ((hashData == 'contact') && (company_name != '' || business_type != '')) {
        $('.basic_details').hide();
        $('.contact_details').show();
        $('.payment_details').hide();
        $('.basica').attr('href', '#basic');
        $('.contacta').attr('href', '#contact');
    } else if ((hashData == 'payment') && (contact_name != '' || mem_address != '' || mem_city != '' || mem_pincode != '')) {
        $('.basic_details').hide();
        $('.contact_details').hide();
        $('.payment_details').show();
        $('.basica').attr('href', '#basic');
        $('.contacta').attr('href', '#contact');
        $('.paymenta').attr('href', '#payment');
    } else {
        $('.basic_details').show();
        $('.contact_details').hide();
        $('.payment_details').hide();
        $('.basica').attr('href', '#basic');
    }
});
$(window).load(function () {
    $("#company_website").focus();
    $("#contact_name").focus();
    $("#cmpny_name").focus();
    $("#video_url").focus();
    getphonecode();
});
function getphonecode(complaintmem) {
    if (complaintmem) {
        var compmem = complaintmem.split(',');
        var mem_country = compmem[0];
    } else {
        var mem_country = $('#mem_country').val();
        $('#memcountry_id').val(mem_country);
    }
    $.ajax({
        url: URL_MAIN_PATH + '/mobilecode',
        data: {mem_country: mem_country},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            var mobile_code = output.mobile_code;
            $('#mobile_code').val(mobile_code);
        }
    });
}

$('ul.basiccontaddinfo a').click(function () {
    var txt = $(this).attr('href');
    var txtvalue = txt.replace(/^#/, '');
    var hashValue = location.hash;
    hashData = hashValue.replace(/^#/, '');
//    var parentvalue = $(hashValue).parent().attr('id');
    var company_name = $('#company_name').val();
    var businesstype = $('#businesstype option:selected').text();
    var servicestype = $('#servicestype option:selected').text();
    var mem_country = $('#mem_country').val();
//    if (mem_country == 'in') {
//        $('#countrymobilediv').show();
//    } else {
//        $('#countrymobilediv').hide();
//    }
    var contact_name = $('#contact_name').val();
    var mobile_number = $('#mobile_number').val();
//    var mobile_code = $('#mobile_code').val();
    var mem_address = $('#mem_address').val();
    var mem_city = $('#mem_city').val();
    var mem_pincode = $('#mem_pincode').val();
    if (txt == '#basic') {
        $('#basic_li').attr('class', 'active');
        $('#contact_li').removeAttr('class', 'active');
        $('#payment_li').removeAttr('class', 'active');
    } else if (txt == '#contact') {
        $('#basic_li').removeAttr('class', 'active');
        $('#contact_li').attr('class', 'active');
        $('#payment_li').removeAttr('class', 'active');
    } else if (txt == '#payment') {
        $('#basic_li').removeAttr('class', 'active');
        $('#contact_li').removeAttr('class', 'active');
        $('#payment_li').attr('class', 'active');
    }
//    else {
//        $('#basic_li').attr('class', 'active');
//        $('#contact_li').removeAttr('class', 'active');
//        $('#address_li').removeAttr('class', 'active');
//        $('#verify_li').removeAttr('class', 'active');
//    }


    if (company_name == '') {
        $('.contacta').attr('href', 'javascript:void(0)');
    } else {
        $('.contacta').attr('href', '#contact');
    }

    if (mobile_number == '' || contact_name == '' || mem_country == '') {
        $('.paymenta').attr('href', 'javascript:void(0)');
    } else {
        $('.paymenta').attr('href', '#payment');
    }

    if ((txtvalue == 'basic' || hashData == 'basic') && (txtvalue != 'contact' && txtvalue != 'payment')) {
        $('.basic_details').show();
        $('.contact_details').hide();
        $('.payment_details').hide();
        $('.basica').attr('href', '#basic');
    } else if ((txtvalue == 'contact' || hashData == 'contact') && (company_name != '') && (txtvalue != 'basic' && txtvalue != 'payment')) {
        $('.basic_details').hide();
        $('.contact_details').show();
        $('.payment_details').hide();
        $('.basica').attr('href', '#basic');
        $('.contacta').attr('href', '#contact');
    } else if ((txtvalue == 'payment' || hashData == 'payment') && (mem_country != '' && contact_name != '' && mobile_number != '') && (txtvalue != 'contact' && txtvalue != 'basic')) {
        $('.basic_details').hide();
        $('.contact_details').hide();
        $('.payment_details').show();
        $('.basica').attr('href', '#basic');
        $('.contacta').attr('href', '#contact');
        $('.paymenta').attr('href', '#payment');
    } else {
        $('.basic_details').show();
        $('.contact_details').hide();
        $('.payment_details').hide();
        $('.basica').attr('href', '#basic');
    }
});
//****************welcome user page ends***********

//function checkedAll(elem) {
//    if ($(elem).is(':checked')) {
//        $(".selectstandthis").attr("checked", "checked");
//    } else {
//        $(".selectstandthis").attr("checked", false);
//    }
//
//}
//********certification details starts(line 1718 to 1862)***********
$(".selectall").change(function () {
    $(".selectstandthis").prop('checked', $(this).prop("checked"));
});
$('.selectstandthis').change(function () {
    if (false == $(this).prop("checked")) {
        $(".selectall").prop('checked', false);
    }
    if ($('.selectstandthis:checked').length == $('.selectstandthis').length) {
        $(".selectall").prop('checked', true);
    }
});
//$('.selectstandthisajax').change(function () {
//    if (false == $(this).prop("checked")) {
//        $(".selectall").prop('checked', false);
//    }
//    if ($('.selectstandthisajax:checked').length == $('.selectstandthisajax').length) {
//        $(".selectall").prop('checked', true);
//    }
//});
$(".selectallqa").change(function () {
    $(".selectqathis").prop('checked', $(this).prop("checked"));
});
$('.selectqathis').change(function () {
    if (false == $(this).prop("checked")) {
        $(".selectallqa").prop('checked', false);
    }
    if ($('.selectqathis:checked').length == $('.selectqathis').length) {
        $(".selectallqa").prop('checked', true);
    }
});
function checkedAllqa(elem) {
    if ($(elem).is(':checked')) {
        $(".selectqathis").attr("checked", "checked");
    } else {
        $(".selectqathis").attr("checked", false);
    }
}
function remove_stand_certify() {
    var cbs1 = document.getElementsByName('selectstandthis[]');
    var hasChecked = false;
    var blkstr1 = [];
    var cbs1 = document.getElementsByName('selectstandthis[]');
    for (var i = 0; i < cbs1.length; i++)
    {
        if (cbs1[i].checked == true)
        {
            hasChecked = true;
            var cb = cbs1[i].value;
            blkstr1.push(cb);
        }
    }
    var selected_vals = blkstr1.join(",");
    $('#deletestand_id').val(selected_vals);
    var deleteid = $('#deletestand_id').val();
    if (hasChecked == true) {
        var confirmuser = confirm('Are you sure do you want to delete this Certificate?');
        if (confirmuser == true) {
            var hidstandqa = 'standard';
            $.ajax({
                url: URL_PROFILE_PATH + 'deletecertify',
                type: 'post',
                dataType: 'json',
                data: {deleteid: deleteid, hidstandqa: hidstandqa},
                success: function (output) {
                    if (output.message) {
                        $('#success_div').html(output.message).show();
                        setInterval(function () {
                            location.reload();
                        }, 3000);
                    } else {
                        $('#success_div').html('').hide();
                    }
                }
            });
        }
    } else {
        alert('Choose any one certificate to delete');
    }
}

function delete_certify(id) {
    var result = confirm("Are you sure do you want to delete this Certificate?");
    if (result) {
        $.ajax({
            url: URL_PROFILE_PATH + 'deletecertify',
            type: 'post',
            dataType: 'json',
            data: {deleteid: id},
            success: function (output) {
                $('#qafile_div').load(location.href + ' #qafile_div');
                $('#load_certify_types').load(location.href + ' #load_certify_types');
            }
//            if (output.message) {
//                $('#qasuccess_div').html(output.message).show();
//                setInterval(function () {
//                    location.reload();
//                }, 3000);
//            } else {
//                $('#qasuccess_div').html('').hide();
//            }
//        }

        });
    }
}

function remove_qa_certify() {
    var cbs1 = document.getElementsByName('selectqathis[]');
    var hasChecked = false;
    var blkstr1 = [];
    for (var i = 0; i < cbs1.length; i++)
    {
        if (cbs1[i].checked == true)
        {
            hasChecked = true;
            var cb = cbs1[i].value;
            blkstr1.push(cb);
        }
    }
    var selected_vals = blkstr1.join(",");
    $('#deleteqa_id').val(selected_vals);
    var deleteid = $('#deleteqa_id').val();
    if (hasChecked == true) {
        var confirmuser = confirm('Are you sure do you want to delete this Certificate?');
        if (confirmuser == true) {
            var hidstandqa = 'qa';
            $.ajax({
                url: URL_PROFILE_PATH + 'deletecertify',
                type: 'post',
                dataType: 'json',
                data: {deleteid: deleteid, hidstandqa: hidstandqa},
                success: function (output) {
                    if (output.message) {
                        $('#qasuccess_div').html(output.message).show();
                        setInterval(function () {
                            location.reload();
                        }, 3000);
                    } else {
                        $('#qasuccess_div').html('').hide();
                    }
                }

            });
        }
    } else {
        alert('Choose any one certificate to delete');
    }
}
//*************certification details ends***********
//********welcome user page*******
function validmobile(mobileval) {
    var mem_country = $('#mem_country').val();
    $('#error_val').hide();
    if (mobileval != '') {
        $.ajax({
            url: URL_MAIN_PATH + '/checkmobilevalid',
            type: 'post',
            dataType: 'json',
            data: {mobileval: mobileval, mem_country: mem_country},
            success: function (output) {
                var successval = output.errorval;
                var successerr = output.err;
                if (successval == '1') {
                    $('#mobile_number').val('');
                    if (successerr == '3') {
                        $('#error_valnw').show();
                    } else {
                        $('#error_val').show();
                    }
                    setInterval(function () {
                        $('#error_val').hide();
                        $('#error_valnw').hide();
                    }, 6000);
                    return false;
                } else {
                    $('#error_val').hide();
                    $('#error_valnw').hide();
                }
            }
        });
    }
}
//function getpincode(cityvalue) {
//
//}
//********profile index**********
function loadbusinesstype(membertype) {
    $.ajax({
        url: URL_PROFILE_PATH + 'loadbusinesstype',
        data: {membertype: membertype},
        dataType: 'html',
        type: 'post',
        success: function (output) {
            $('#indiv_bus_type').html(output);
        }
    });
}
/*
 * resend otp button (change mobile number in profile page)
 */
$('#sendotp').click(function () {
    var tally = ($(this).data('clicks') || 0) + 1;
    if (tally < 4) {
        $(this).data('clicks', tally);
        var mobilenum = $('#mobilenumber').val();
        resendotp(mobilenum);
    } else {
        $('#disable_otp_btn input[type="button"]').attr('disabled', 'disabled');
        $('#otpinfomsg').css({'display': 'block'});
        $.ajax({
            url: '/profile/settings/mobile-otp-block',
            data: {},
            type: 'post',
            success: function (output) {
            }
        });
    }
});
/*
 * resend otp function for basic form page
 */
function resendotp_basic(mobilenumber) {
    $('#sendotp_basic').val('Loading...');
    $('#sendotp_basic').attr('disabled', true);
    $.ajax({
        url: URL_MAIN_PATH + '/resendotpbasic',
        data: {mobilenumber: mobilenumber},
        dataType: 'json',
        type: 'get',
        success: function (output) {
            var successvalss = output.mobilebasic;
            if (successvalss == 1) {
                $('#sendotp_basic').val('Resend OTP Password');
                $('#sendotp_basic').attr('disabled', false);
                $('#sendotpsuccess').slideDown().show();
                setInterval(function () {
                    $('#sendotpsuccess').hide('slow');
                }, 5000);
            } else {
                $('#sendotp_basic').val('try later.');
                $('#sendotp_basic').attr('disabled', true);
                $('#otpinfomsg').css({'display': 'block'});
            }
        }
    });
}
/*
 * resend otp button  in basic form page
 */
$('#sendotp_basic').click(function () {
    var tally = ($(this).data('clicks') || 0) + 1;
    if (tally < 4) {
        $(this).data('clicks', tally);
        var mobilenum = $('#mobilenumber').val();
        resendotp_basic(mobilenum);
    } else {
        $('#disable_otp_btn input[type="button"]').attr('disabled', 'disabled');
        $('#otpinfomsg').css({'display': 'block'});
        $.ajax({
            url: '/profile/settings/mobile-otp-block',
            data: {},
            type: 'post',
            success: function (output) {
            }
        });
    }
});
/*
 *function check resend email activation for basic form
 */

$('#validate_email').click(function () {
    var tally = ($(this).data('clicks') || 0) + 1;
    if (tally < 4) {
        $(this).data('clicks', tally);
        verify_resendmail_activation(); //call resend activation link function
    } else {
        $('#validate_email').val('Try later');
        $('#validate_email').attr('disabled', 'disabled');
        $('#verifymailinfomsg').css({'display': 'block'});
        $.ajax({
            url: '/profile/settings/email-activation-block',
            data: {},
            type: 'post',
            success: function (output) {
            }
        });
    }
});
//$("#validate_email").on('click', function () {
function verify_resendmail_activation() {
    $('#emailverify_form').parsley().validate("first");
    if ($('#emailverify_form').parsley().isValid()) {
        var emailvalue = $('#verify_email').val();
        var session_memid = $('#session_memid').val();
        var session_memname = $('#session_memname').val();
        var session_memtype = $('#session_memtype').val();
        $('#validate_email').attr('disabled', 'true');
        $('#validate_email').val(" Loading....");
        $('#email_error').hide();
        $.ajax({
            url: URL_MAIN_PATH + '/emailalreadyexist',
            data: {emailvalue: emailvalue},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                if (output.succ_val == 0) {
                    $('#email_error').hide();
                    $.ajax({
                        url: URL_MAIN_PATH + '/emailverified',
                        data: {action: 'email_verify', email_value: emailvalue, session_memid: session_memid, session_memname: session_memname, session_memtype: session_memtype},
                        dataType: 'json',
                        type: 'post',
                        success: function (output) {
                            var successmessage = output.success;
                            if (successmessage == 1) {
                                $('#validate_email').removeAttr('disabled');
                                $('#validate_email').val('Resend Activation Link');
                                $('#verifymailsuccessmsg').css({'display': 'block'});
                                $('#verifya').attr('href', '#verification');
                                $('.basic_details').hide();
                                $('.address_details').hide();
                                $('.contact_details').hide();
                                $('#email_verify').fadeIn('slow');
                                setInterval(function () {
                                    $('#email_verify').fadeOut('slow');
                                }, 6000);
                                $('.verification_details').show();
                                $('.payment_details').hide();
                                $('#basic_li').removeAttr('class', 'active');
                                $('#contact_li').removeAttr('class', 'active');
                                $('#address_li').removeAttr('class', 'active');
                                $('#verify_li').attr('class', 'active');
                                $('#payment_li').removeAttr('class', 'active');
                                setInterval(function () {
                                    $('#verifymailsuccessmsg').css({'display': 'none'});
                                }, 3000);
//                                window.location = '#verification';
                            } else if (successmessage == 0) {
                                $('#verifya').attr('href', '#verification');
                                $('#validate_email').val('Try later');
                                $('#validate_email').attr('disabled', 'disabled');
                                $('#verifymailinfomsg').css({'display': 'block'});
                            } else {
                                $('#validate_email').val('Already activated');
                                $('#validate_email').attr('disabled', 'disabled');
                                $('#alreadyverifymailinfomsg').css({'display': 'block'});
                                var chckwelcom_email = $('#chckwelcom_email').val();
                                setInterval(function () {
                                    $('#refresh_email_verify').hide();
                                    if (chckwelcom_email == 1)
                                        window.location.href = URL_PROFILE_PATH;
                                }, 3000);
                            }
                        }
                    });
                } else {
                    $('#email_error').show();
                    $('#validate_email').removeAttr('disabled');
                    $('#validate_email').val('Resend Activation Link');
                }
            }
        });
    }
}
//function check resend email activation for change email option
$('#email_resend').click(function () {
    var tally = ($(this).data('clicks') || 0) + 1;
    if (tally < 4) {
        $(this).data('clicks', tally);
        resendmailactivation();
    } else {
        $('#email_resend').val('Try later');
        $('#email_resend').attr('disabled', 'disabled');
        $('#mailinfomsg').css({'display': 'block'});
        $.ajax({
            url: '/profile/settings/email-activation-block',
            data: {},
            type: 'post',
            success: function (output) {
            }
        });
    }
});
//********change mobile number in profile settings*********
function resendotp(mobilenumber) {
    $('#sendotp').val('Loading...');
    $('#sendotp').attr('disabled', true);
    $.ajax({
        url: URL_PROFILE_PATH + 'resendotp',
        data: {mobilenumber: mobilenumber},
        dataType: 'json',
        type: 'get',
        success: function (output) {
            var successval = output.mobile;
            if (successval == 1) {
                $('#sendotp').val('Resend OTP Password');
                $('#sendotp').attr('disabled', false);
                $('#sendotpsuccess').slideDown().show();
                setInterval(function () {
                    $('#sendotpsuccess').hide('slow');
                }, 5000);
            } else if (successval == 0) {
                $('#sendotp').val('try later.');
                $('#sendotp').attr('disabled', true);
                $('#otpinfomsg').css({'display': 'block'});
            }
        }
    });
}

//********change email in profile settings*********
$('.resendemail_btn').hide();
var newemailval = $('#new_email').val();
if (newemailval != '') {
    $('.resendemail_btn').show();
}
function resendmailactivation() {
    var curremail = $('#current_email').val();
    var newemail = $('#new_email').val();
    $.ajax({
        url: URL_PROFILE_PATH + 'resendemailactivationcode',
        data: {newemail: newemail, curremail: curremail},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            var successval = output.email;
            if (successval == 1) {
                $('#email_resend').val('Resend activation link');
                $('#email_resend').attr('disabled', false);
                $('#resendemailsuccess').slideDown().show();
                setInterval(function () {
                    $('#resendemailsuccess').hide('slow');
                }, 5000);
            } else if (successval == 0) {
                $('#email_resend').val('try later.');
                $('#email_resend').attr('disabled', true);
                $('#mailinfomsg').css({'display': 'block'});
            }
        }
    });
}

//********change password in profile settings*********
function checkcurrentpass(currentpass, currentpassid, partner_pass) {
    var currentpassword = currentpass;
    var ajax_url;
    var partner_pass = typeof partner_pass !== 'undefined' ? partner_pass : 0;
    if (partner_pass == 1) {
        ajax_url = URL_PARTNERS_PATH + '/checkcurrentpass';
    } else {
        ajax_url = URL_PROFILE_PATH + 'checkcurrentpass';
    }
    if (currentpassword != '' && currentpassword.length >= 6) {
        $.ajax({
            url: ajax_url,
            data: {currentpassword: currentpassword},
            dataType: 'json',
            type: 'post',
            success: function (output) {
                var successmessage = output.success;
                if (successmessage == 1) {
                    $('#wrongpass').hide();
                } else {
                    $('#wrongpass').show();
                    $('#' + currentpassid).val('');
                    setInterval(function () {
                        $('#wrongpass').hide();
                    }, 5000);
                    return false;
                }
            }
        });
    }
}
function checknewpass(newpass) {
    var newpassword = newpass;
    var olspass = $('#current_pass').val();
    if (newpassword.length >= 6) {
        if (olspass == newpassword) {
            $('#newpass').show();
            $('#new_pass').val('');
            setInterval(function () {
                $('#newpass').hide();
            }, 5000);
            return false;
        } else {
            $('#newpass').hide();
        }
    }
}
//********change email in profile settings*********
function checknewemail(newemail) {
    var newemail = newemail;
    var oldemail = $('#current_email').val();
    if (newemail != '') {
        if (newemail == oldemail) {
            $('#alreadyexist').show();
            $('#alreadyexist').val('It should be same as current email address');
            $('#new_email').val('');
            setInterval(function () {
                $('#alreadyexist').hide();
            }, 5000);
            return false;
        } else {
            $('#alreadyexist').hide();
        }
    }
}

function checknewmobile(newmobile) {
    var newmobile = newmobile;
    var oldmobile = $('#current_mobile').val();
    if (newmobile != '') {
        if (newmobile == oldmobile) {
            $('#alreadymobexist').show();
            $('#alreadymobexist').val('It should be same as current mobile number');
            $('#new_mobile').val('');
            setInterval(function () {
                $('#alreadymobexist').hide();
            }, 5000);
            return false;
        } else {
            $('#alreadymobexist').hide();
        }
    }
}

$(document).ready(function () {
    $('#confirm_pass').bind("cut copy paste", function (e) {
        e.preventDefault();
    });
//    $("#supp_refine_region").load(location.href + " #supp_refine_region>*", "");
});
//*********custom domain settings in profile*********
function checkdomainavailability(domainvalue) {
    $('#check_domain').attr('disabled', true);
    $('#check_domain').val('Loading...');
    $('#slug_but').attr('disabled', true);
    $('#slug_but').val('Loading...');
    $.ajax({
        url: URL_PROFILE_PATH + 'settings/checkdomainavailability',
        data: {domainvalue: domainvalue},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            if (output == 'no') {
                $('#domain_err').text(domainvalue + ' is not registered. Plese register your domain or enter another domain').show();
                $('#custom_url').val('');
            } else {
                $('#domain_err').hide();
            }
            $('#check_domain').attr('disabled', false);
            $('#check_domain').val('Check Availability');
            $('#slug_but').attr('disabled', false);
            $('#slug_but').val('Save');
        }
    });
}

//*****profile contact details form validation**********
var $form = $('#contactcompany_form');
$form.find('button').click(function () {
    form.validate();
});
//******market region in basic company profile***********
$("#market_region_all").change(function () {
    if ($(this).prop('checked') == true) {
        $(".chckall_market").prop('checked', true);
    } else {
        $(".chckall_market").prop('checked', false);
    }
});
//******market region checkbox selection in basic company profile***********
function check_selbox() {
    var sel_chckbox = $(".chckall_market:checked").length;
    if (sel_chckbox == 7) {
        $("#market_region_all").prop('checked', true);
    } else {
        $("#market_region_all").prop('checked', false);
    }
}

function pricemode(val) {
    if (val == 1) {
        $('#getpricedetails').show();
        $('#currency').attr('required', 'required');
        $('#preferred_price').attr('required', 'required');
        $('#preferred_priceto').attr('required', 'required');
        $('#production_capacity_unit1').attr('required', 'required');
    } else {
        $('#getpricedetails').hide();
        $('#currency').val('');
        $('#currency').removeAttr('required');
        $('#preferred_price').val('');
        $('#preferred_price').removeAttr('required');
        $('#preferred_priceto').val('');
        $('#preferred_priceto').removeAttr('required');
        $('#production_capacity_unit1').val('');
        $('#production_capacity_unit1').removeAttr('required');
    }
}

var edit_prod = $('#edit_pricemode').val();
if (edit_prod == 2) {
    $('#getpricedetails').hide();
    $('#currency').val('');
    $('#currency').removeAttr('required');
    $('#preferred_price').val('');
    $('#preferred_price').removeAttr('required');
    $('#preferred_priceto').val('');
    $('#preferred_priceto').removeAttr('required');
    $('#production_capacity_unit1').val('');
    $('#production_capacity_unit1').removeAttr('required');
}

function minquantity_select(val) {
    if (val == 1) {
        $('#selquantity_minorder').show();
        $('#min_order_qty').attr('required', 'required');
        $('#min_order_unit').attr('required', 'required');
    } else {
        $('#selquantity_minorder').hide();
        $('#min_order_qty').removeAttr('required', 'required');
        $('#min_order_unit').removeAttr('required', 'required');
    }
}

var edit_minquantity = $('#edit_minquantity').val();
if (edit_minquantity == -1) {
    $('#selquantity_minorder').hide();
    $('#min_order_qty').removeAttr('required', 'required');
    $('#min_order_unit').removeAttr('required', 'required');
}

$('.prod_payment').click(function () {
    var chck_pay = this.value;
    if (chck_pay == 'On Inquiry' || chck_pay == 'OnInquiry') {
        $('#payment_terms8').prop('checked', true);
        for (var i = 1; i <= 10; i++) {
            if (i != 8) {
                $('#payment_terms' + i).prop('checked', false);
            }
        }
    } else {
        $('#payment_terms8').prop('checked', false);
        for (var i = 1; i <= 9; i++) {
            if (i != 8 && i != 10) {
                var sel_chckbox = $(".prod_payment:checked").length;
                if (sel_chckbox == 8)
                    $('#payment_terms10').prop('checked', true);
            } else if (sel_chckbox == 0) {
                $('#payment_terms8').prop('checked', true);
            } else {
                $('#payment_terms10').prop('checked', false);
            }
        }
    }
});
$('#product_name').keyup(function () {
    $('#category_search').val($(this).val());
    var search_cate = $('#category_search').val();
    var search_catelen = search_cate.length;
    if (search_catelen > 2) {
        searchcategoryselect($('#category_search').val(), 'searchcatappend');
        $('.categoryshowview1').html('');
    } else {
        $('#category1').css({'display': 'none'});
    }
});
$('#category_search').keyup(function () {
    var search_cate = $('#category_search').val();
    var search_catelen = search_cate.length;
    if (search_catelen > 2) {
        searchcategoryselect($('#category_search').val(), 'searchcatappend');
        $('.categoryshowview1').html('');
    } else {
        $('#category1').css({'display': 'none'});
    }
});
$('#buyer_name').keyup(function () {
    $('#category_buy_search').val($(this).val());
    var search_cate = $('#category_buy_search').val();
    var search_catelen = search_cate.length;
    if (search_catelen > 2) {
        searchcategoryselect($('#category_buy_search').val(), 'searchcatappend');
        $('.categoryshowview1').html('');
    } else {
        $('#category1').css({'display': 'none'});
    }
});
$('#category_buy_search').keyup(function () {
    var search_cate = $('#category_buy_search').val();
    var search_catelen = search_cate.length;
    if (search_catelen > 2) {
        searchcategoryselect($('#category_buy_search').val(), 'searchcatappend');
        $('.categoryshowview1').html('');
    } else {
        $('#category1').css({'display': 'none'});
    }
});
$('#servicename').keyup(function () {
    $('#categoryserv_search').val($(this).val());
    var search_cate = $('#categoryserv_search').val();
    var search_catelen = search_cate.length;
    if (search_catelen > 2) {
        searchservicecategoryselect($('#categoryserv_search').val(), 'searchcatappend');
        $('.categoryshowview1').html('');
    } else {
        $('#category1').css({'display': 'none'});
    }
});
$('#categoryserv_search').keyup(function () {
    var search_cate = $('#categoryserv_search').val();
    var search_catelen = search_cate.length;
    if (search_catelen > 2) {
        searchservicecategoryselect($('#categoryserv_search').val(), 'searchcatappend');
        $('.categoryshowview1').html('');
    } else {
        $('#category1').css({'display': 'none'});
    }
});

function validate_pinteresturl($uri) {

    $.ajax({
        url: URL_PROFILE_PATH + 'checkpinterest',
        data: {pinurl: $uri},
        dataType: 'html',
        type: 'post',
        success: function (output) {
            if (output == 1) {
                $('#pinterest_errmsg').html('');
            } else {
                $('#pinterest_errmsg').html(output);
            }
//            $('#indiv_bus_type').html(output);
        }
    });
//    if (preg_match("/^(http|https):\\/\\/[a-z0-9_]+([\\-\\.]{1}[a-z_0-9]+)*\\.[_a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i", $uri)) {
//        $('#pinterest_errmsg').html('Invalid pinterest link');
//        console.log('asas');
//    } else {
//        $('#pinterest_errmsg').html('');
//        console.log('1212');
//    }
}

/* ************ basic flow supplier service select option div open and close scrip *****************/
//$('#mem_bustype_sel').click(function () {
//    $('#reload_selType').slideUp(400);
//    $('.small-select .small-optbox p').html('I am a Supplier / Buyer');
//    $('.serv-opt').removeClass('col-xs-12');
//});
//$('#mem_servtype_sel').click(function () {
//    $('#reload_selType').slideUp(400);
//    $('.small-select .small-optbox p').html('I am a Service Provider');
//    $('.serv-opt').addClass('col-xs-12');
//});
//$(document).ready(function () {
//    $('.small-optbox,.cant-edit').dblclick(function (e) {
//        e.preventDefault();
//    });
//});
$(".small-optbox").on("click", function () {
    $('#reload_selType').css('display', 'block');
});
$('.cant-edit').on("click", function () {
    $('#reload_selType').css('display', 'none');
//     $('#reload_selType').slideUp();
});
//var dbclick = false;
//$(".cant-edit").click(function () {
//    setTimeout(function () {
//        //singleclick functionality should start here.
//
//        if (dbclick == false) {
//            $('#reload_selType').hide();
//            $('#reload_selType').css('display', 'none');
//        }
//
//    }, 200);
//
//});
//$('').click(function () {

//    $('#reload_selType').css('display', 'none');
//    $('#reload_selType').css({'height': '100%', 'display': 'block'});
//     $('#reload_selType').animate({'height': '100%','display': 'block'}, "slow" );
//});

//$('.cant-edit').dblclick(function () {
//    $('#reload_selType').css('display', 'none');
//});
/*************** end ***************/

/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :   Forum , E-Comm scripts , Blog
 Description     :   Forum scripts, all ecomm related scripts and blog name edit scripts are in this file.
 Included        :   
 Last Modified   :   Aug 15,2017 / Arivarasi
 Assigned to     :   Daniel Sebastian
 */

////function handleClick(cb) {
//    var cat = $("#category option:selected").val();
//    var myarr = cat.split(",");
//    var main_id = myarr[0];
//    var sub_id = myarr[1];
//    var main_name = myarr[2];
//    var sub_name = myarr[3];
//    if (cb.checked)
//    {
//        $.ajax({
//            url: '/forum/pinpost.html',
//            data: {
//                main_id: main_id,
//                sub_id: sub_id,
//                main_name: main_n,
//                sub_name: sub_name
//            },
//            type: 'post',
//            dataType: 'text',
//            success: function (e) {
//                console.log(e);
//                if (e > 0)
//                {
//                    document.getElementById("pin_status").value = 0;
//                    document.getElementById("err_pin").style.color = "red";
//                    document.getElementById("err_pin").innerHTML = "Already You Pin This Category.";
//                }
//                else {
//                    document.getElementById("pin_status").value = 1;
//                    document.getElementById("err_pin").style.color = "";
//                    document.getElementById("err_pin").innerHTML = "";
//                }
//
//            }
//        });
//    }
//    else
//    {
//        document.getElementById("err_pin").innerHTML = "";
//        document.getElementById("pin_status").value = '';
//    }
//}
/////// pin post function /////
function handleClick(cb) {
    var cat = $("#forum_category option:selected").val();
    var myarr = cat.split(",");
    var main_id = myarr[0];
    var sub_id = myarr[1];
    var main_name = myarr[2];
    var sub_name = myarr[3];
    if (cb.checked)
    {
        if (cat == '')
        {
            document.getElementById("err_pin").innerHTML = "Please Select Category/Topic.";
            document.getElementById("err_pin").style.color = "red";
            $("#pin").prop('checked', false);
        } else
        {
            $.ajax({
                url: '/forum/pinpost.html',
                data: {
                    main_id: main_id,
                    sub_id: sub_id,
                    main_name: main_name,
                    sub_name: sub_name
                },
                type: 'post',
                dataType: 'text',
                success: function (e) {
                    var text = e;
                    var obj = JSON.parse(text);
                    console.log(obj.cnt_pin);
                    console.log(obj.cnt_pinall);
                    if (obj.cnt_pinall < 6)
                    {
                        if (obj.cnt_pin > 0)
                        {
                            document.getElementById("pin_status").value = 0;
                            document.getElementById("err_pin").style.color = "red";
                            document.getElementById("err_pin").innerHTML = "Already You Pin This Category.";
                        } else {
                            document.getElementById("pin_status").value = 1;
                            document.getElementById("err_pin").style.color = "";
                            document.getElementById("err_pin").innerHTML = "";
                        }
                    } else
                    {
                        document.getElementById("pin_status").value = 0;
                        document.getElementById("err_pin").style.color = "red";
                        document.getElementById("err_pin").innerHTML = "Already 5 Member Pin This Category.";
                    }

                }
            });
        }
    } else
    {
        document.getElementById("pin_status").value = 0;
    }
}
//// check pin only when category is selected// 
function removepin(){
    $("#pin").prop('checked', false);
    document.getElementById("err_pin").innerHTML = "";
    document.getElementById("pin_status").value = '';
}
//// to check entered email id already exist or not ///
function alreadyemail(email) {
    $.ajax({
        url: '/forum/getemail.html',
        data: {
            emailid: email
        },
        type: 'post',
        dataType: 'text',
        success: function (e) {
            var text = e;
            var obj = JSON.parse(text);
            if (obj.allemail)
            {
                document.getElementById("username").value = obj.allemail.name;
                document.getElementById("username").readOnly = true;
                document.getElementById("username").style.color = "#12a3df";
//          document.getElementById("al_email").innerHTML = "This is Existing Email.";
            } else {
                document.getElementById("username").value = '';
                document.getElementById("username").readOnly = false;
                document.getElementById("username").style.color = "";
            }

        }
    });
}
//// function used in edit forum ///
function editform(id){
    $.ajax({
        url: '/forum/editform.html',
        data: {
            id: id
        },
        type: 'post',
        dataType: 'html',
        success: function (e) {
            $('#editforumfrm1').html(e);
            $('#editdata1').modal('show');
        }
    });
}
//// function used in delete forum ///
function deleteform(id){
    var confirmuser = confirm('Are you sure you want to delete this Topic');
    if (confirmuser == false) {

    } else {
        console.log(id);
        $.ajax({
            url: '/forum/deleteform.html',
            data: {
                id: id
            },
            type: 'post',
            dataType: 'text',
            success: function (e) {
                var text = e;
                var obj = JSON.parse(text);
                if (obj.message) {
                    $('#success_div').html(obj.message).show();
                    setTimeout(function () {
                        location.reload();
                    }, 3000);
                } else {
                    $('#success_div').html('').hide();
                }
            }
        });
    }
}

function replyeditform(id)
{
    $('#p_id' + id).hide();
    $('#rep_div' + id).show();

}
var sanitize = function (name) {
    name = name.replace(/\s+/gi, '-'); // Replace white space with dash
    return name.replace(/[^a-zA-Z0-9\-]/gi, ''); // Strip any special character
};

/// image uploader in forum ///
var photo_counter = 0;
Dropzone.autoDiscover = false;
//var fileList = new Array;
var i = 1;
$("#dZUpload1").dropzone({
    url: "/uploadhandler/upload",
    parallelUploads: 1,
    maxFilesize: 2,
    addRemoveLinks: true,
    dictRemoveFile: 'Remove',
    dictFileTooBig: 'Image is bigger than 2MB',
    acceptedFiles: 'image/*',
    dictInvalidFileType: 'Upload Image Only',
    maxFiles: 1,
    // The setting up of the dropzone
    init: function () {
        /***
         * Retrive Old files
         */
        thisDropzone = this;
        $.getJSON('/uploadhandler/getuploadsinglefile', function (data) {
            var existingFileCount = data.length;
            console.log(existingFileCount);
            thisDropzone.options.maxFiles = thisDropzone.options.maxFiles - existingFileCount;
            console.log(thisDropzone.options.maxFiles);
            $.each(data, function (i, val) {
                var fileName = val.name.replace(/^.*[\\\/]/, '')
                fileList[i] = {'serverFileName': val.name, 'fileName': fileName, 'fileId': i};
                var mockFile = {name: fileName, size: val.size};
                thisDropzone.emit("addedfile", mockFile);
                thisDropzone.createThumbnailFromUrl(mockFile, URL_UPLOADS_PATH + '/' + val.name, null, true);
                thisDropzone.emit("complete", mockFile);
                thisDropzone.files.push(mockFile);
            });
        });
        this.on("sending", function (file, xhr, data) {
            console.log($('#module_name').val());
            data.append("module_name", $('#module_name').val());
        });
        /***
         * File Removal
         */
        this.on("removedfile", function (file) {
            var rmvFile = "";
            for (f = 0; f < fileList.length; f++) {
                if (fileList[f].fileName == file.name) {
                    rmvFile = fileList[f].serverFileName;
                }
            }

            if (rmvFile) {
                var modname = $('#module_name').val();
                $.ajax({
                    type: 'POST',
                    url: '/uploadhandler/singledelete',
                    data: {'fileList': rmvFile, module_name: modname},
                    dataType: 'html',
                    success: function (data) {
                        var rep = JSON.parse(data);
                        console.log(rep.code);
                        if (rep.code == 200)
                        {
                            console.log(fileList);
//                            photo_counter--;
                        }
                    }
                });
            }

        });
        /***
         * File Added
         */
        this.hiddenFileInput.removeAttribute('multiple');
        this.on("maxfilesexceeded", function (file) {
            this.removeAllFiles();
            this.addFile(file);
        });
        this.on('addedfile', function (file) {
            if (this.files.length > 1) {
                this.removeFile(this.files[0]);
            }

            if (this.files.length != 0) {
                if (!this.files[0].name.match(/\.(jpg|jpeg|png|gif)$/)) {
                    this.removeFile(this.files[0]);
                    console.log("Not an image");
                }
                var s = this.files[0].size / 1024 / 1024;
                if (parseFloat(s) > parseFloat(2))
                {
                    this.removeFile(this.files[0]);
                    console.log("Size is too long");
                }
            }
            var img = $(file.previewTemplate).find("img");
            img[0].onload = function () {
                var max = this.width > this.height ? this.width : this.height;
                var ratio = 100.0 / max;

                var width = this.width * ratio;
                var height = this.height * ratio;

                img.css({
                    width: width + "px",
                    height: height + "px",
                    top: ((100 - height) / 2) + "px",
                    left: ((100 - width) / 2) + "px"
                });
            };
        });
        this.accept = function (file, done) {
            // custom duplicate check
            if (this.files.length) {
                var _i, _len;
                var isDuplicate = false;
                for (_i = 0, _len = this.files.length - 1; _i < _len; _i++) {
                    if (this.files[_i].name === file.name || this.files[_i].name === sanitize(file.name)) {
                        isDuplicate = true;
                        this.removeFile(file);
//                            console.log("duplikat: " + file.name);
                        return false;
                    }
                }
            }

            // default dropzone checks
            if (file.size > this.options.maxFilesize * 1024 * 1024) {
                return done(this.options.dictFileTooBig.replace("{[{filesize}]}", Math.round(file.size / 1024 / 10.24) / 100).
                        replace("{[{maxFilesize}]}", this.options.maxFilesize));
            } else if (!Dropzone.isValidFile(file, this.options.acceptedFiles)) {
                return done(this.options.dictInvalidFileType);
            } else if ((this.options.maxFiles != null) && this.getAcceptedFiles().length >= this.options.maxFiles) {
                done(this.options.dictMaxFilesExceeded.replace("{[{maxFiles}]}", this.options.maxFiles));
                return this.emit("maxfilesexceeded", file);
            } else if (isDuplicate === true) {
                // output my error string for duplicates
                return done(this.options.dictDuplicate);
            } else {
                return this.options.accept.call(this, file, done);
            }
        }
        /***
         * On Upload Success
         */
        this.on("success", function (file, serverFileName) {
            fileList = {'serverFileName': serverFileName, 'fileName': file.name, 'fileId': i};
            console.log(fileList);
        });
    }
});
// form validation for number based enteries //
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;

    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
//-----------------------------------START OF ECOMM SCRIPTS -----------------------//
/// ecomm save button
function saveqty(id, design)
{
    var qty = document.getElementById('quantity' + id).value;
    var hid_del_err = document.getElementById('hid_del_err').value;
//    var hid_min_qty = document.getElementById('hid_min_qty').value;
//    console.log(qty);
//    if (qty <= hid_min_qty) {
//        qty = hid_min_qty;
//        var set=2;
//    }
    if (qty == 0) {
        qty = 1;
    }
//    if (qty > 5) {
//        qty = 5;
//        var set=1;
//    }
    var url = '/cart/saveqty';
    $.ajax({
        url: url,
        data: {
            id: id,
            qty: qty,
            hid_del_err: hid_del_err,
            design: design
        },
        type: 'get',
        dataType: 'html',
        success: function (e) {
            if (design == 1) {
                $('#cart_ajax').html(e);
//                if(set==1){
//                    $('#set_MaxQty').show();
//                    $('#set_MaxQty').html('We are sorry! We are able to accommodate only 5 units');
//                }else{
//                    $('#set_MaxQty').hide();
//                    $('#set_MaxQty').html('');
//                }
//                if(set==2){
//                $(".set_MinQty").fadeIn();
//                            setTimeout(function () {
//                                $(".set_MinQty").fadeOut();
//                            }, 3000);
//                    $('#set_MinQty').show();
//                    $('#set_MinQty').html('Quantity can not be less than MOQ (MOQ : '+hid_min_qty+')');
//                }else{
//                    $('#set_MinQty').hide();
//                    $('#set_MinQty').html('');
//                }
            } else if (design == 2) {
                orderdetail();
//                $('#order_summary').hide();
//                $('#order_detail1').html(e);
//                $('#order_detail1').show();
            } else {
                orderdetail();
            }
        }
    });
}
//---------- place order button -----//
function placeorderclick() {
    targetUrl = '?form=addform';
    window.history.pushState({url: "" + targetUrl + ""}, '', targetUrl);
    $('#formModel').modal('show');
}
//------- reduce quantiy --------//
function subtractQty(id) {
    if (document.getElementById("quantity" + id).value - 1 < 1)
        return;
    else
        document.getElementById("quantity" + id).value--;
    document.getElementById("savecartqty" + id).style.display = "inline";
}

function SetBilling(checked) {
//    var d= document.getElementById('ship_mob').value;
//    console.log(d+'=== hkhk');
    if (checked) {
        console.log(document.getElementById('bill_mob').value);
        document.getElementById('bill_mob').value = document.getElementById('ship_mob').value;
        document.getElementById('bill_address').value = document.getElementById('ship_address').value;
        document.getElementById('bill_landmark').value = document.getElementById('ship_landmark').value;
        document.getElementById('bill_pin').value = document.getElementById('ship_pin').value;
    } else {
        document.getElementById('bill_mob').value = '';
        document.getElementById('bill_address').value = '';
        document.getElementById('bill_landmark').value = '';
        document.getElementById('bill_pin').value = '';
    }
}
/// change address to delivery ///
function changeaddr(memid){
    var url = '/cart/alladdress';
    $.ajax({
        url: url,
        data: {
            memid: memid
        },
        type: 'post',
        dataType: 'html',
        success: function (e) {
            $('#all_address').hide();
            $('#all_addr').show();
            $('#all_addr').html(e);
        }
    });
}
// New address show function //
function newaddress(){
    $('#all_addr').hide();
    $('#all_address').hide();

    $('#new-address').show();
}
$(document).ready(function () {
    if ($('#aDDNEwAddR').length) {
        editaddress('add', '');
        $('.cart-close').hide();
    }
    if ($('#ordeRSummary').length) {
        orderdetail();
    }

});
//view details of cart - onclick function
function orderdetail() {
//    $('#order_summary').hide();
//    $('#order_detail').show();
    var req_edit_id1 = '';
    var req_edit_id = $('#req_edit_order').val();
    if (req_edit_id != '') {
        req_edit_id1 = req_edit_id;
    }
    var del_req_ids1 = '';
    var del_req_ids = $('#del_req_ids').val();
    if (del_req_ids != '') {
        del_req_ids1 = del_req_ids;
    }
    var url = '/cart/ordercart';
    $.ajax({
        url: url,
        data: {
            req_edit_id: req_edit_id1,
            del_req_ids: del_req_ids1
        },
        type: 'post',
        dataType: 'html',
        beforeSend: function () {
            $('.checkout-loader').show();
        },
        complete: function (e) {
            $('.checkout-loader').hide();
        },
        success: function (e) {
//            console.log(e);
            $('#order_summary').hide();
            $('#order_detail1').html(e);
            $('#order_detail1').show();
        }
    });
}
//// edit contact address //
function editaddress(type, id){
    var req_edit_id1 = '';
    var req_edit_id = $('#req_edit_id').val();
    if (req_edit_id == 1) {
        req_edit_id1 = '1';
    }
    var url = '/cart/editaddress';
    $.ajax({
        url: url,
        data: {
            id: id,
            type: type,
            req_edit_id: req_edit_id1
        },
        type: 'post',
        dataType: 'html',
        success: function (e) {
            if (type == 'add') {
                $('.invalidpin').hide();
            }
            $('#all_addr').hide();
            $('#all_address').hide();
            $('#new-address').hide();
            $('#edit-address').show();
            $('#edit-address').html(e);
            $('#delivery_address').parsley();
            $('html,body').animate({scrollTop: 0}, 200);
        }
    });
}
///// address to deliver ///
function deliveraddress(id){
//    console.log(id);
    var url = '/cart/deliveraddress';
    $.ajax({
        url: url,
        data: {
            id: id
        },
        type: 'post',
        dataType: 'html',
        success: function (e) {
            console.log(e);
            $('#all_addr').hide();
            $('#all_address').show();
            $('#all_address').html(e);
            location.reload();
//            var text = e;
//            var obj = JSON.parse(text);
//            if (obj.message) {
//                $('#success_div').html(obj.message).show();
//                setTimeout(function () {
////                        $('#all_addr').hide();
////                        $('#all_address').show();
//                    location.reload();
//                }, 3000);
//            } else {
//                $('#success_div').html('').hide();
//            }
        }
    });
}
/// delete address ///
function del_addr(id){
    var confirmuser = confirm('Are you sure you want to delete this address');
    if (confirmuser == false) {

    } else {
        $.ajax({
            url: '/cart/deleteaddr',
            data: {
                id: id
            },
            type: 'post',
            dataType: 'text',
            success: function (e) {
//                console.log(e);
                var text = e;
                var obj = JSON.parse(text);
                if (obj.message) {
                    $('#success_div').html(obj.message).show();
                    setTimeout(function () {
                        location.reload();
                    }, 3000);
                } else {
                    $('#success_div').html('').hide();
                }
            }
        });
    }
}
/// remove item frm cart ///
function removecartitem(id, orders_id){
    //e.preventDefault();
//    console.log(id);
    if (!confirm("Are you sure to remove this product?"))
        return;
    var url = '/cart/deletecart';
    $.ajax({
        url: url,
        data: {
            id: id,
            orders_id: orders_id
        },
        type: 'post',
        dataType: 'html',
        success: function (e) {
//            console.log(e);
            updateCartCount();
            $('#cart_ajax').html(e);
        }
    });
}
/// remove item order ///
function rmvcartorder(id, orders_id){
//    var del_req_ids1 = '';
//    var del_req_ids = $('#del_req_ids').val();
//    if (del_req_ids != '') {
//        del_req_ids1 = del_req_ids;
//    }
    if (!confirm("Are you sure to remove this product?"))
        return;
    var url = '/cart/removecartorder';
    var hid_del_err = document.getElementById('hid_del_err').value;
    $.ajax({
        url: url,
        data: {
            id: id,
            orders_id: orders_id,
            hid_del_err: hid_del_err
//            del_req_ids: del_req_ids1
        },
        type: 'post',
        dataType: 'html',
        success: function (e) {
            updateCartCount();
//            $('#order_detail1').html(e);
//            $('#order_detail1').show();
            orderdetail();
        }
    });
}
/// confirm order scritp ///
function confirmorder(){
    var grand_amt = $('#grand_tot').val();
    var grand_qty = $('#grand_qty').val();
    var grand_curr = $('#grand_curr').val();
    var grand_product = $('#grand_product').val();
    var mod_id = $('#mod_id').val();
//    console.log(grand_amt+'==grand_amt<br>');
//    console.log(grand_qty+'==grand_qty<br>');
//    console.log(grand_curr+'==grand_curr<br>');
    var url = '/cart/confirmorder';
    $.ajax({
        url: url,
        data: {
            mod_id: mod_id
        },
        type: 'get',
        dataType: 'html',
        success: function (e) {
//            console.log(e);
            if (e == 1)
            {
                $('#order_detail1').hide();
                $('#order_summary').show();
                $('#order_product_cnt').html(grand_product + ' Items');
                $('#order_tot_price').html('Total: ' + grand_curr + '. ' + grand_amt);
                $('#payment_wrap').hide();
                $('#payment_detail').show();
            }
        }
    });
}
//// close cart view ///
function cart_close() {
//    var date = new Date(),
//      month = date.getMonth();
//    var curr_year = date.getFullYear();
//    var curr_month = month < 10 ? "0" + (month+1) : month+1;
//    console.log(curr_month);
//    console.log(curr_year);
//    if(curr_month<=06 && curr_year<=2016)
//    {
//        $('#error_month').html('Expiration date is not correct.');
//        console.log('fafa');
//    }

    $('#all_addr').hide();
    $('#edit-address').hide();
    $('#all_address').show();
}
//// open payment wrap ////
function payment_open() {
    $('#payment_wrap').hide();
    $('#payment_detail').show();
}
///// combo offers ///
function comboaddcart(ids, offer_id, price){
    var price_variant = document.getElementById('defaultvariantspec').value;
//    var delivery_charge = document.getElementById('delivery_charge').value;
    var delivery_charge = "";
    var url = URL_MAIN_PATH + '/cart/comboaddcart';
    $.ajax({
        url: url,
        data: {
            ids: ids,
            offer_id: offer_id,
            price: price,
//            hid_variant: price_variant,
            delivery_charge: delivery_charge
        },
        crossDomain: true,
        type: 'get',
        dataType: 'jsonp',
        beforeSend: function () {
            $('.cart-preloader').show();
        },
        complete: function (e) {
            $('.cart-preloader').hide();
        },
        success: function (e) {
//            console.log(e);
            updateCartCount();
            $(".cart-fixed").fadeIn();
            setTimeout(function () {
                $(".cart-fixed").fadeOut();
            }, 5000);
            $('.cart-fixed').html(e);
            $("#cart_combo").html('<span>Added to cart</span>');
            $('#load_cart').load(location.href + ' #load_cart');
        }
    });
}

//function use_ship(cb)
//{
//    if(cb.checked)
//    {
//        var url = '/cart/useshipaddress';
//        $.ajax({
//            url: url,
//
//            type: 'get',
//            dataType: 'html',
//            success: function (e) {
////                console.log(e);
//            }
//        });
//    }
//}
 // add product to wishlist ///
function addtowishlist(pro_id){
//    console.log(pro_id);
    var url = URL_PRODUCTS_PATH + '/addtowishlist.php';
    $.ajax({
        url: url,
        dataType: 'JSONP',
        data: {
            pro_id: pro_id,
        },
        type: 'POST',
        success: function (e) {
            console.log(e);
            if (e[0] == 1) {
                $('#succ_wish_list').html('Added to your Wishlist.!');
                $('#succ_wish_list').addClass('wish_slide');
                $('.prod-fav-btn').addClass('wish-i');
                $('#wisicon_' + pro_id).addClass('wish-i');
                setTimeout(function () {
                    $("#succ_wish_list").removeClass('wish_slide');
                }, 5000);
            } else if (e[0] == 0) {
                $('#succ_wish_list').html('Removed from your Wishlist.!');
                $('#succ_wish_list').addClass('wish_slide');
                $('.prod-fav-btn').removeClass('wish-i');
                $('#wisicon_' + pro_id).removeClass('wish-i');
                setTimeout(function () {
                    $("#succ_wish_list").removeClass('wish_slide');
                }, 5000);
            } else {
                $('#succ_wish_list').html('').hide();
            }
        }
    });
}
/// add to cart wishlist //
function addcartwishlist(cart_id, pro_id, del_price, designid){
//    console.log(cart_id);
//    console.log(pro_id);
//    console.log(del_price);
//    var designid = typeof designid !== 'undefined' ? designid : 0;
//    console.log(designid);
    var url = '/addcartwishlist';

    $.ajax({
        url: url,
        data: {
            cart_id: cart_id,
            pro_id: pro_id,
            del_price: del_price
        },
        type: 'get',
        success: function (e) {
//            console.log(e);
            if (e == 1 && designid == 0) {
//                $('#cart_ajax').load(location.href + ' #cart_ajax');
                $('#rmv_wishlist').load(location.href + ' #rmv_wishlist');
                $('#succ_wish_list').html('Added to your Wishlist!.');
                $('#succ_wish_list').addClass('wish_slide');
                setTimeout(function () {
                    $("#succ_wish_list").removeClass('wish_slide');
                }, 5000);
                $('#load_cart').load(location.href + ' #load_cart');
            }
            if (e == 1 && designid == 1) {
                orderdetail();
            }
        }
    });
}
/****************Start of Blog Scripts ********************/
/// to change blog name
function changeblogname(memid, urlnew) {
    var cont = $('#blog_newtitle').val();
    $.ajax({
        url: urlnew,
        data: {
            memid: memid,
            content: cont
        },
        type: 'get',
        success: function (e) {
            $('#blog_newtitle').val(cont);
            $('#blog_update').hide();
            $('#blog_changed').show();
            setTimeout(function () {
                $("#blog_changed").hide();
                window.location.href = URL_PROFILE_PATH + 'blog/post-blog.html';
            }, 2000);
        }
    });
}
//// edit name///
function nameshowhide() {
    $('#blog_newtitle').removeAttr('readonly');
    $('#blog_newtitle').focus();
    $('#blog_edit').hide();
    $('#blog_update').show();
}
/****************End of Blog Scripts ********************/
/****************Start of Ecomm Scripts ********************/
function wishlistlogin(prod_id){
    $.ajax({
        url: '/wishlistlogin',
        data: {
            prod_id: prod_id,
        },
        type: 'get',
        success: function (e) {
            console.log(e);

        }
    });
}
/// detail page buynow button //
function buynowlogin(){
    var price_val = document.getElementById('ecompriceinp').value;
    var price_variant = document.getElementById('defaultvariantspec').value;
    var delivery_charge = document.getElementById('delivery_charge').value;
    var provider = document.getElementById('hid_provider').value;
//    var delivery_charge = document.getElementById('delivery_charge').value;
    $('#proprice').attr('value', price_val);
    $('#provariant').attr('value', price_variant);
    $('#prodelivery').attr('value', delivery_charge);
    $('#provider').attr('value', provider);
}

function buynow(pro_id, mem_id)
{
//    var url = URL_MAIN_PATH+'/cart/buynow';
    var price_val = document.getElementById('ecompriceinp').value;
    var price_variant = document.getElementById('defaultvariantspec').value;
    var delivery_charge = document.getElementById('delivery_charge').value;
//    console.log(pro_id);
//    console.log(mem_id);

//    $.ajax({
//        type: 'get',
//        url: url,
//        dataType: 'jsonp',
//        crossDomain: true,
//        data: {
//            id: pro_id,
//            hid_amt: price_val,
//            hid_variant: price_variant,
//            delivery_charge: delivery_charge
//        },
//
//        success: function (e) {
//            console.log(e);
////            updateCartCount();
//        }
//    });
}
// remove form wishlist///
function removewishlist(id)
{
    if (!confirm("Are you sure to remove this product?"))
        return;
    var url = URL_PROFILE_PATH + 'wishlist/removeid';
    $.ajax({
        url: url,
        data: {id: id},
        type: 'get',
        dataType: 'html',
        success: function (e) {
            location.reload();
//            $('#wish-reload').load(location.href + ' #wish-reload');
//            $('#remove_msg').html('Your wishlist has been successfully deleted.');
//            $('#remove_msg').delay(2000).show(100);
//            setTimeout(function () {
//                $('#remove_msg').hide();
//                location.reload();
//            }, 5000);
        }
    });
}

function uncheckedAll() {
    document.getElementById("checkall")
            .checked = false;
}
/// cart checkbox-- check all //
function checkall(e) {
    //  console.log('agaga');
    console.log(e);
    if (e.checked) { // check select status
        $('.cart_checkbox1')
                .each(function () { //loop through each checkbox
                    this.checked = true; //select all checkboxes with class "cart_checkbox1"
                });
    } else {
        $('.cart_checkbox1')
                .each(function () { //loop through each checkbox
                    this.checked = false; //deselect all checkboxes with class "cart_checkbox1"
                });
    }
}

function remSelected() {
    if ($('#selectaaaall')
            .is(':checked')) {
        $("#selectaaaall")
                .attr("checked", false);
    }
//    var selected = new Array();
//    $(".cart_checkbox1:checked").each(function () {
//        selected.push($(this).val());
//    });
//    console.log(selected);
//    var url = '/checkboxcart';
//    $.ajax({
//        url: url,
//        data: {id: selected},
//        type: 'get',
//        dataType: 'html',
//        success: function (e) {
//            console.log(e);
//        }
//    });
}
/// proceed to payment ///
function singleorder(id, price, curr, items){
//    console.log(price);
//    console.log(items);
    var mod_id = $('#mod_id').val();
    var req_edit_id1 = '';
    var req_edit_id = $('#req_edit_order').val();
    if (req_edit_id != '') {
        req_edit_id1 = req_edit_id;
    }
    var del_req_ids1 = '';
    var del_req_ids = $('#del_req_ids').val();
    if (del_req_ids != '') {
        del_req_ids1 = del_req_ids;
    }
//    console.log(price);
//    if(price>=1000000){
//        console.log('greater amount');
//    }
//    console.log(URL_MAIN_PATH + '/checkout');
    var url = '/single-confirmorder';
    $.ajax({
        url: url,
        data: {
            pro_id: id,
            grand_tot: price,
            grand_curr: curr,
            grand_qty_product: items,
            mod_id: mod_id,
            req_edit_id: req_edit_id1,
            del_req_ids: del_req_ids1
        },
        type: 'post',
        dataType: 'html',
        success: function (e) {
            console.log(e);
            if (e == 1) {
                console.log(e);
                window.location.href = URL_MAIN_PATH + '/checkout';
            }
        }
    });
}
//$("#delivery_reuest").on('submit', function (e) {
//    e.preventDefault();
//    var form = $(this);
//    form.parsley().validate();
//    if (form.parsley().isValid()) {
//        confirmRequest();
//    }
//});
//
//function confirmRequest() {
//    console.log('hahahahahahahahah');
//    var formdata = $('#delivery_reuest').serialize();
//    $.ajax({
//        url: URL_PRODUCTS_PATH + '/reuest-login-post',
//        type: 'post',
//        data: formdata,
//        success: function (e) {
//            console.log(e);
////            $('#reqmessage').css('display', 'block');
////            $('#reqmessage').html('Delivery request confirmed.!');
////            setTimeout(function () {
////                $('#reqmessage').css('display', 'none');
////            }, 3000);
//        }
//    });
//}
//Request Supplier for Delivery charge///
function setcarthidden(){
    var price_val = document.getElementById('ecompriceinp').value;
    var price_variant = document.getElementById('defaultvariantspec').value;
    var ship_json = document.getElementById('shippingdetailsjson').value;
//    var delivery_charge = document.getElementById('delivery_charge').value;
//    var provider = document.getElementById('hid_provider').value;

    $('#req_price').attr('value', price_val);
    $('#req_variant').attr('value', price_variant);
    $('#req_ship_json').attr('value', ship_json);
//    $('#req_del_chrg').attr('value', delivery_charge);
//    $('#req_provider').attr('value', provider);

}
//
//var ctrlKeyDown = false;
//
//$(document).ready(function () {
//    if ($('#chkOUTREfresh').length) {
//        $(document).on("keydown", keydown);
//        $(document).on("keyup", keyup);
//    }
//});
//
//function keydown(e) {
//
//    if ((e.which || e.keyCode) == 116 || ((e.which || e.keyCode) == 82 && ctrlKeyDown)) {
//        // Pressing F5 or Ctrl+R
//        e.preventDefault();
//    } else if ((e.which || e.keyCode) == 17) {
//        // Pressing  only Ctrl
//        ctrlKeyDown = true;
//    }
//}
//;
//
//function keyup(e) {
//    // Key up Ctrl
//    if ((e.which || e.keyCode) == 17)
//        ctrlKeyDown = false;
//}
/*
Project Title   :   Bizbilla
Version         :   3.0
Title           :   webtemplates
Description     :   Profile and admin header, template customisation
Included        :   -
Last Modified   :   Aug 14,2017 / Sivagami
Assigned to     :   Manobalan
*/
//****header cart view(hidded)****
function cart_fixed_close() {
    $('.cart-fixed').fadeOut();
}
//*****profile and admin search in header*****
$(function () {
    $('.serch-menu-form').submit(function () {
        $('.navbar-collapse.collapse').removeClass('in');
    });
    $(".search-icon").click(function () {
        $('.serch-menu-form').slideToggle();
    });
    $(".search-menu-list .dropdown .dropdown-toggle").mouseenter(function () {
        $(".search-menu-list .dropdown .dropdown-toggle").parent().removeClass("open");
        $(this).parent().addClass("open");
    });
    $(".search-menu-list .dropdown .dropdown-toggle").mouseleave(function () {
        $(".search-menu-list .dropdown .dropdown-toggle").parent().removeClass("open");
        $(this).parent().removeClass("open");
    });
    $(".search-menu-list .dropdown-menu").hover(function () {
        $(".search-menu-list .dropdown-menu").parent().removeClass("open");
        $(this).parent().addClass("open");
    });
    $(".search-menu-list .dropdown-menu").mouseleave(function () {
        $(".search-menu-list .dropdown .dropdown-toggle").parent().removeClass("open");
    });

});
//****owl listing image in core module detail page****
$(document).ready(function () {

    $(".detpro").click(function () {
        var mainImage = $(this).attr("src"); // Find Image URL
        var imgLink = $(this).children('img').attr('rel'); // Find the image link in rel
        var imgTitle = $(this).attr('title');
        $("#det_view").html('<img id="zoom_01" src="' + mainImage + '" class="galleryThumb img-responsive" title="' + imgTitle + '" alt="' + imgTitle + '" />');

    });
});

//******contact details for template(hidded)*****
function websitecontact() {
    console.log("fga");
    var name = $('#txtname').val();
    var email = $('#txtemail').val();
    var phone = $('#txtphone').val();
    var message = $('#txtmsg').val();
    var tmpmemberid = $('#tmpmemberid').val();
    $.ajax({
        url: '/websitecontact',
        type: 'post',
        data: {
            name: name,
            txtemail: email,
            phone: phone,
            message: message,
            tmpmemberid: tmpmemberid

        }, success: function (e) {
            $('#websignupform').html(e);
            $('#testM').modal();
        }
    });
}
//***template theme color change****
function themechnage(tempid, memberid, themeid) {

    $.ajax({
        url: '/websitetheme',
        data: {
            templateid: tempid,
            memberid: memberid,
            themenum: themeid
        },
        type: 'post',
        success: function (e) {
//            console.log(e);
//          $('#customstyle').html('<style>'+e+'</style>');
            $('#customstyle').html('<link rel="stylesheet" href="' + e + '" type="text/css" />');
            location.reload();
        }
    })
}

/***for select free or premium templates
 * 
 */
//function selecttempval(valid) {
//    $.ajax({
//        url: URL_API_BASE_PATH + '/get_selected_template',
//        data: {
//            tempid: valid,
//        },
//        type: 'post',
//        success: function (e) {
////            console.log(e);
//            location.reload();
//        }
//    })
//}

/**template page share **/

$(document).ready(function () {
    $("#pagesharetemplate").jsSocials({
        showLabel: false,
        showCount: false,
        shareIn: "popup",
        shares: ["twitter", "facebook", "googleplus", "linkedin"]
    });

});


<!DOCTYPE html >

<head>
        <title>User Profile Dashboard | Bizbilla.com</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=0"/>
    <meta name="keywords" content="User Bizbilla control panel, b2b e-commerce dashboard, Bizbilla member admin panel"/>
    <meta name="description" content="User CMS profile dashboard in Bizbilla.com for manage and update profile details."/>
    <link rel="shortcut icon" type="image/png" href="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/img/favicon.png"/>
    <link rel="canonical" href="../../../www.bizbilla.com/default.htm" />
    <link rel="publisher" href="../../../https@plus.google.com/+BizbillaB2B/default.htm"/>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="User Profile Dashboard | Bizbilla.com" />
    <meta property="og:description" content="User CMS profile dashboard in Bizbilla.com for manage and update profile details." />
    <meta property="og:url" content="http://www.bizbilla.com" />
    <meta property="og:image" content="" />
    <meta property="og:site_name" content="Bizbilla" />
    <meta property="fb:app_id" content="205513886291314" />
    <meta property="article:publisher" content="https://www.facebook.com/bizbilla/" />
    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:description" content="User CMS profile dashboard in Bizbilla.com for manage and update profile details."/>
    <meta name="twitter:title" content="User Profile Dashboard | Bizbilla.com"/>
    <meta name="twitter:site" content="@BizbillaB2B"/>
    <meta name="twitter:domain" content="Bizbilla"/>
    <meta name="twitter:url" content="http://www.bizbilla.com"/>
    <meta name="twitter:image" content=""/>
    <meta name="twitter:image:alt" content="User Profile Dashboard | Bizbilla.com"/>
    <meta name="google-site-verification" content="zGDXXcxgmpFNxysfm87reQvlmRfd_13FjpmR5oUF5yA" />
        <link rel="stylesheet" href="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/css/cssvendor.css@v=1507295303"/>
            <link rel="stylesheet" href="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/css/app.css@v=1510659030"/>
                    <link rel="stylesheet" href="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/css/customstyle.css@v=1510659030"/>
                <link rel="stylesheet" href="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/css/staticpromo.css@v=1510650289"/>
        <style>#oaremuoif,#aufimreoo,#uorefamoi,#aomfiuoer,#ofieuamro,#oareimfuo{visibility: hidden;width:1px;height:1px;}</style>            <!--ipt type="text/javascript">
            _atrk_opts = {atrk_acct: "YoD2q1Y1Mn20Io", domain: "bizbilla.com", dynamic: !0}, function () {
                var t = document.createElement("script");
                t.type = "text/javascript", t.async = !0, t.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js";
                var e = document.getElementsByTagName("script")[0];
                e.parentNode.insertBefore(t, e)
            }();
        </scri-->
    <noscript><img src="../../../https@d5nxst8fruw4z.cloudfront.net/atrk.gif@account=YoD2q1Y1Mn20Io" style="display:none" height="1" width="1" alt="bizbilla" /></noscript>
</head>
<body>
            <script>
            !function (e, t, a, n, c, o, s) {
                e.GoogleAnalyticsObject = c, e[c] = e[c] || function () {
                    (e[c].q = e[c].q || []).push(arguments)
                }, e[c].l = 1 * new Date, o = t.createElement(a), s = t.getElementsByTagName(a)[0], o.async = 1, o.src = n, s.parentNode.insertBefore(o, s)
            }(window, document, "script", "../../../https@www.google-analytics.com/analytics.js", "ga"), ga("create", "UA-101490387-1", "auto");
                    ga('set', 'user_email', 'info@tech-consult.in');
                ga('send', 'pageview');
        </script>
                <script>
        var URL_MAIN_PATH = '../..';
        var URL_UPLOADS_PATH = '../../../https@uploads-3scb1afwjgwax1popi.stackpathdns.com';
        var URL_B2B_PATH = '../../../https@b2b.classifieds.bizbilla.com';
        var URL_BSCLASSIFIEDS_PATH = '../../../https@business.classifieds.bizbilla.com';
        var URL_BLOGPATH = '../../../https@blog.bizbilla.com';
        var URL_B2BCLASSIFIEDS_PATH = '../../../https@b2b.classifieds.bizbilla.com';
        var URL_PRODUCTS_PATH = '../../../https@products.bizbilla.com';
        var URL_SELLOFFERS_PATH = '../../../https@selloffers.bizbilla.com';
        var URL_BUYINGNEED_PATH = '../../../https@buyingneeds.bizbilla.com';
        var URL_PARTNERS_PATH = '../../../https@partners.bizbilla.com';
        var URL_LOGIN_PATH = '../../../https@login.bizbilla.com';
        var APP_HTTP_SCHEME = 'https';
        var URL_PROFILE_PATH = '../';
        var URL_CDN_PATH = '../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com';
        var URL_TRADESHOW_PATH = '../../../https@tradeshows.bizbilla.com';
        var URL_CITY_PATH = '../../../https@city.bizbilla.com';
//            var URL_SERVICES_PATH = '../../../https@city.bizbilla.com';
        var URL_API_BASE_PATH = '../../api/v1';
        var URL_API_BIZ_SEARCH_PATH = '../../biz-search-api';
        var MEMBER_ID = "292846";
        var bannerurl = "www.bizbilla.com/profile/addons/upgrade-membership.php";
        var MEMBER_COUNTRY = "in";
        var __pageId = "";
        var __moduleId = "";
        var ConvertTimeZone = "11,16,2017";
            MEMSELECTCITY = 0;
            SERVICECITY = 0;
            SERVICECITIES = '';
    </script>
        <header class="main-header">
        <button id="showLeftPush" class="menu-icon" style="display:none;"><i class="fa fa-bars"></i></button>
        <div class="biz-logo logo">
        <a href="../../default.htm">
          <img src="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/img/site/bizbilla-logo.png" alt="World's Largest B2B Ecommerce Marketplace" title="World's Largest B2B Ecommerce Marketplace" class="img-responsive"/>
        </a>
    </div>
    <div class="profile-search-div">
                        <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-lg-6 col-lg-offset-3">
            <form action="https://www.bizbilla.com/search" method="GET" data-parsley-validate="" class="navbar-form  serch-menu-form">
                <div class="input-group">
                    <input name="q" id="headqsearch" autocomplete="off" type="text" required="" data-parsley-required-message="Enter search keyword" data-parsley-minlength="3" class="form-control typeahead" placeholder="What are you looking for...">
                    <input type="hidden" name="view" value="1">
                    <input type="hidden" name="type" value="supplier">
                    <span class="input-group-btn">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </span>
                </div>
            </form>
        </div>
        <button class="profile-search-close"><i class="fa fa-close"></i></button>
    </div>
    <nav class="navbar navbar-static-top">
        <div class="navbar-right search-menu">
            <div class="cart-fixed"></div>
            <div class="col-xs-12">
                                <ul class="search-menu-list">
                                        
<li class="dropdown profile hidden-xs hidden-sm">
    <a  title="techconsult" class="dropdown-toggle" ><i class="fa fa-user"><span class=" label-success"><i class="fa fa-angle-down"></i></span></i></a>
    <ul class="dropdown-menu">
        <div class="col-xs-12 profil-img">
                        <div class="col-xs-4 ">
                <div class=" user-img">
                    <img src="../../../https@uploads-3scb1afwjgwax1popi.stackpathdns.com/member-profile/2017/10/30_292846images-1-jpg.jpeg" alt="" class="img-circle">
                </div>
            </div>
            <div class="col-xs-8 user-email">
                <h6><b>techconsult</b></h6>
                <p>info@tech-consult.in</p>
            </div>
        </div>
        <div class="col-xs-12 profil-log">
            <li class="col-xs-6 p-r-0">
                <a href="../../profile" title="Profile" class="btn  active"><i class="fa fa-user"></i>Dashboard</a>
            </li>
            <li class="col-xs-6">
                <a href="../../../https@login.bizbilla.com/logout@return=www.bizbilla.com_2Fprofile_2Faddons_2Fupgrade-membership.php" title="Logout" class="ripple-effect btn "><i class="fa fa-power-off"></i>Logout</a>
            </li>
        </div>
    </ul>
</li>
<li class="mb-drop hidden-lg hidden-md">
    <a  href="../../profile" aria-expanded="false" title="My Profile" class="dropdown-toggle" data-toggle="dropdown">
        <i class="fa fa-ellipsis-v " ></i>
    </a>
    <ul class="dropdown-menu">
        <li><a href="../../profile" title="Profile" class="ripple-effect" ><i class="fa fa-user"></i>Dashboard</a></li>
        <li><a href="../../../https@login.bizbilla.com/logout" title="Logout" class="ripple-effect"><i class="fa fa-power-off"></i>Logout</a></li>
    </ul>
</li>                    <button class="profile-search-icon"><i class="fa fa-search"></i></button>
                </ul>
            </div>
        </div>
    </nav>
</header><div class="container-fluid">
    <div class="row">
        <div class="profile-secnd-wrap col-xs-12">
            <div class="slide-out col-sm-4 col-md-3">
    <div class="row m-0 prof-left-menuwrap">
                <div class="profile-pic">
            <div class="profile-pic-box">
                <div class="profile-user-img">
                    <button  type="button" class="avatar-preview avatar-preview-128" data-toggle="modal" data-target="#basicModal" >
                        <img src="../../../https@uploads-3scb1afwjgwax1popi.stackpathdns.com/member-profile/2017/10/30_292846images-1-jpg.jpeg" class="img-responsive" alt="" title=""/>
                        <span class="update">
                            <i class="fa fa-photo"></i>
                            Upload photo
                        </span>
                    </button>
                    <input type="file" id="profile-img" style="display:none"/>
                </div>
                <div class="memberprof-data">
                    <div class="member-data">
                        <h3 class="mem-name">Techconsult</h3>
                        <!--<h6 class="membership">Supplier/Buyer</h6>-->
                                                    <h6 class="membership">Last login : <span>16 Nov 2017 12:52</span></h6>
                                                                            <h6 class="membership">IP: <span>27.5.7.99</span></h6>
                                            </div>
                </div>
            </div>
        </div>
        <div class="slide-out-widgets">
                                                <ul class="menu-list profile-accordion" id="profile-accordion">
                <li class=""><a href="../default.htm" class=" pdd "><i class="fa fa-home" aria-hidden="true"></i>Dashboard</a></li>
                <li><a href="../messages" class="pdd "><i class="fa fa-envelope " aria-hidden="true"></i>Messages <p class="badge">3</p></a></li>
                                                    <li><a href="../add-company-profile.html" class="pdd  "><i class="fa fa-user" aria-hidden="true"></i>Company Profile</a></li>
                                                                                                <li>
                    <a class="link pdd" href="../../create-website/domain" target="_blank"><i class="fa fa-globe" aria-hidden="true"></i><p>My Website</p></a>
                    <!--                    <ul class="profile-submenu">
                                            <li><a href="" target="_blank"><i class="fa fa-circle-thin"></i><p>Preview</p></a></li>
                                            <li><a href="" target="_blank"><i class="fa fa-circle-thin"></i><p>Customize</p></a></li>
                                        </ul>-->
                </li>
                                                                        <li>
                        <a href="../products/add" class=" pdd  "><i class="fa fa-cart-plus" aria-hidden="true"></i>Products</a>
                                            </li>
                                                            <li>
                        <a href="../buyingneeds/add" class="pdd  "><i class="fa fa-shopping-bag" aria-hidden="true"></i>Buyer Requirements</a>
                                            </li>
                    
                <li>
                    <a href="../settings/change-password.html" class="pdd "><i class="fa fa-cogs" aria-hidden="true"></i>Settings</a>
                                    </li>
                                                        <li><a class="link pdd active" href="upgrade-membership.php"><i class="fa fa-user-plus" aria-hidden="true"></i><p>Upgrade Membership</p></a></li>
                                        <li class=""><a href="../receipts" class="pdd "><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Receipts</a></li>
                                    <li class=""><a target="_blank" href="../../Advertise-with-us.php" class=" pdd "><i class="fa fa-bullhorn" aria-hidden="true"></i>  Advertise with us</a></li>
            </ul>
        </div>

    </div>

    </div>

<div class="modal fade pf-imgmodel" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true" >
    <div class="modal-dialog modal-lg">
        <div class="modal-content change-prof-img" style="margin-top:50px">
            <div class="panel panel-danger">
                <div class="modal-header">
                    <div class="panel-heading prof-title">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"  ><i class="fa fa-close"></i></button>
                        <center><h4 class="modal-title " id="myModalLabel">Choose Your Profile Image</h4></center>
                    </div>
                </div>
                <div class="panel-body">
                    <style>
                        /* jquery.Jcrop.min.css v0.9.10 (build:20120429) */
                        .jcrop-holder{direction:ltr;text-align:left;}
                        .jcrop-vline,.jcrop-hline{background:#FFF url(Jcrop.gif) top left repeat;font-size:0;position:absolute;}
                        .jcrop-vline{height:100%;width:1px!important;}
                        .jcrop-hline{height:1px!important;width:100%;}
                        .jcrop-vline.right{right:0;}
                        .jcrop-hline.bottom{bottom:0;}
                        .jcrop-handle{background-color:#333;border:1px #eee solid;font-size:1px;}
                        .jcrop-tracker{-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none;-webkit-user-select:none;height:100%;width:100%;}
                        .jcrop-handle.ord-n{left:50%;margin-left:-4px;margin-top:-4px;top:0;}
                        .jcrop-handle.ord-s{bottom:0;left:50%;margin-bottom:-4px;margin-left:-4px;}
                        .jcrop-handle.ord-e{margin-right:-4px;margin-top:-4px;right:0;top:50%;}
                        .jcrop-handle.ord-w{left:0;margin-left:-4px;margin-top:-4px;top:50%;}
                        .jcrop-handle.ord-nw{left:0;margin-left:-4px;margin-top:-4px;top:0;}
                        .jcrop-handle.ord-ne{margin-right:-4px;margin-top:-4px;right:0;top:0;}
                        .jcrop-handle.ord-se{bottom:0;margin-bottom:-4px;margin-right:-4px;right:0;}
                        .jcrop-handle.ord-sw{bottom:0;left:0;margin-bottom:-4px;margin-left:-4px;}
                        .jcrop-dragbar.ord-n,.jcrop-dragbar.ord-s{height:7px;width:100%;}
                        .jcrop-dragbar.ord-e,.jcrop-dragbar.ord-w{height:100%;width:7px;}
                        .jcrop-dragbar.ord-n{margin-top:-4px;}
                        .jcrop-dragbar.ord-s{bottom:0;margin-bottom:-4px;}
                        .jcrop-dragbar.ord-e{margin-right:-4px;right:0;}
                        .jcrop-dragbar.ord-w{margin-left:-4px;}
                        .jcrop-light .jcrop-vline,.jcrop-light .jcrop-hline{background:#FFF;filter:Alpha(opacity=70)!important;opacity:.70!important;}
                        .jcrop-light .jcrop-handle{-moz-border-radius:3px;-webkit-border-radius:3px;background-color:#000;border-color:#FFF;border-radius:3px;}
                        .jcrop-dark .jcrop-vline,.jcrop-dark .jcrop-hline{background:#000;filter:Alpha(opacity=70)!important;opacity:.7!important;}
                        .jcrop-dark .jcrop-handle{-moz-border-radius:3px;-webkit-border-radius:3px;background-color:#FFF;border-color:#000;border-radius:3px;}
                        .jcrop-holder img,img.jcrop-preview{max-width:none;}

                    </style>
                    <div class="col-xs-12">
                        <div id="profile_pic" style="display: none;">
                            <img src="" id="thumb" style="display: none;"/>
                        </div>
                        <form id="upload_form" enctype="multipart/form-data" method="post" action="https://www.bizbilla.com/profile/uploadprofileimage" name="f1" >
                            <input type="hidden" id="w" name="w" />
                            <input type="hidden" id="h" name="h" />
                            <input type="hidden" id="x1" name="x1" />
                            <input type="hidden" id="y1" name="y1" />
                            <input type="hidden" id="x2" name="x2" />
                            <input type="hidden" id="y2" name="y2" />
                                                        <div class="file_field" >
                                <div><strong style="" align="center">Select an Image: </strong>
                                    <button type="button" name="image_fille" id="image_fille" style=""  onclick="changeFile()" class="btn pf-bt">Choose File</button>
                                    <input type="file" style="width:82px;margin-left: 20px;height: 22px;display: none;" id="image_file" name="image_file" class="validate[required]" onclick="" onchange="validate1()"/>
                                    <input type="submit" formaction="action/defimage_action.php" style="display:none;" id="def_submit"/>
                                </div>
                                <div class="checkfile-size">Maximum file size : 1 MB. Supporting image formats : (Only .jpg, .jpeg, .png)</div>
                            </div>
                            <div id="crop_img" class="hide up-prof-img">
                                First Crop the image and upload.
                                <input type="submit" value="Upload" id="button_upload" class="btn pf-bt"/>
                            </div>
                            <br/>
                            <div class="error1" style="display: none;"></div>
                            <div class="def_image" style="display: none;text-align: center;">
                            </div>
                            <div class="clear" style="height:0.5em"></div>
                            <div id="image_div" style="display:none;">
                                <img src="" id="load_img" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>            <div class="secondry-profile-content col-xs-12 col-sm-12 col-md-9">
                <!--<div class="profile-secondry-ban2 col-xs-12">
    <div class="col-lg-12 profile-head">
        <h1 class="page-title">B2B Premium Membership</h1>
    </div>
</div>-->
<!--<div class="profile-secondry-ban2 col-xs-12">
    <div class="col-lg-12 profile-head">
        <h1 class="page-title">B2B Premium Membership</h1>
    </div>
</div>-->
<div class="profile-secondry-ban2 col-xs-12">
    <div class="col-lg-offset-2 col-lg-7 col-md-offset-1 col-md-8 col-sm-10 col-sm-offset-1 profile-head">
        <h1 class="page-title">Upgrade Membership</h1>
    </div>
</div>
<div class="col-xs-12 m-t-20">
    <div class="row tab-head ">
        
    </div>
    <div class="back upgrade-mem">

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <!--<p style="text-align: justify; letter-spacing: .5px;">(Your payment receipt will comprise the following details)</p>-->
                
            <form name="memberdetails_form" id="memberdetails_form"  data-parsley-validate="" >
                <div class="col-xs-12 p-0">
                    <div class="row">
                                                                        <div class="col-lg-offset-2 col-lg-7 col-md-offset-1 col-md-8 col-sm-10 col-sm-offset-1">
                            <div class="upgrade-right">
                                <div class="col-xs-12 m-t-10">
                                    <div class="member-details">
                                        <h3 class="upgrd-right-heading">Bill To</h3>
                                        <div class="member-details-info">
                                            <p>tech consult</p>
                                            <p>mumbai</p>
                                            <p>Mumbai, Maharashtra, India - 400001</p>
                                            <p><span><i class="fa fa-envelope-o" aria-hidden="true"></i></span> info@tech-consult.in</p>
                                            <p><span class="mbl-icons"><i class="fa fa-mobile" aria-hidden="true"></i></span> 1234561234</p>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-xs-12 m-t-10"> 
                                    <div class="pay-summary" id='payment_div'>
                                        <h3 class="upgrd-right-heading">Payment Details</h3>
                                        <div class="pay-sumry">
                                            <div class="col-xs-12 p-0 pay-sum-det">
                                                <p class="col-xs-5 p-0">Membership Fee </p>
                                                                                                                                                <p class="col-xs-7 p-0 right-upgrd-info">15000.00</p>
                                            </div>
                                                                                                                                                <div class="col-xs-12 pay-sum p-0">
                                                            <p class="col-xs-5 p-0">CGST(9%) </p>
                                                                                                                        <p class="col-xs-7 p-0 right-upgrd-info">1350.00 </p>
                                                        </div>
                                                                                                                                                            <div class="col-xs-12 pay-sum p-0">
                                                            <p class="col-xs-5 p-0">SGST(9%) </p>
                                                                                                                        <p class="col-xs-7 p-0 right-upgrd-info">1350.00 </p>
                                                        </div>
                                                                                                    
                                                                                                <div class="col-xs-12 p-0">
                                                    <div class="net-amount">
                                                        <p class="col-xs-5 p-0 left-netamount">Net Amount </p>
                                                        <p class="col-xs-7 p-0 right-upgrd-info">INR 17700.00 </p>
                                                    </div>
                                                </div>

                                                                                            <!--?>-->

                                            <div class="col-xs-12 p-0 discount">
                                                
                                                                                                <div class="col-xs-8 col-sm-8 col-lg-9 p-0"> 
                                                    <input  type="text"  id='coupon_code_value'  data-parsley-required-message="Enter coupon code" class="form-control input-form" placeholder="Enter Coupon Code" value=""/>
                                                </div>
                                                <div class="col-xs-4 col-sm-4 col-lg-3 p-0">
                                                    <!--<a id='coupon_cd' class="form-control pf-bt "  style="cursor: pointer;">APPLY</a>-->
                                                    <input type="button" id="coupon_apply_btn" class="form-control pf-bt "   onclick="activeCouponCode();" value="APPLY">
                                                    <!--<input type="submit" class="form-control pf-bt membership-btn" value="APPLY">-->
                                                </div>
                                                
                                                                                                <p id="coupon_msg_invalid" style="display:none;color:red;text-align: center;">Invalid coupon code</p>
                                                <p id="coupon_msg_empty" style="display:none;color:red;text-align: center;">Enter coupon code</p>
                                            </div>
                                        </div>
                                        <input type="hidden" name="memcountry_id" id="memcountry_id" value="in"/>
                                        <input type="hidden" name="memstate_id" id="memstate_id" value="16"/>
                                        <input type="hidden" name="memcity_id" id="memcity_id" value="1275339"/>
                                        <input type="hidden" name="revenue_modelid" id="revenue_modelid" value="1"/>
                                        <input type="hidden" name="revenue_purpose" id="revenue_purpose" value="B2B Premium Membership"/>
                                        <input type="hidden" name="totalPrice" id="totalPrice" value="17700"/>
                                        <input type="hidden" name="priceAmount" id="priceAmount" value="15000"/>
                                        <input type="hidden" name="discount_price" id="discount_price" value=""/>
                                                                                <input type="hidden" name="currency" id="currency" value="INR"/>
                                        <input type="hidden" name="addonstype" id="addonstype" value="b2b-premium-membership"/>
                                        <input type="hidden" name="coupon_code" id="coupon_code" value=""/>
                                        <input type="hidden" name="coupon_value" id="coupon_value" value=""/>
                                        <input type="hidden" name="coupon_offer_title" id="coupon_offer_title" value=""/>

                                    </div>
                                </div>

                                <div class="col-xs-12 m-b-20 m-t-10">
                                    <div class="pay-methods" id="pay_method_block">
                                        <h3 class="upgrd-right-heading">Payment Method</h3>
                                                                                    <div class="col-lg-12 col-sm-6 col-md-12 col-xs-12 p-0 pay-categ">
                                                <h5>Credit card / Debit card / Net Banking / Wallet / UPI</h5>
                                                <label><input type="radio" checked="checked" required="" class="payment_gateway" data-parsley-required-message="Choose any one option" name="payment_gateway" id="payment_gateway" value="7" />
                                                    <div class="payment-logo payment-billdesk" title="BillDesk"></div>
                                                </label>

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    <!--                                            <label class="col-xs-6"><input type="radio" required="" checked="checked" class="payment_gateway" data-parsley-required-message="Choose any one option" name="payment_gateway" id="payment_gateway" value="7" />
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        <div class="payment-logo payment-billdesk" title="BillDesk"></div>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    </label>-->
                                            </div>
                                         
                                        <!--                                        <div class="col-lg-6 col-sm-6 col-md-12 col-xs-12 p-0 pay-categ wire-tra">
                                                                                    <h5>Bank Transfer</h5>
                                                                                    <label class="wire-trans"><input type="radio" required="" class="payment_gateway" data-parsley-required-message="Choose any one option" name="payment_gateway" id="payment_gateway" value="3" />
                                                                                        <div class="payment-logo payment-wiretransfer" title="Bank transfer"></div>
                                                                                    </label>
                                                                                </div>-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 queries-info m-t-10 p-0">
                                <p>If you have any queries feel free to <span><a href="../../contact-us" target="_blank">Contact Us</a></span></p>
                                <!--<p>If you have any queries feel free to <span><a onclick="Tawk_API.toggle();" title="Chat">chat</a></span> with us or simply call us on <span>+91 9943825499</span></p> </div>-->
                                                                    <div class="col-xs-12 m-t-10 m-b-10 p-0">
                                        <div class="terms-agree">
                                            <span style="color:red">*</span>By clicking <span class="proceed_pay">Proceed to Pay</span>, you are agreeing to our <a data-toggle="modal" data-target="#upgradeTerms" title="Service Agreement">Service Agreement</a>
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="col-xs-12 text-center">
                                            <input type="button" name="member_details" onclick="member_payment_insert()" id="member_details_pay" class="btn pf-bt" value="Proceed to Pay"/>
                                        </div>
                                    </div>
                                                                <div id="upgradeTerms" class="modal fade" role="dialog">
                                    <div class="modal-dialog">

                                        <!-- Modal content-->
                                        <div class="modal-content col-xs-12 p-b-20">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal"><span>x</span></button>
                                            </div>
                                            <div class="modal-body">
                                                <p id="service_agr_msg" style="color:green;display:none;">Email send</p>
                                                <div class="terms-accpt col-xs-12 p-0">
                                                    <div class="col-xs-12 p-0" >
                                                        <div class="col-xs-12" style="outline: 1px solid #CCC;height:552px;overflow-y: auto; background:#eee;">
                                                                                                                        <p class="agri-text" style="margin-bottom:0px;text-align:center;">SERVICES AGREEMENT</p>

                                                            <p style="margin-top:15px;margin-bottom:0px;text-align:center;">PLEASE READ THIS AGREEMENT CAREFULLY</p>
                                                            <div class="col-xs-12 p-0">
                                                                <h3 style="margin-top:0px;">Acceptance of Terms</h3>
                                                            </div>
                                                            <p>BIZBILLA.COM SERVICES AGREEMENT</p>

<p>PLEASE READ THIS AGREEMENT CAREFULLY</p>

<ol>
	<li>Acceptance of Terms</li>
</ol>

<p>Thank you for your subscription. This Agreement governs the Premium membership service and/or any related Value Added Services (collectively, the &quot;Services&quot;) offered to you by Bizbilla.com (as defined below) through the web site identified by the uniform resource locator www.bizbilla.com (the &quot;Site&quot; or &quot;Website&quot;). You are contracting with AKGS INFOTECH PRIVATE LIMITED under this Agreement.&nbsp; The contracting AKGS PVT LTD entity shall be referred to as &quot;Bizbilla.com&quot;. BY SUBMITTING YOUR APPLICATION OR SERVICE ORDER OR MAKING ANY PAYMENT FOR ANY SERVICES WHETHER ONLINE VIA THE WEBSITE OR OFFLINE OR THROUGH OUR AUTHORIZED SALES AGENT OR RESELLER, YOU INDICATE YOUR AGREEMENT TO BE BOUND BY THIS AGREEMENT.</p>

<p>1.1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This Agreement applies to all Services and governs all applications or service orders for the services (each referred to as a &quot;Service Order&quot;).&nbsp; In case of any conflict between the terms of this Agreement and those of a Service Order, the final resolution is solely rests on bizbilla.com management.</p>

<p>1.2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If a Service Order includes the Premium Membership Service, this Agreement will take effect after, either (i) you have paid the total service fees in full under the Service Order, and (ii) you have successfully completed the A&amp;V (as defined below).</p>

<p>1.3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If a Service Order includes Value Added Services only and NOT the Premium Membership Service, you must concurrently be an existing Premium member. This Agreement will take effect as soon as you have paid the total service fees in full within the prescribed period set forth in the Service Order or otherwise acceptable to Bizbilla.com and shall remain in force until the last date of the relevant service periods of the Services unless early termination in accordance with this Agreement.</p>

<p>1.4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bizbilla.com may amend any part of the Agreement at any time with or without prior notice. The revised Agreement will be published on our website, the earliest possible and shall be effective immediate upon posting. After posting by Bizbilla.com of the amended and restated Agreement, your continued use of the Services shall be deemed to be acceptance of the amended terms. This Agreement may not otherwise be modified except in writing by an authorized signatory of Bizbilla.com.</p>

<p>1.5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The Services provided are subject to the Terms of Use, and all rules and policies of the Website (including but not limited to the Privacy Policy, Product Listing Policy and any rules, policies and special terms and conditions applicable to any Value Added Services), published may be revised from time to time (collectively, the &quot;Website Terms&quot;).&nbsp; You hereby agree to comply with such Terms at all time.</p>

<p>1.6&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; As some or part of the Services may be supported and provided by affiliates of Bizbilla.com, Bizbilla.com may delegate some of the Services to its affiliates, where you agree to pay the portion of invoice for their part of the Service.</p>

<p>2. Authentication and Verification &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>

<p>2.1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Registration for the Premium Membership Service is subject to verification and authentication procedures to validate all the information provided in the registration form as deemed appropriate by Bizbilla.com (the &quot;A&amp;V&quot;).&nbsp; &quot;Authentication&quot; refers to confirmation by the A&amp;V Agency of your business registration. &quot;Verification&quot; refers to confirmation by the A&amp;V Agency that the contact person indicated in the Service Order is your authorized representative to represent you on our website. You authorize Bizbilla.com and its authorized third party security service provider (at Bizbilla.com&rsquo;s sole choice) (the &quot;A&amp;V Agency&quot;) to conduct the A&amp;V about you.&nbsp; You agree to provide all necessary information and render all reasonable assistance and cooperation that either Bizbilla.com or the A&amp;V Agency may require in order to complete the A&amp;V.</p>

<p>2.2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If you fail the A&amp;V for the first time, upon your request and at your cost, Bizbilla.com may conduct the A&amp;V for the subsequent time. However, in no event shall Bizbilla.com be obliged to conduct any A&amp;V after three (3) calendar months from the date of your Service Order.&nbsp; If you fail to successfully complete the A&amp;V within the above mentioned 3 months period, your Service Order for the Services will be considered as cancelled.</p>

<p>2.3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If you fail the A&amp;V and then cancel the Service Order or if you are deemed to cancel a Service Order upon the expiry of the above-mentioned 3 months period, Bizbilla.com will refund the service fees in accordance with our established practices, provided, however that Bizbilla.com shall have the right to deduct administrative charges in connection with the A&amp;V that has been conducted as well as any other applicable charges, levies, costs and expenses that may be incurred in connection with or arising from such refund. You shall provide to us correct bank account details and other information necessary for Bizbilla.com to process and make the refund.&nbsp; In case you fail to provide the required information within three (3) months, you will be deemed to have waived any claim in respect of such refund money, and Bizbilla.com shall be entitled to forfeit absolutely the entire service fees paid by you without any liability to you.</p>

<p>2.4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Any changes to the information that has been verified under the A&amp;V shall be subject to new A&amp;V at Member&#39;s own expense.&nbsp; If Member fails to make payment and the changed information is not verified, Bizbilla.com may, in its sole discretion, suspend or revoke all Services with respect to such Member without any refund or other compensation to Member.</p>

<p>2.5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Upon each renewal of the Premium Membership Service, the A&amp;V shall be carried out by Bizbilla.com in accordance with the clause 2. If you purchase the Premium Membership Service for more than one year, you shall also undergo and pass the A&amp;V annually prior to the expiry date of each annual placement period in accordance with this clause 2.</p>

<p>3. Services</p>

<p>3.1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Premium Membership Service has the following core features (which may be modified or suspended for scheduled or unscheduled maintenance purposes, from time to time at the sole discretion of Bizbilla.com upon notification)</p>

<ol>
	<li>Company Profile: Allows Member to display and edit basic information about its business, such as year and place of establishment, estimated annual sales, number of employees, products and services offered, etc.</li>
	<li>Product &amp; Services Showcase: Allows Member to display and edit descriptions, specifications and images of its products.</li>
	<li>Buyer Requirements Posting: Allows member to post their buying requirements to get quotations from suppliers.</li>
	<li>Promotion Tools: Allows premium members to post articles, news, blogs, tradeshow and press release to enhance their web presence and promote their business.</li>
	<li>Member Site: Bizbilla provides a separate webpage in which member can choose his own premium membership template from a list of premium templates with advanced CMS and other responsive features. It acts like separate webpage with all information of the member.</li>
</ol>

<p>3.2 The Value Added Services include the following:</p>

<p>a) Advertisement Banners booking: Bizbilla.com members can book advertisement banners on all web pages of the portal. Members will be charged accordingly to the size of the banner and the respective page displaying their ads.</p>

<p>3.3. Bizbilla.com reserves the right to change, upgrade, modify, limit or suspend the Services or any of its related functionalities or applications at any time temporarily or permanently without prior notice.&nbsp; Bizbilla.com further reserves the right to introduce new features, functionalities and/or applications to the Services. All new features, functionalities, applications, modifications, upgrades and alterations shall be governed by this Agreement, unless otherwise stated by Bizbilla.com.</p>

<p>3.4 The Services are offered only to businesses and corporate entities (e.g. corporations, limited liability companies, partnership, sole proprietors, etc.) that are capable of having a business name and business address that can be verified by the A&amp;V Agency.</p>

<p>3.5 Members shall keep confidentiality and proper custody of their Member ID and Password in connection with its use of the Services (the &quot;Account&quot;).&nbsp; A set of Member ID and Password is unique to a single Account.&nbsp; Members agree that they shall solely be responsible for any use of their Account (including but not limited to publishing of any information and materials, accepting any online rules and agreements, subscribing for or purchasing any service or product online) and any use of its Account will be deemed by Bizbilla.com as having been fully authorized by such Member.&nbsp; Member shall not share with, assign to or permit a third party to use their Account, Member ID or Password (collectively, &quot;multiple use&quot;).&nbsp; Member acknowledges that multiple use of its Account with any third party may cause irreparable harm to Bizbilla.com or other users of the Site, and agrees to indemnify Bizbilla.com and its affiliates against any loss or damages suffered by Bizbilla.com and its affiliates as a result of multiple use of its Account. If Member fails to take necessary measures to maintain the security of the Account or to prevent the risks of unauthorized access, Bizbilla.com shall have the right to suspend the provision of the Services or terminate this Agreement without any refund or other compensation to Member.</p>

<p>3.6 Bizbilla.com shall have the right, but shall not be obliged, to monitor or examine any information and materials including any website link that Member publishes or submits to Bizbilla.com for publishing on the Site (the &quot;Member Materials&quot;).&nbsp; Publishing of Member Materials shall by no means mean that Bizbilla.com has endorsed or otherwise certify the contents of such Member Materials.&nbsp; Member shall be solely responsible for the contents of its Member Materials.</p>

<p>3.7 If any activities of Member on the Site or any Member Materials (including material accessible through a link in the Member Materials), in Bizbilla.com&rsquo;s reasonable opinion, are in violation of any applicable laws and regulations or a third party&rsquo;s legitimate rights (including without limitation intellectual property rights), the terms of this Agreement or the Website Terms or may otherwise subject Bizbilla.com or its affiliates to liability. Bizbilla.com may, at its option, delete, remove or modify such Member Material or any part there of and/or limit or suspend the provision of the Services or any part thereof (including without limitation limiting the number or types of product listings that the Member can publish on the Site for such duration as Bizbilla.com may in its sole discretion consider appropriate).</p>

<p>3.8 Bizbilla.com reserves the right to cooperate fully with governmental authorities, private investigators and/or injured third parties in the investigation of any suspected criminal or civil wrongdoing. Further, Bizbilla.com may disclose Member&#39;s identity and contact information, if requested by a government or law enforcement body, an injured third party, or as a result of a subpoena or other legal action.&nbsp; Bizbilla.com shall not be liable for damages or results thereof, and Member agrees not to bring any action or claim against Bizbilla.com for such disclosure. In connection with any of the foregoing, Bizbilla.com may suspend or terminate Member&rsquo;s Account as Bizbilla.com deems appropriate at its sole discretion.&nbsp; Bizbilla.com shall have the right to publish the records relating to handling of complaints against Member, breaches by Member or termination of this Agreement on the Site.</p>

<p>3.9 Member hereby grants to Bizbilla.com a non-exclusive, royalty-free, sub-licensable, worldwide, transferable license to (a) display, publish or transmit all or part of the Member Materials or any adaptations thereof, (b) link, copy, store, adapt, translate or make other reasonable use of all or part of the Member Materials or any adaptations thereof, necessary to provide the Services in any medium known now and in the future.</p>

<p>3.10 Member authorizes Bizbilla.com (Bizbiila.com however has no obligation) to, directly or indirectly, in such form and at such time and conditions at Bizbilla.com&rsquo;s sole discretion, promote, on behalf of Member, any Materials.&nbsp; To the extent that Bizbilla.com does not materially modify such Materials, Member agrees and undertakes that it shall be solely responsible for, and shall keep Bizbilla.com fully indemnified against any action, liability, claim, loss, damage and expense (including legal cost) arising from or related to such Materials.</p>

<p>3.11 Bizbilla.com reserves the right to improve or update the Services at any time, including improvement to or upgrade of the company and product classifications, ranking etc.</p>

<p>4. Service Period</p>

<p>4.1 Unless otherwise agreed by the Parties, the service period for the Premium Membership Service shall be one (1) year from the activation date of the Account. Activation of the Account shall be notified to the member via email to such email address provided by member upon registration for the service.</p>

<p>4.2 The service period for any Value Added Service shall be the agreed period specified in the relevant Service Order provided.</p>

<p>4.3 This Agreement will expire on the day when all the service periods expire unless early terminated according to the terms of this Agreement.</p>

<p>5. Fees &amp; Payment:</p>

<p>5.1 In consideration of Bizbilla.com&#39;s agreement to process the application and subject to the A&amp;V, to provide the Services, you agree to pay Bizbilla.com (of its relevant affiliate) the service fees.&nbsp; All service fees shall be payable in advance to Bizbilla.com or its affiliate or authorized agent by wire transfer, credit card, third-party payment system (including but not limited to PayPal) or such other method acceptable to Bizbilla.com, in US Dollars or its equivalent in such other currency as permitted by Bizbilla.com. Except as provided in clauses 2.3 and 3.5, all payments made are non-refundable.</p>

<p>5.2 All services fees are exclusive of any taxes, duties or other governmental levies or any financial charges.&nbsp;&nbsp; You agree to pay and be responsible for any such taxes, duties, levies or charges on the sale and use of the Services in addition to our service fees.&nbsp; In the event Bizbilla.com is required by any applicable law to collect any taxes or duties, you agree to pay such taxes or duties toBizbilla.com.</p>

<p>5.3 Bizbilla.com reserves the right to modify its pricing structure, discounts and payment conditions from time to time at its sole discretion.</p>

<p>6. Member Responsibilities:</p>

<p>6.1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Member agrees to provide all necessary information, materials and approval, and render all reasonable assistance and cooperation necessary for Bizbilla.com&rsquo;s provision of the Services.&nbsp; If Member&rsquo;s fails to do so results in delay in the provision of any Service, Bizbilla.com shall not be obliged to extend the relevant service period or liable for any loss or damages arising from such delay.</p>

<p>6.2 Member represents, warrants, and undertakes (where applicable) to Bizbilla.com that:</p>

<ol>
	<li>They have the full power and authority to enter into this Agreement, to grant the license and authorization and to perform their obligations hereunder;</li>
	<li>They will carry on their activities on the Site in compliance with any applicable laws and regulations;</li>
	<li>They will not use the Services to defraud users of the Site or engage in other unlawful activities (including without limitation spamming, allowing another to use their business registration information to subscribe for an Bizbilla.com service;</li>
	<li>They have the legitimate right and authorization to sell, distribute or export all products or services that they posts on the Site or otherwise referred to in their Member Materials;</li>
	<li>all contents of their Member Materials are true, lawful and accurate, and are not false, misleading or deceptive;</li>
	<li>They will not impersonate any person or entity, or misrepresent themselves or their affiliation with any person or entity;</li>
	<li>They will not post any product or service listing in breach of the Site&rsquo;s Product Listing Policy, and their Member Materials or any product or service referred to in their Member Materials do not infringe or otherwise abet or encourage the infringement or violation of any third party&#39;s copyright, patent, trademarks, trade secret or other proprietary right, rights of publicity and privacy or other legitimate rights;</li>
	<li>Their Member Materials do not contain information that is defamatory, libellous, threatening or harassing, obscene or sexually explicit or harmful to minors;</li>
	<li>Their Member Materials do not contain information that is discriminatory or promotes discrimination based on race, sex, religion, nationality, disability, sexual orientation or age.</li>
</ol>

<p>6.3 Member agrees and undertakes that they will not:</p>

<ol>
	<li>Copy, reproduce, exploit or expropriate Bizbilla.com&#39;s various proprietary directories, databases and listings;</li>
	<li>use or distribute any computer viruses or other destructive devices and codes that may harm, interfere with, intercept or expropriate any software or hardware system, data or personal information;</li>
	<li>Gain or attempt to gain authorized access to the computer systems or networks used by Bizbilla.com and/or any user of the Site or engage in any other activities that may harm the integrity of such computer systems or networks;</li>
	<li>Take any action which may undermine the integrity of Bizbilla.com&#39;s feedback system, such as leaving positive feedback for himself using secondary Member IDs or through third parties or by leaving unsubstantiated negative feedback on another Member.</li>
</ol>

<p>6.4 With regards to the information about or posted on behalf of any business referee, Member represents and warrants that they have obtained all necessary consents, approvals and waivers from their business partners and associates (a) to act as their business referee; (b) to post and publish their contact details and information, reference letters and comments on their behalf; and (c) that third parties may contact such business referees to support claims or statements made about the Member.</p>

<p>6.5 Member shall conduct all activities on the Site in accordance with all applicable laws and regulations and commonly accepted commercial practices.&nbsp; Member shall also conduct their business affairs with integrity and in an ethical manner.</p>

<p>6.6 Member acknowledges and agrees that Bizbilla.com shall not be responsible, and shall have no liability to their or anyone else for any content of the Member Materials or materials posted by third parties.</p>

<p>6.7 Member shall be solely liable for their business name submitted.&nbsp; In case Bizbilla.com receives any complaint or claim against Member in respect of their business name, unless Member changes to a new business name which has also passed the A&amp;V, Bizbilla.com shall have the right to suspend or terminate Member&rsquo;s Account immediately.</p>

<p>6.8 Member agrees to indemnify Bizbilla.com and its affiliates and their employees, agents and representatives and to hold them harmless, from any and all losses, damages, actions, claims and liabilities (including legal costs on a full indemnity basis) which may arise, directly or indirectly, from their Member Materials or use of the Services or from Member&#39;s breach of this Agreement or the Website Terms (including claims arising from Member&rsquo;s business name) and from claims of third parties. Bizbilla.com reserves the right, at its own expense, to assume the exclusive defence and control of any matter otherwise subject to indemnification by Member, in which event Member shall cooperate with Bizbilla.com in asserting any available defences.</p>

<p>7. Limitation of Liability</p>

<p>7.1 Bizbilla.com represents and warrants that it will provide the Services with reasonable care and skill.&nbsp; EXCEPT AS EXPRESSLY PROVIDED IN THIS AGREEMENT AND TO THE FULL EXTENT PERMITTED BY LAW THE SERVICES ARE PROVIDED ON AN &quot;AS IS&quot; AND &quot;AS AVAILABLE&quot; BASIS, BIZBILLA.COM HEREBY EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF CONDITION, QUALITY, DURABILITY, PERFORMANCE, ACCURACY, RELIABILITY, MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES OR IF SUCH POSSIBILITY WAS REASONABLY FORESEEABLE.&nbsp; ALL SUCH WARRANTIES, REPRESENTATIONS, CONDITIONS, UNDERTAKINGS AND TERMS ARE HEREBY EXCLUDED.&nbsp; IF BIZBILLA.COM BREACHES THE WARRARNTY HEREUNDER, BIZBILLA.COM SHALL RE-PERFORM THE AFFECTED PART OF THE SERVICES.&nbsp; TO THE FULL EXTENT PERMITTED BY LAW, THE REMEDY UNDER THIS CLAUSE 7.1 SHALL BE MEMBER&rsquo;S SOLE AND EXCLUSIVE REMEDY FOR BREACH OF BIZBILLA.COM&rsquo;S WARRANTIES UNDER THIS AGREEMENT.</p>

<p>7.2 TO THE FULL EXTENT PERMITTED BY LAW, BIZBILLA.COM SHALL NOT BE LIABLE FOR ANY INDIRECT, CONSEQUENTIAL, INCIDENTIAL, SPECIAL OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION DAMAGES FOR LOSS OF PROFITS OR REVENUES, BUSINESS INTERRUPTION, LOSS OF BUSINESS OPPORTUNITIES OR LOSS OF DATA, WHETHER IN CONTRACT, NEGLIGENCE, TORT OR OTHERWSIE, ARISING FROM THE USE OR INABILITY TO USE OF THE SERVICES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES OR IF SUCH POSSIBILITY WAS REASONABLY FORESEEABLE.</p>

<p>7.3 Member agrees not to hold Bizbilla.com responsible for third parties&rsquo; content, actions or inactions.&nbsp; If Member uses third parties&rsquo; services, software or products in connection with the Services, Member further agrees not to hold Bizbilla.com responsible for such third parties&rsquo; services, software or products.</p>

<p>7.4 Any material downloaded or otherwise obtained through the use of the Services is done at Member&#39;s sole discretion and risk and Member is solely responsible for any damage to their computer system or loss of data that may result from the download of any such material. No advice or information, whether oral or written, obtained by Member from Bizbilla.com or through or from the Services shall create any warranty not expressly stated in this Agreement.</p>

<p>7.5 Not with-standing any of the foregoing provisions, the aggregate liability of Bizbilla.com and its affiliates and their employees, agents and representatives or anyone acting on their behalf, with respect the Member, for all the claims arising from the use of the Services or the Site shall not exceed the amount of the services fees that Member pays to Bizbilla.com during the current service period for the Premium Membership Service. The preceding sentence shall not preclude the requirement by Member to prove actual damages. All claims arising from the use of the Services must be filed within one (1) year from the date the cause of action arose.</p>

<p>8. Termination</p>

<p>If any of the following circumstances occurs, Bizbilla.com shall have the right to terminate the Agreement immediately at such time deemed appropriate by Bizbilla.com acting in its sole discretion upon written notice to Member and to forfeit the service fees for any unused Services without liability:</p>

<p>8.1 Bizbilla.com has reasonable grounds to believe that Member uses the Services for any fraudulent or other unlawful purpose;</p>

<ol>
	<li>upon complaint or claim from any third party, Bizbilla.com has reasonable grounds to believe that Member has wilfully or materially breached their contract with the third party complainant, including without limitation where Member has failed to deliver the products ordered by the complainant after receipt of the purchase price, or where Member has failed to make payment to the complainant after receipt of the products delivered by the complainant, or where Member has delivered the products that fail to materially meet the terms and descriptions outlined in Member Materials;</li>
	<li>Bizbilla.com has reasonable grounds to believe that Member is involved in the production or sale of any inferior goods or any goods which infringe any intellectual property rights or other legitimate rights of any third party;</li>
	<li>Member assigns or transfers part or all of their rights and obligations under this Agreement to a third party (including multiple use of their Account) without Bizbilla.com&rsquo;s prior written consent;</li>
	<li>Member sells any business information related to buyers and/or their buy leads/enquiries which are obtained by Member as a result of use of the Services without Bizbilla.com&rsquo;s prior written consent;</li>
	<li>Member is involved in any scheme or activities to undermine the integrity or normal operation of the computer systems or networks of the Site (including gaining unauthorized access to the systems of the Site, stealing, modifying or deleting the information of other members of the Site without authorization);</li>
	<li>Member is in breach of any of their representations, warranties and undertakings in</li>
</ol>

<p>clause 6;</p>

<ol>
	<li>Member has failed to rectify any breach of their Agreement other than those under para (1)-(7) hereof within 10 working days of being notified by Bizbilla.com of such breach;</li>
	<li>Member has committed breaches other than those under para (1)&ndash;(7) hereof for 3 or more times;</li>
	<li>Member is deemed to be an &quot;offshore entity&quot; pursuant to clause 3.5 of this Agreement;</li>
	<li>Member ceases to conduct their operations, is insolvent or wound up, or becomes the subject of any voluntary or involuntary proceeding relating to insolvency, receivership, liquidation or composition for the benefit of creditors or similar proceeding; or</li>
	<li>Member and/or its director(s), officer(s) or controlling party/ies became, or Bizbilla.com has reason to believe that Member and/or its director(s), officer(s) or controlling party/ies will become, an entity or person who is subject to any economic or trade sanctions of any governmental, inter-national or regulatory entities, provided that should Bizbilla.com exercise its right of termination under this Clause 8.1(12), Bizbilla.com may, at its discretion (but not as an obligation), refund to Member within 90 days part or all of the fees for any unused Services for the reminder of the Service Period after the termination date.</li>
</ol>

<p>8.2 If the Agreement is terminated under clause 8.1 and other provisions of this Agreement, Bizbilla.com shall have the right to refuse any and all current or future use by Member of the Services or any other services that may be provided by Bizbilla.com. Furthermore, Bizbilla.com shall have the right to refuse any renewal or extension of Service Period if any of the scenario described in Clause 8.1(11) occurred.</p>

<p>8.3 In the event that Bizbilla.com does not receive full payment of subscription fees within ten (10) days of automatic renewal of subscription for the Service, such Member&#39;s subscription shall be terminated immediately without further notification from Bizbilla.com.&nbsp; Access to the Premium Membership Service shall be denied upon such termination.</p>

<p>8.4 Not with-standing any of the foregoing provision of the Clause 8, Bizbilla.com may at any time within 14 calendar days prior written notice for convenience, without reason terminate this Agreement. Such termination shall be without prejudice to all rights and obligations incurred by Member and Bizbilla.com on and prior to the termination date. Bizbilla.com shall at its discretion refund within 90 days to Member the pro-rated amount of any fees received from Member for unused Services for the remainder of the Service Period after the termination date.</p>

<p>8.5 It is the sole obligation of Member to keep Bizbilla.com informed of a valid and legally permissible account for receiving any funds payable to it under this Agreement. Bizbilla.com shall not be responsible for any delay or failure of receipt of funds by Member arising out of incomplete or inaccurate information provided by Member and Bizbilla.com shall only use its reasonable commercial efforts to contact Member in respect of any such delay or failure.</p>

<p>8.6 Under no circumstances shall Bizbilla.com be held liable for any delay or failure or disruption of the Services resulting directly or indirectly from acts of nature, forces or causes beyond its reasonable control, including without limitation, acts of God, Internet failures, computer, telecommunications or any other equipment failures, electrical power failures, strikes, labour disputes, riots, insurrections, civil disturbances, shortages of labour or materials, terrorism, war, governmental actions, orders of domestic or foreign courts or tribunals.</p>

<p>9. &nbsp;Force Majeure</p>

<p>9.1 Under no circumstances shall Bizbilla.com be held liable for any delay or failure or disruption of the Services resulting directly or indirectly from acts of nature, forces or causes beyond its reasonable control, including without limitation, acts of God, Internet failures, computer, telecommunications or any other equipment failures, electrical power failures, strikes, labour disputes, riots, insurrections, civil disturbances, shortages of labour or materials, terrorism, war, governmental actions, orders of domestic or foreign courts or tribunals.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>10. Pharmaceutical Product/Service Policies:</p>

<p>10.1 Bizbilla.co is a platform that does not facilitates the purchase of pharmaceutical products, in fact, it only advertise and/or showcase the pharmaceutical products posted by the Suppliers listed on the website &ndash; www.bizbilla.com. The Buyers and Suppliers assure Bizbilla.com and hereby agree to abide by and be compliant of all the related laws, rules, regulations, notifications or orders issued by the Government of India or any of its Agencies from time to time. Bizbilla.com shall not be responsible for any information/content related to the Medicine(s) and/or Drugs, posted/provided/displayed by the listed Suppliers on our website Bizbilla.com, as we are only a medium of advertisement for the Buyers and Suppliers. Suppliers of the Medicines and/or Drugs hereby undertake that they shall solely be responsible and shall bear all the liabilities in respect of selling prescriptive Medicines and/or Drugs mentioned in the Schedules of the Drugs and Cosmetics Act, 1940, without the Certified Practitioner&rsquo;s Prescription.</p>

<p>10.2 In the event of breach of such condition, Bizbilla.com shall not be liable and responsible in any manner whatsoever, as Bizbilla.com does not take part in the actual transaction that takes place between the Buyers and Suppliers. User(s) of the website &ndash; www.bizbilla.com undertake and agree to INDEMNIFY and hold harmless Bizbilla.com or any of its affiliates, directors, officers, employees or representatives from and against any/all losses, liabilities, damages, claims, costs and expenses (including attorney&rsquo;s fees and expenses, any third party claims), which Bizbilla.com may incur or suffer as a result of or in connection with any illegal sales of drugs and/or medicines. In compliance with Drug and Cosmetic Act and Rules, we don&#39;t display or list the Medicines and/or Drugs mentioned in the Schedule X of the Drugs and Cosmetics Act, 1940. Bizbilla.com does not offer any guarantees or warranties on the medicinal products or services displayed or listed on our website &ndash; www.bizbilla.com and is not liable for any transaction between the Buyers &amp; Suppliers as such, including the sale of any medicine(s) restricted and/or banned for sale by the Governmental or any other Regulatory Authorities.</p>

<p>11. General Provisions</p>

<p>11.1 This Agreement constitutes the entire agreement is between the Member and Bizbilla.com with respect to and governs the use of the Services, superseding any prior written or oral agreements in relation to the same subject matter herein.</p>

<p>11.2 This Agreement shall be governed by the laws of the &quot;Republic of India&rdquo; without regard to its conflict of law provisions. The Parties to this Agreement hereby submit to the exclusive jurisdiction of the legal courts of India</p>

<p>11.3 If any provision of this Agreement is held to be invalid or unenforceable, such provision shall be struck and the remaining provisions shall be enforced.</p>

<p>11.4 Headings are for reference purposes only and in no way define, limit, constitute or describe the scope or extent of such section.</p>

<p>11.5 Any failure by Bizbilla.com to exercise any of its rights under this Agreement shall not constitute a waiver of such right or a waiver with respect to subsequent or similar breach.&nbsp; A waiver shall be effective only if made in writing.</p>

<p>11.6 Bizbilla.com shall have the right to assign this Agreement (including all of its rights, titles, benefits, interests, and obligations and duties in this Agreement) to any person or entity (including any affiliates of Bizbilla.com)&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--                                            <div class="upg-send-mail m-t-10 col-xs-12 p-0">
                                                                                                <a id="service_agreement_mail" href="">Send Email</a>
                                                                                            </div>-->
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
            </form>
                    </div>
        <div id="bill_pay_section">

        <form name="billdesk_payment_form" id="billdesk_payment_form" data-parsley-validate="" method="post" action="https://pgi.billdesk.com/pgidsk/PGIMerchantPayment">
                        <input type="hidden"  name="msg" id="billdesk_pay_msg" value=""/>
        </form>
    </div>
</div>
<input type="hidden" name="addonstype" id="addonstype" value="b2b-premium-membership"/>
                        <!--</div>
</div>-->



<!--</form>
</div>
<div class="clear" style="clear: both;height:1em"></div>
</div>
</div>-->            </div>
        </div>
    </div>
</div>
<div class="container-fluid profile-footer">   
    <p class="text-center"> Copyright &copy; 2017 <a href="../../default.htm" target="_blank" title="Bizbilla.com">Bizbilla.com</a> All rights reserved.</p>
</div>    <script>
            window.__INIT_USER__ = {
                userId: '292846',
                name: 'techconsult',
                pic: '../../../https@uploads-3scb1afwjgwax1popi.stackpathdns.com/member-profile/2017/10/30_292846images-1-jpg.jpeg'
            };
    </script>
    <div id="chatApp">
        <div id="__supportChat"></div>
    </div>
            <script src="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/js/vendor.js@v=1510029775"></script>
            <link rel="stylesheet" href="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/css/customstyle.css@v=1510659030"/>
                <link rel="stylesheet" href="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/css/staticpromo.css@v=1510650289"/>
                <script src="../../../https@cdnassets-3scb1afwjgwax1popi.stackpathdns.com/assets/js/app.js@v=1510663159"></script>
                <script src="../../assets/js/dashboard.js@v=1510661199"></script>
                <script src="../../js/verified.js@v=1495001519"></script>
        <!--            <script type="text/javascript">
var bannerurl = '<br />
<b>Notice</b>:  Undefined variable: Bannerurl in <b>/home/bizbilla/public_html/src/app/views/layout.php</b> on line <b>501</b><br />
';</script>-->
        <div class="modal fade common-fade" data-backdrop="static" id="testM" role="dialog" style="display: none;">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header testM-close">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade common-fade" data-backdrop="static" id="ratingModelID" role="dialog"  style="display: none;">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header testM-close">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade common-fade" data-backdrop="static" id="adbannerModelID" role="dialog"  style="display: none;">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content col-xs-12 p-b-30">
                <div class="modal-header testM-close">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade common-fade" data-backdrop="static" id="InquiryModal" role="dialog" style="display: none;">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <div class="report-form modal fade common-fade " data-backdrop="static" id="ComplaintModal" role="dialog" style="display: none;">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
            <script type="text/javascript">
            var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
            (function () {
                var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
                s1.async = true;
                s1.src = '../../../https@embed.tawk.to/5959c5d750fd5105d0c839cd/default';
                s1.charset = 'UTF-8';
                s1.setAttribute('crossorigin', '*');
                s0.parentNode.insertBefore(s1, s0);
            })();
                    Tawk_API = Tawk_API || {};
                Tawk_API.visitor = {
                    name: 'techconsult',
                    email: 'info@tech-consult.in',
                    phone: '1234561234'
                };
            </script>
        </body>

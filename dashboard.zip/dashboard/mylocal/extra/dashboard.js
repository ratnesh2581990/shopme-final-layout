/*
 Project Title   :   Bizbilla
 Version         :   3.0
 Title           :   Dashboard
 Description     :   Profile dashboard-product,sell offer(hidded),blog,news,article,press release,certification details scripts
 Included        :   Home,profile
 Last Modified   :   Aug 15,2017 / Sivagami
 Assigned to     :   Aravind,Manobalan,Kalaivanan
 */
//*********active menu in profile*******

var hashValue = location.hash;
hashData = hashValue.replace(/^#/, '');
if (hashData == '') {
    hashData = 'pending';
}
$('#page_type').val(hashData);
$('#productactive').find('li a label input.' + hashData).addClass('active');
$('#refresh-count-load').find('.' + hashData).addClass('proactive');
$('#refresh-count-load-services').find('.' + hashData).addClass('proactive');
$(window).on('hashchange', function () {

//    $('#messages_container').load(location.href + ' #messages_container');

    var hashValue = location.hash;
//       $('#products_manage_container').load(location.href + '#products_manage_container');
    var currentURL = window.location.href;
    $('#page_type').val(hashData);
    hashData = hashValue.replace(/^#/, '');
    if (hashData == '') {
        hashData = 'pending';
    }
    $('#productactive').find('li a label input').removeClass('active');
    $('#productactive').find('li a label input.' + hashData).addClass('active');
    $('#refresh-count-load').find('.product-manag-box').removeClass('proactive');
    $('#refresh-count-load-services').find('.product-manag-box').removeClass('proactive');
    $('#refresh-count-load').find('.' + hashData).addClass('proactive');
    $('#refresh-count-load-services').find('.' + hashData).addClass('proactive');
    $("#manage-ecom-offers,#showbscproducttable,#messages_container,#selloffers_manage,#buyingneeds_manage_container,#article_manage,#press_manage,#hotnews_manage,#blog_manage,#services_manage_container,#tradeshow_manage_container,#sharelink_manage,#ewallet,#ecommerce_manage_container,#ecommerce_delivery_container").
            jsGrid("reset");
    $("#products_manage_container, #buyingneeds_manage_container").jsGrid("refresh");
    $("#manage-ecom-offers,#showbscproducttable,#products_manage_container,#halal_products_manage_container,#messages_container,#selloffers_manage,#buyingneeds_manage_container,#article_manage,#press_manage,#hotnews_manage,#blog_manage,#services_manage_container,#tradeshow_manage_container,#sharelink_manage,#ewallet,#ecommerce_manage_container,#ecommerce_delivery_container").
            jsGrid("render");
    //productsManageGrid(product_field, hashData);
//    $('.jsgrid-nodata-row').html("No " + hashData + " Product Found");
});
//*****product specification in profile add product form*****
$(function () {
//    $('.addproducttagspecfic').select2({
//        tags: true,
//        selectOnBlur: true,
//        selectOnClose: true,
////                        tags: ["red", "green", "yellow"],
//        tokenSeparators: [',', ';', '\t', '\n'],
//    });

    /* profile index page form */
    $("#buy_local").select2({
        placeholder: 'Choose country',
        tags: true,
        createTag: function (params) {
            return undefined;
        },
        maximumSelectionLength: 10,
        matcher: function (params, data) {
            return matchStart(params, data);
        }
//        selectOnClose: hide
    });
    $("#buy_keyword").select2({
        placeholder: 'Enter keywords',
        tags: true,
        maximumSelectionLength: 10,
//        selectOnClose: true,
        tokenSeparators: [',', '\t', '\n'],
        language: {
            noResults: '',
            maximumSelected: function (args) {
                // args.maximum is the maximum number of items the user may select
                return "You can select only 10 items";
            }
        }
    });
    $("#sell_local").select2({
        placeholder: 'Choose country',
        tags: true,
        createTag: function (params) {
            return undefined;
        },
        maximumSelectionLength: 10,
        matcher: function (params, data) {
            return matchStart(params, data);
        }
//        selectOnClose: true
    });

    $("#sell_keyword").select2({
        placeholder: 'Enter keywords',
        tags: true,
        maximumSelectionLength: 10,
//        selectOnClose: true,
        tokenSeparators: [',', '\t', '\n'],
        language: {
            noResults: '',
            maximumSelected: function (args) {
                // args.maximum is the maximum number of items the user may select
                return "You can select only 10 items";
            }
        }
    });


    $('#buyer_req_detail').select2({
        tags: true,
        selectOnBlur: true,
        selectOnClose: true,
//                        tags: ["red", "green", "yellow"],
        tokenSeparators: [',', ';', '\t', '\n'],
    });
//    $(".addproducttagspecfic").on("select2:select select2:unselect", function (e) {
//        //this returns all the selected item
//        var items = $(this).val();
//        //Gets the last selected item
//        var lastSelectedItem = e.params.data.id;
//        if (/^[a-zA-Z0-9-]*$/.test(lastSelectedItem) == false) {
//            $('#proforms').attr('onsubmit', 'return false;');
//            items.splice(-1, 1);
//            $(".addproducttagspecfic option[value='" + lastSelectedItem + "']").remove();
//            var new_items = $.unique(items);
//            $('.addproducttagspecfic').select2({data: new_items});
//            $('.addproducttagspecfic').select2({tags: new_items});
//        } else {
//            $('#proforms').attr('onsubmit', 'return true;');
//            var new_items = $.unique(items);
//            $('.addproducttagspecfic').select2({data: new_items});
//            $('.addproducttagspecfic').select2({tags: new_items});
//        }
//    });
});
function matchStart(params, data) {
    params.term = params.term || '';
    if (data.text.toUpperCase().indexOf(params.term.toUpperCase()) == 0) {
        return data;
    }
    return false;
}
//*********profile manage blocks***********
var mem_type = $('#mem_type').val();
var product_field = [];
if (hashData == 'approved') {
    product_field = [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {
            name: "name", title: "Name", align: "center", type: "text", autosearch: true, valueField: "name", textField: "name", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {

                    return item.name;
                } else {
                    return item.temp_name;
                }
            }
        },
        {
            name: "description", align: "center", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {
                    return item.description;
                } else {
                    return item.temp_description;
                }
            }
        },
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                if (item.last_update_at == '0000-00-00 00:00:00') {

                    return item.updated_at;
                } else {
                    return item.last_update_at;
                }
            }
        },
        {
            type: "control",
            align: "center",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete this Product",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        },
        {
            name: "slug", type: "Button", width: 30, align: "center", title: "Status", itemTemplate: function (value, item) {
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else if (item.status == 10) {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    } else if (item.edited_status == 1) {
                        var $myButton = '<span class="label label-info">Edited</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    if (mem_type == '4') {
                        var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                        var $myButton = '<a href="' + URL_BSCLASSIFIEDS_PATH + '/' + value + '.html"><span class="btn  btn-sm btn-primary">View</span></a>';
                    } else if (mem_type == '5') {
                        var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                        var $myButton = '<a href="' + URL_B2BCLASSIFIEDS_PATH + '/' + value + '.html"><span class="btn  btn-sm btn-primary">View</span></a>';
                    } else {
                        var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                        var $myButton = '<a id="viewproducts" target="_blank" href="' + URL_PRODUCTS_PATH + '/' + value + '.html"><span class="btn  btn-sm btn-primary">View</span></a>';
                    }
                    return $result.add($myButton)
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 2) {
                        var $myButton = '<span class="label  label-danger">Ignored</span>';
                    } else {
                        var $myButton = '<span class="label  label-danger">Deleted</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="btn pf-bt">Edited</span>';
                    return $result.add($myButton);
                }
            }
        }
//        {
//            name: "edited_status", width: 30, align: "center", title: "Edited Status", itemTemplate: function (value) {
//                if (hashData == 'approved' && value == '1') {
//                    return '<label class="label label-warning">Edited</label>';
//                } else {
//                    return '--';
//                }
//            }
//        }

    ];
} else {
    product_field = [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {
            name: "name", title: "Name", align: "center", type: "text", autosearch: true, valueField: "name", textField: "name", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {

                    return item.name;
                } else {
                    return item.temp_name;
                }
            }
        },
        {
            name: "description", align: "center", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {
                    return item.description;
                } else {
                    return item.temp_description;
                }
            }
        },
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "updated_at", textField: "updated_at", itemTemplate: function (__, item) {
                if (item.last_update_at == '0000-00-00 00:00:00') {

                    return item.updated_at;
                } else {
                    return item.last_update_at;
                }
            }
        },
        {
            type: "control",
            align: "center",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete this Product",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        },
        {
            name: "slug", width: 30, align: "center", title: "Status", itemTemplate: function (value, item) {
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else if (item.status == 10) {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    } else if (item.edited_status == 1) {
                        var $myButton = '<span class="label label-info">Edited</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    if (mem_type == '4') {
                        var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                        var $myButton = '<a href="' + URL_BSCLASSIFIEDS_PATH + '/' + value + '.html"><span class="btn  btn-sm btn-primary">View</span></a>';
                    } else if (mem_type == '5') {
                        var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                        var $myButton = '<a href="' + URL_B2BCLASSIFIEDS_PATH + '/' + value + '.html"><span class="btn  btn-sm btn-primary">View</span></a>';
                    } else {
                        var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                        var $myButton = '<a id="viewproducts" target="_blank" href="' + URL_PRODUCTS_PATH + '/' + value + '.html"><span class="btn  btn-sm btn-primary">View</span></a>';
                    }
                    return $result.add($myButton)
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 2) {
                        var $myButton = '<span class="label  label-danger">Ignored</span>';
                    } else {
                        var $myButton = '<span class="label  label-danger">Deleted</span>'; //
                    }
                    return $result.add($myButton);
//                    return item.status;
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="btn pf-bt">Edited</span>';
                    return $result.add($myButton);
                }
            }
        }
    ];
}

//$(function () {
//    productsManageGrid(product_field, hashData);
//
//});
//function productsManageGrid(product_field, hashData) {

//    $("#products_manage_container").jsGrid("destroy");

//***********js grid table for product(includes view,edit,delete)******
$("#products_manage_container").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
//    pageLoading: true,
    pageButtonCount: 5,
    noDataContent: "No products found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
//            console.log(filter.pageSize);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/products',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {
//                console.log(response.products);
                d.resolve(response.products);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
//        if (hashData == 'edited') {
//            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid + '/edited';
//        } else {
//            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid;
//        }
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid + '/edited';
        } else if (hashData == 'pending') {
            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid + '/pending';
        } else if (hashData == 'deleted') {
            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid + '/ignored';
        } else if (hashData == 'approved') {
            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid + '/approved';
        } else {
            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid + '/pending';
        }
    },
    rowClick: function (args) {
        var $target = $(args.event.target);
        if ($target.closest("#viewproducts").length) {
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
//        if (hashData == 'approved') {
//            args.cancel = true;
//            var slug = args.item.slug;
//            if (mem_type == '4') {
//                window.location.href = URL_BSCLASSIFIEDS_PATH + '/' + slug + '.html';
//            } else if (mem_type == '5') {
//                window.location.href = URL_B2BCLASSIFIEDS_PATH + '/' + slug + '.html';
//            } else {
//                window.location.href = URL_PRODUCTS_PATH + '/' + slug + '.html';
//            }
//        } else {
//            args.cancel = true;
//            var editid = args.item.id;
//            if (hashData == 'edited') {
//                window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid + '/edited';
//            } else {
//                window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid;
//            }
////            window.location.href = URL_PROFILE_PATH + 'products/edit/' + editid;
//        }
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        var product_type = $('#mem_type').val();
        $.ajax({
            url: URL_API_BASE_PATH + '/productsdelete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
                if (hashData == 'edited' || hashData == 'approved') {
                    if (product_type === '5') {
                        $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/b2b-classifieds-product/remove?id=' + delid);
                    } else if (product_type === '4') {
                        $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/business-classifieds-product/remove?id=' + delid);
                    } else {
                        $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/product/remove?prod_id=' + delid);
                    }
                }
                window.location.href = URL_PROFILE_PATH + 'products#deleted';
                var url_path = URL_PROFILE_PATH + 'products#deleted';
                $("#load_products").load(url_path + " #load_products");
            }
        });
    },
//         onDataLoading: function(args) {
//        // cancel loading data if 'name' is empty
//        if(hashData== 'pending') {
//           fieldOption.edited_status.visible= false;
//        }
    // },
    fields: product_field
});
//*********js grid for halal products(includes view, edit, delete)*******
$("#halal_products_manage_container").jsGrid({
    height: "auto",
    width: "100%",
    inserting: true,
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
//    pageLoading: true,
    pageButtonCount: 5,
    noDataContent: "No halal products found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
//            console.log(filter.pageSize);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/halal-products',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {
//                console.log(response.products);
                d.resolve(response.products);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        var halal_products_id = args.item.halal_products_id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'halal-products/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'halal-products/edit/' + editid;
        }
    },
    rowClick: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        var halal_products_id = args.item.halal_products_id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'halal-products/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'halal-products/edit/' + editid;
        }

    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        var product_type = $('#mem_type').val();
        console.log(delid);
        $.ajax({
            url: URL_API_BASE_PATH + '/halal-products-delete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
                window.location.href = URL_PROFILE_PATH + 'halal-products#deleted';
                var url_path = URL_PROFILE_PATH + 'halal-products#deleted';
                $("#load_products").load(url_path + " #load_products");
            }
        });
    },
    fields: [
        {
            name: "image", title: "Product Image", align: "center", width: 70, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "name", title: "Product Name", align: "center", type: "text", autosearch: true, valueField: "name", textField: "name"},
        {name: "certification_file", title: "Certification No.", align: "center", type: "text", autosearch: true, valueField: "issued_company_name", textField: "description"},
        {name: "issued_by", title: "Issued By", align: "center", type: "text", autosearch: true, valueField: "issued_company_name", textField: "description"},
        {
            name: "valid_from", title: "Valid From", align: "center", type: "text", autosearch: true, itemTemplate: function (valid_from) {
                var dateAr = valid_from.split('-');
                var newDate = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0].slice(-4);
                return newDate;
            }
        },
        {
            name: "valid_to", title: "Valid To", align: "center", type: "text", autosearch: true, itemTemplate: function (valid_to) {
                var dateAr = valid_to.split('-');
                var newDate = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0].slice(-4);
                return newDate;
            }
        },
        {
            type: "control",
            align: "center",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete this Halal Product",
        }
    ]
});
//}
function removefields() {
//    $("#products_manage_container").jsGrid("reset");
//    $("#products_manage_container").jsGrid("fieldOption", "edited_status", "visible", false);
//    $("#products_manage_container").jsGrid("fieldOption", "slug", "visible", false);
//    // $("#products_manage_container").jsGrid("refresh");
}

function addfields() {
//    console.log('sdfds');
//    $("#products_manage_container").jsGrid("reset");
//    $("#products_manage_container").jsGrid("fieldOption", "edited_status", "visible", true);
//    $("#products_manage_container").jsGrid("fieldOption", "slug", "visible", true);

}
//************js grid table for tradeshow manage block**********
$("#tradeshow_manage_container").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    selecting: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No trade shows found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
//            console.log(filter.pageSize);
//            console.log(hashData);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            //var fromdate = $('#ewalletfrom_date').val();
            // var ewalletto_date = $('#ewalletto_date').val();
            $.ajax({
                url: URL_API_BASE_PATH + '/tradeshows',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                            //  fromdate: fromdate,
                            //  todate: ewalletto_date
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.products);
            });
            return d.promise();
        }
    },
    rowClick: function (args) {
        var $target = $(args.event.target);
        if ($target.closest("#viewtrade").length) {
            //console.log('sdfsdf');
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemEditing: function (args) {
        // console.log('fdsfds');
        args.cancel = true;
        var editid = args.item.id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'tradeshows/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'tradeshows/edit/' + editid;
        }
        //  window.location.href = URL_PROFILE_PATH + 'tradeshows/edit/' + editid;
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/tradeshowdelete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
//                console.log(data);
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
                if (hashData == 'edited' || hashData == 'approved') {
                    $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/tradeshow/remove?tshow_id=' + delid);
                }

                window.location.href = URL_PROFILE_PATH + 'tradeshows#deleted';
                var url_path = URL_PROFILE_PATH + 'tradeshows#deleted';
                $("#load_products").load(url_path + " #load_products");
            }

        });
    },
    fields: [
        {name: "title", title: "Event Title", align: "center", type: "text", autosearch: true, valueField: "title", textField: "title"},
        {name: "venue_details", align: "center", title: "Venue", type: "text", autosearch: true, valueField: "venue_details", textField: "venue_details"},
        {name: "from_date", align: "center", title: "From Date", type: "text", autosearch: true, valueField: "from_date", textField: "from_date"},
        {name: "to_date", align: "center", title: "To Date", type: "text", autosearch: true, valueField: "to_date", textField: "to_date"},
        {name: "updated_at", align: "center", title: "Last Updated At", type: "text", autosearch: true, valueField: "to_date", textField: "to_date"},
        {
            name: "To Date",
            type: "control",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete this Tradeshow",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        },
//        {
//            itemTemplate: function(value, item) {
//    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
//    var $myButton ='<a target="_blank" href="' + URL_TRADESHOW_PATH + '/' + item.slug + '_detailed' + item.id + '.html"><i class="fa fa-eye"></i></a>';
//    return $result.add($myButton);
//}
//       },
        {
            name: "slug", type: "button", editing: false, selecting: false, align: "center", title: "Status", itemTemplate: function (value, item) {

                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<a id="viewtrade" target="_blank" href="' + URL_TRADESHOW_PATH + '/' + value + '_detailed' + item.id + '.html"><span class="btn btn-sm btn-primary">View</span></a>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 3) {
                        var $myButton = '<span class="label label-danger">Deleted</span>';
                    } else {
                        var $myButton = '<span class="label label-danger">Ignored</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="label label-primary">Edited</span>';
                    return $result.add($myButton);
                }
                if (hashData == 'expired') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="label" style="background: #ff5722!important;">Expired</span>';
                    return $result.add($myButton);
                }
            }
        }
    ]
});
//****************js-grid for revenue*************
$("#revenue_reciepts").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: false,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No receipts found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            var d = $.Deferred();
            var fromdate = $('#ewalletfrom_date').val();
            var ewalletto_date = $('#ewalletto_date').val();
            $.ajax({
                url: URL_API_BASE_PATH + '/reciepts',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex,
                    fromdate: fromdate,
                    todate: ewalletto_date
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.reciepts);
            });
            return d.promise();
        }
    },
    fields: [
        {name: "particulars", title: "Particulars", align: "center", type: "text", autosearch: true, valueField: "title", textField: "title"},
        {name: "amount", align: "center", title: "Amount", type: "text", autosearch: true, valueField: "amount", textField: "amount"
//            ,itemTemplate: function (value) {

//                if(billing_country == 'in'){
//                return '<a href="' + URL_PROFILE_PATH + 'receiptdownloads/' + btoa(value) + '">Download</a>';
//            }else{
//
//            }
//        }
        },
        {name: "payment_mode", align: "center", title: "Payment Mode", type: "text", autosearch: true, valueField: "payment_mode", textField: "payment_mode"},
        {name: "date_time", align: "center", title: "Pain on", type: "text", autosearch: true, valueField: "date_time", textField: "date_time"},
        {name: "transaction_id", align: "center", type: "text", title: "Transaction ID"},
        {name: "payment_status", align: "center", type: "text", title: "Status", itemTemplate: function (value) {
                if (value == 1) {
                    return '<span class="label label-success">Paid</span>';
                } else if (value == 2) {
                    return '<span class="label label-danger" >Payment failed</span>';
                } else if (value == 3) {
                    return '<span class="label label-warning" >Payment cancelled</span>';
                } else if (value == 0) {
                    return '<span class="label label-warning" >Payment initiated</span>';
                }
            }
        },
        {name: "pay_id", width: 50, align: "center", title: "Receipt", itemTemplate: function (value) {
                return '<a target="_blank" href="' + URL_PROFILE_PATH + 'receiptdownloads/' + btoa(value) + '">Download</a>';
            }
        }

//        {
//            type: "control",
//            modeSwitchButton: true,
//            filtering: false,
//            sorting: true,
////            deleteButtonTooltip: "Delete  this Tradeshow"
//        }
//
    ]
});
String.prototype.capitalize = function () {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

//**************Js grid for service manage block(includes view,edit,delete)***********
$("#services_manage_container").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    selecting: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No services found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/services',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.products);
            });
            return d.promise();
        }
    },
    rowClick: function (args) {
        var $target = $(args.event.target);
        if ($target.closest("#viewtrade").length) {
            //console.log('sdfsdf');
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid + '/edited';
        } else if (hashData == 'pending') {
            window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid + '/pending';
        } else if (hashData == 'deleted') {
            window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid + '/ignored';
        } else if (hashData == 'approved') {
            window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid + '/approved';
        } else {
            window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid + '/pending';
        }
//        if (hashData == 'edited') {
//            window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid + '/edited';
//        } else {
//            window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid;
//        }
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/servicedelete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
//                console.log(data);
                $('#refresh-count-load-services').load(location.href + ' #refresh-count-load-services');
                if (hashData == 'edited' || hashData == 'approved') {
                    $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/service/remove?service_id=' + delid);
                }
                window.location.href = URL_PROFILE_PATH + 'services#deleted';
            }

        });
    },
    fields: [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {
            name: "name", title: "Name", align: "center", type: "text", autosearch: true, valueField: "name", textField: "name", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {

                    return item.name;
                } else {
                    return item.temp_name;
                }
            }
        },
        {
            name: "description", align: "center", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {
                    return item.description;
                } else {
                    return item.temp_description;
                }
            }
        },
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                if (item.last_update_at == '0000-00-00 00:00:00') {

                    return item.updated_at;
                } else {
                    return item.last_update_at;
                }
            }
        },
        {
            type: "control",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete  this Services",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        },
        {
            name: "slug", type: "button", editing: false, selecting: false, align: "center", title: "Status", itemTemplate: function (value, item) {
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else if (item.status == 10) {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    } else if (item.edited_status == 1) {
                        var $myButton = '<span class="label label-info">Edited</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<a id="viewtrade" target="_blank" href="' + URL_MAIN_PATH + '/services/' + item.company_slug + '/' + item.service_slug + '.html"><span class="btn btn-sm btn-primary">View</span></a>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 2) {
                        var $myButton = '<span class="label  label-danger">Ignored</span>';
                    } else {
                        var $myButton = '<span class="label  label-danger">Deleted</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="btn pf-bt">Edited</span>';
                    return $result.add($myButton);
                }
            }
        }
//
    ]
});
//*******js grid for e-wallet(hidded)**********
$("#ewallet_statement").jsGrid({
    height: "auto",
    width: "98%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No records found",
//    deleteConfirm: "Are you sure you want to delete this service?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/ewallet_statement',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.ewallet);
            });
            return d.promise();
        }
    },
//    onItemEditing: function (args) {
//        args.cancel = true;
//        var editid = args.item.id;
//        window.location.href = URL_PROFILE_PATH + 'services/edit/' + editid;
//    },
//    onItemDeleted: function (args) {
//        var delid = args.item.id;
//        $.ajax({
//            url: URL_API_BASE_PATH + '/servicedelete',
//            data: {
//                pageName: hashData,
//                deleteId: delid
//            },
//            type: "get",
//            success: function (data) {
//                console.log(data);
//            }
//
//        });
//    },
    fields: [
        {name: "datetime", title: "Date Time", align: "center", type: "text", autosearch: true, valueField: "datetime", textField: "datetime"},
        {name: "particulars", align: "center", title: "Particulars", type: "text", autosearch: true, valueField: "particulars", textField: "particulars"},
        {name: "debit", align: "center", title: "Debit", type: "text", autosearch: true, valueField: "debit", textField: "debit"},
        {name: "credit", align: "center", title: "Credit", type: "text", autosearch: true, valueField: "credit", textField: "credit"},
        {name: "balance", align: "center", title: "Balance", type: "text", autosearch: true, valueField: "balance", textField: "balance"},
//
    ]
});
//$(document).ready(function () {
//    if(hashData == 'approved'){
//        $('#article_manage').jsGrid('alterField', 'title', 'visible', true);
//    }else{
//        $('#article_manage').jsGrid('alterField', 'title', 'visible', false);
//    }
//
//});

//****************js-grid for article manage block***************
$("#article_manage").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No articles found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/articles',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.articles);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        window.location.href = URL_PROFILE_PATH + 'articles/edit/' + editid;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'articles/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'articles/edit/' + editid;
        }

    },
    rowClick: function (args) {
//        if (hashData == 'approved') {
//            args.cancel = true;
//            var page = args.item.page;
//            var str = page.split(',');
//            window.location.href = URL_MAIN_PATH + '/articles/' + str['0'] + '-' + str['1'] + '.html';
//        } else {
//            args.cancel = true;
//            var editid = args.item.id;
//            window.location.href = URL_PROFILE_PATH + 'articles/edit/' + editid;
//        }
        var $target = $(args.event.target);
        if ($target.closest("#viewarticles").length) {
            //console.log('sdfsdf');
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/delete-record',
            data: {
                pageName: hashData,
                deleteId: delid,
                table_name: 'articles',
                temptable_name: 'articles_temp',
                temptable_field: 'articles_id'
            },
            type: "get",
            success: function (data) {
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
                if (hashData == 'edited' || hashData == 'approved') {
                    $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/article/remove?id=' + delid);
                }
                window.location.href = URL_PROFILE_PATH + 'articles#deleted';
            }

        });
//        var url_path = URL_PROFILE_PATH + 'articles#deleted';
//        $("#load_promotion").load(url_path + "#load_promotion");
    },
    fields: [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "title", title: "Name", align: "center", type: "text", autosearch: true, valueField: "title", textField: "title"},
        {name: "description", align: "justify", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {
            type: "control",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete  this articles",
////            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }

        },
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                return item.updated_at;
            }
        },
        {
            name: "page", width: 40, align: "center", title: "Status", itemTemplate: function (value, item) {
                var str = value.split(',');
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    return '<a id="viewarticles" target="_blank" href="' + URL_MAIN_PATH + '/articles/' + str['0'] + '-' + str['1'] + '.html"><span class="btn pf-bt">View</span></a>';
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="label label-info">Edited</span>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 3) {
                        var $myButton = '<span class="label label-danger">Deleted</span>';
                    } else {
                        var $myButton = '<span class="label label-danger">Ignored</span>';
                    }
                    return $result.add($myButton);
                }
            }

        }
//        {
//            name: "edited_status", width: 30, align: "center", title: "", itemTemplate: function (value) {
//                if (hashData == 'approved' && value == '1') {
//                    return '<label class="label label-warning">Already Edited</label>';
//                } else {
//
//                }
//            }
//        }
    ]
});
//***********js grid for profile message***********


$(function () {

    if (hashData == 'inbox' || hashData == '') {
        message_container = [
            {
                headerTemplate: function () {
                    return $("<input>").attr("type", "checkbox").attr("class", "msgCheckAll").on("change", function () {
                        if ($(this).prop('checked')) {
                            selectedItems = [];
                            $('input.msgCheckbox').each(function () {
                                selectedItems.push($(this).data('id'));
                                // console.log(selectedItems);
                            });
                        } else {
                            selectedItems = [];
                        }
                        $("input.msgCheckbox").prop('checked', $(this).prop("checked"));
                    });
                },
                itemTemplate: function (_, item) {
//                    console.log(item.thread_id);
//                    if ($('.msgCheckAll').prop('checked')) {
//                        console.log('chk');
//                         $("input.msgCheckbox").prop('checked', 'checked');
//                    } else {
//                        console.log('not chk');
//
//                    }

                    return $("<input>").attr("type", "checkbox").attr("class", "msgCheckbox").attr('data-id', item.thread_id)
                            .prop("checked", $.inArray(item, selectedItems) > -1)
                            .on("change", function () {
                                $(this).is(":checked") ? selectItem(item) : unselectItem(item);
                                //  unselectItem(item);
                            })

                },
                align: "center",
                sorting: false,
                editing: false,
                sorter: "number",
            },
            {
                name: 'name', title: 'From', sorting: false, itemTemplate: function (_, item) {
//                    console.log(item);
                    var UnreadClass = "";
                    var ReplyClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    if (hashData == 'inbox') {
                        if (item.reply == 1) {
                            ReplyClass = "msg-unread";
                        }
                    }

                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '" class="' + UnreadClass + ' ' + ReplyClass + '" >' + item.name + '</a>'
                }
            },
            {
                name: 'subject', title: 'Subject', sorting: false, itemTemplate: function (_, item) {
                    var UnreadClass = "";
                    var ReplyClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    if (hashData == 'inbox') {
                        if (item.reply == 1) {
                            ReplyClass = "msg-unread";
                        }
                    }
                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '" class="' + UnreadClass + ' ' + ReplyClass + '">' + item.subject + '</a>'
                }
            },
            {
                name: 'created_at', sorting: false, title: 'Date', itemTemplate: function (_, item) {
                    var UnreadClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '"  class="' + UnreadClass + '">' + item.created_at + '</a>'
                }
            },
            {
                type: 'control',
                title: 'Action',
                editButton: false,
                modeSwitchButton: true,
                filtering: false,
                sorting: false,
                editing: true,
                deleteButtonTooltip: 'Delete  this message',
            }

        ]
    } else if (hashData == 'sent') {
        message_container = [
            {
                headerTemplate: function () {
                    return $("<input>").attr("type", "checkbox").attr("class", "msgCheckAll").on("change", function () {
                        if ($(this).prop('checked')) {
                            selectedItems = [];
                            $('input.msgCheckbox').each(function () {
                                selectedItems.push($(this).data('id'));
                                // console.log(selectedItems);
                            });
                        } else {
                            selectedItems = [];
                        }
                        $("input.msgCheckbox").prop('checked', $(this).prop("checked"));
                    });
                },
                itemTemplate: function (_, item) {

                    return $("<input>").attr("type", "checkbox").attr("class", "msgCheckbox").attr('data-id', item.thread_id)
                            .prop("checked", $.inArray(item, selectedItems) > -1)
                            .on("change", function () {
                                $(this).is(":checked") ? selectItem(item) : unselectItem(item);
                                //  unselectItem(item);
                            })

                },
                align: "center",
                sorting: false,
                editing: false,
                sorter: "number",
            },
            {
                name: 'name', title: 'To', sorting: false, itemTemplate: function (_, item) {
//                    console.log(item);
                    var UnreadClass = "";
                    var ReplyClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    if (hashData == 'inbox') {
                        if (item.reply == 1) {
                            ReplyClass = "msg-unread";
                        }
                    }

                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '" class="' + UnreadClass + ' ' + ReplyClass + '" >' + item.name + '</a>'
                }
            },
            {
                name: 'subject', title: 'Subject', sorting: false, itemTemplate: function (_, item) {
                    var UnreadClass = "";
                    var ReplyClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    if (hashData == 'inbox') {
                        if (item.reply == 1) {
                            ReplyClass = "msg-unread";
                        }
                    }
                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '" class="' + UnreadClass + ' ' + ReplyClass + '">' + item.subject + '</a>'
                }
            },
            {
                name: 'created_at', sorting: false, title: 'Date', itemTemplate: function (_, item) {
                    var UnreadClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '"  class="' + UnreadClass + '">' + item.created_at + '</a>'
                }
            },
            {
                type: 'control',
                title: 'Action',
                editButton: false,
                modeSwitchButton: true,
                filtering: false,
                sorting: false,
                editing: true,
                deleteButtonTooltip: 'Delete  this message',
            }

        ]
    } else {
        message_container = [
            {
                headerTemplate: function () {
                    return $("<input>").attr("type", "checkbox").attr("class", "msgCheckAll").on("change", function () {
                        if ($(this).prop('checked')) {
                            selectedItems = [];
                            $('input.msgCheckbox').each(function () {
                                selectedItems.push($(this).data('id'));
                                // console.log(selectedItems);
                            });
                        } else {
                            selectedItems = [];
                        }
                        $("input.msgCheckbox").prop('checked', $(this).prop("checked"));
                    });
                },
                itemTemplate: function (_, item) {

                    return $("<input>").attr("type", "checkbox").attr("class", "msgCheckbox").attr('data-id', item.thread_id)
                            .prop("checked", $.inArray(item, selectedItems) > -1)
                            .on("change", function () {
                                $(this).is(":checked") ? selectItem(item) : unselectItem(item);
                                //  unselectItem(item);
                            })

                },
                align: "center",
                sorting: false,
                editing: false,
                sorter: "number",
            },
            {
                name: 'name', title: 'Name', sorting: false, itemTemplate: function (_, item) {
//                    console.log(item);
                    var UnreadClass = "";
                    var ReplyClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    if (hashData == 'inbox') {
                        if (item.reply == 1) {
                            ReplyClass = "msg-unread";
                        }
                    }

                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '" class="' + UnreadClass + ' ' + ReplyClass + '" >' + item.name + '</a>'
                }
            },
            {
                name: 'subject', title: 'Subject', sorting: false, itemTemplate: function (_, item) {
                    var UnreadClass = "";
                    var ReplyClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    if (hashData == 'inbox') {
                        if (item.reply == 1) {
                            ReplyClass = "msg-unread";
                        }
                    }
                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '" class="' + UnreadClass + ' ' + ReplyClass + '">' + item.subject + '</a>'
                }
            },
            {
                name: 'created_at', sorting: false, title: 'Date', itemTemplate: function (_, item) {
                    var UnreadClass = "";
                    if (hashData != 'sent') {
                        if (item.read_status == 0) {
                            UnreadClass = "msg-unread";
                        }
                    }
                    return '<a href="' + URL_PROFILE_PATH + "messages/view/" + item.thread_id + "?type=" + hashData + '"  class="' + UnreadClass + '">' + item.created_at + '</a>'
                }
            },
            {
                type: 'control',
                title: 'Action',
                editButton: false,
                modeSwitchButton: true,
                filtering: false,
                sorting: false,
                editing: true,
                deleteButtonTooltip: 'Delete  this message',
            }

        ]
    }

    var selectedItems = [];
    $("#messages_container").jsGrid({
        height: "auto",
        width: "100%",
        filtering: false,
        editing: false,
        sorting: true,
        paging: true,
        autoload: true,
        pageSize: 10,
        pageLoading: true,
        pageButtonCount: 5,
        noDataContent: "No messages found",
        deleteConfirm: "Are you sure want to delete this?",
        controller: {
            loadData: function (filter) {
                //uset items starts
                var k = selectedItems.length;
                if (k != -1) {
                    selectedItems.splice(k, 1);
                }
                $.grep(selectedItems, function (i) {

                    selectedItems.pop(selectedItems);
                });
                //uset items ends

                // console.log(filter);
                var d = $.Deferred();
                var hashValue = location.hash;
                hashData = hashValue.replace(/^#/, '');
                if (hashData == '') {
                    hashData = 'inbox';
                }

                $('.tabName').html(ucwords(hashData));
                $('#moveSelectedToSpam').show();
                $('#moveSelectedToNotSpam').hide();
                $('#moveSelectedToTrashForEver').hide();
                $('.movebuttons').hide();
                if (typeof hashData != 'undefined' && hashData == 'inbox') {
                    $('#moveSelectedToTrash').show();
                    msgType = 'inbox';
                }
                if (typeof hashData != 'undefined' && hashData == 'spam') {
                    $('#moveSelectedToSpam').hide();
                    $('#moveSelectedToNotSpam').show();
                    $('#moveSelectedToTrashForEver').show().text('Move To Trash');
                    $('#moveSelectedToTrash').hide();
                }
                if (typeof hashData != 'undefined' && hashData == 'sent') {
                    $('#moveSelectedToSpam').hide();
                    $('#moveSelectedToTrash').show();
                    // console.log('dfsdf');

                }
                if (typeof hashData != 'undefined' && hashData == 'trash') {
                    $('#moveSelectedToTrash').hide();
                    $('#moveSelectedToSpam').hide();
                    $('#moveSelectedToTrashForEver').show().text('Delete Forever');
                }
                var msgType = 'inbox';
                if (typeof hashData != 'undefined' && hashData == '') {
                    msgType = hashData;
                }

                $.ajax({
                    url: URL_API_BASE_PATH + '/messages',
                    data: {
                        msgType: hashData,
                        pageSize: filter.pageSize,
                        pageIndex: filter.pageIndex
                    },
                    dataType: "json"

                }).done(function (response) {
                    if (hashData === 'inbox') {
                        $('.jsgrid-grid-header .jsgrid-table tr th:nth-child(2)').text('From');
                    } else if (hashData === 'sent') {
                        $('.jsgrid-grid-header .jsgrid-table tr th:nth-child(2)').text('To');
                    } else if (hashData === 'trash') {
                        $('.jsgrid-grid-header .jsgrid-table tr th:nth-child(2)').text('Name');
                    } else if (hashData === 'spam') {
                        $('.jsgrid-grid-header .jsgrid-table tr th:nth-child(2)').text('Name');
                    }
                    $('.' + hashData + 'MessageCount').html(response.itemsCount);
                    if (response['itemsCount'] > 0) {
                        $('.movebuttons').show();
                    }

                    d.resolve(response);
                });
                return d.promise();
            }
        },
        onItemEditing: function (args) {
            args.cancel = true;
            // console.log(args);
            var editid = args.item.thread_id;
            window.location.href = URL_PROFILE_PATH + 'messages/view/' + editid;
        },
        onItemDeleted: function (args) {
            var itemId = args.item.thread_id;
            $.ajax({
                url: URL_PROFILE_PATH + 'messages/moveToTrash',
                data: {
                    pageName: hashData,
                    ids: itemId

                },
                type: "get",
                success: function (data) {
//                      console.log('sdfsdffd');

                    var $grid = $("#messages_container");
                    $grid.jsGrid("option", "pageIndex", 1);
                    $grid.jsGrid("loadData");
                    selectedItems = [];
                    $('#refresh-count-load').load(location.href + ' #refresh-count-load');

                }

            });
        },
        fields: message_container

    });


    var selectItem = function (item) {

        selectedItems.push(item.thread_id);
        if (selectedItems.length === 10) {
            $("input.msgCheckAll").prop('checked', true);
        }
        console.log(selectedItems);
    };
    var unselectItem = function (item) {
        console.log(item.thread_id);
        var k = selectedItems.indexOf(item.thread_id);
        if (k != -1) {
            selectedItems.splice(k, 1);
        }
        selectedItems = $.grep(selectedItems, function (i) {

            return i !== parseInt(item.thread_id, 10);
        });
        $("input.msgCheckAll").prop('checked', false);
    };
    $('#moveSelectedToTrash').on('click', function () {
        bulkMessageAction(selectedItems, hashData, 'moveToTrash');
    });
    $('#moveSelectedToSpam').on('click', function () {
        bulkMessageSpamAction(selectedItems, hashData, 'moveToSpam');
    });
    $('#moveSelectedToNotSpam').on("click", function () {
        bulkMessageNotSpamAction(selectedItems, hashData, 'moveToNotSpam');
    });
    $('#moveSelectedToTrashForEver').on("click", function () {
        bulkMessageAction(selectedItems, hashData, 'moveToTrash');
    });


    function bulkMessageAction(selectedItems, hashData, urlPath) {


        if (!selectedItems.length) {
            alert('No messages choosen to delete!');
            return;
        }
        var msgstr;
        if (selectedItems.length > 1) {
            msgstr = 'messages';
        } else {
            msgstr = 'message';
        }
        if (!confirm("Are you sure to delete " + selectedItems.length + " " + msgstr + "?"))
            return;
        $.ajax({
            url: URL_PROFILE_PATH + 'messages/' + urlPath,
            data: {
                pageName: hashData,
                ids: selectedItems
            },
            type: "get",
            success: function (data) {
                //   console.log(data);
                $(".msgCheckAll").prop("checked", false);
                var $grid = $("#messages_container");
                $grid.jsGrid("option", "pageIndex", 1);
                $grid.jsGrid("loadData");
                //uset items starts
                var k = selectedItems.length;
                if (k != -1) {
                    selectedItems.splice(k, 1);
                }
                $.grep(selectedItems, function (i) {

                    selectedItems.pop(selectedItems);
                });
                //uset items ends
                selectedItems = [];
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
            }
        });
    }
    function bulkMessageSpamAction(selectedItems, hashData, urlPath) {

        if (!selectedItems.length) {
            alert('No messages choosen to spam!');
            return;
        }
        if (!selectedItems.length)
            return;
        $.ajax({
            url: URL_PROFILE_PATH + 'messages/' + urlPath,
            data: {
                pageName: hashData,
                ids: selectedItems
            },
            type: "get",
            success: function (data) {
//                console.log(data);
                $(".msgCheckAll").prop("checked", false);
                var $grid = $("#messages_container");
                $grid.jsGrid("option", "pageIndex", 1);
                $grid.jsGrid("loadData");
                //uset items starts
                var k = selectedItems.length;
                if (k != -1) {
                    selectedItems.splice(k, 1);
                }
                $.grep(selectedItems, function (i) {

                    selectedItems.pop(selectedItems);
                });
                //uset items ends

                selectedItems = [];
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
//                $(window).load(location.href);



            }
        });
    }
    function bulkMessageNotSpamAction(selectedItems, hashData, urlPath) {

        if (!selectedItems.length) {
            alert('No messages choosen to not spam!');
            return;
        }
        if (!selectedItems.length)
            return;
        $.ajax({
            url: URL_PROFILE_PATH + 'messages/' + urlPath,
            data: {
                pageName: hashData,
                ids: selectedItems
            },
            type: "get",
            success: function (data) {
//                console.log(data);
                $(".msgCheckAll").prop("checked", false);
                var $grid = $("#messages_container");
                $grid.jsGrid("option", "pageIndex", 1);
                $grid.jsGrid("loadData");
                //uset items starts
                var k = selectedItems.length;
                if (k != -1) {
                    selectedItems.splice(k, 1);
                }
                $.grep(selectedItems, function (i) {

                    selectedItems.pop(selectedItems);
                });
                //uset items ends
                selectedItems = [];
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
            }
        });
    }
});
function ucwords(str) {
    return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
        return $1.toUpperCase();
    });
}
//***********js grid for sharelinks manage(hidded)**************
$("#sharelink_manage").jsGrid({
    height: "auto",
    width: "100%",
    selecting: false,
    filtering: false,
    editing: false,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No share links found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/business-classifieds/manage-shareLinks',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.share_links);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        var memtype = args.item.memtype;
        if (memtype == 5)
            window.location.href = URL_PROFILE_PATH + 'b2b-classifieds/edit/' + editid;
        else
            window.location.href = URL_PROFILE_PATH + 'business-classifieds/edit/' + editid;
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        var memtype = args.item.memtype;
        if (memtype == 5)
            var url = URL_PROFILE_PATH + 'b2b-classifieds/delete_share';
        else
            var url = URL_PROFILE_PATH + 'business-classifieds/delete_share';
        $.ajax({
            url: url,
            data: {
                pageName: hashData,
                deleteId: delid,
                table_name: 'classifieds_sharelinks',
            },
            type: "get",
            success: function (data) {
                $("#load_loadcount").load(location.href + " #load_loadcount");
            }

        });
    },
    fields: [
        {name: "site_name", title: "Site Name", align: "center", type: "text", autosearch: true, valueField: "site_name", textField: "site_name"},
        {name: "site_link", title: "Site Link", align: "center", type: "text", autosearch: true, valueField: "site_link", textField: "site_link"},
        {name: "back_link", title: "Back Link Code", align: "center", type: "text", autosearch: true, valueField: "back_link", textField: "back_link"},
        {
            type: "control",
            editButton: false,
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete  this share Links",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        }
//
    ]
});
//***********js grid table for press release manage block**********
$("#press_manage").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No press releases found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/press_releases',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {
//console.log(response);
                d.resolve(response.press_release);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
//        console.log(editid);
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'press_releases/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'press_releases/edit/' + editid;
        }
    },
    rowClick: function (args) {
//        if (hashData == 'approved') {
//            args.cancel = true;
//            var page = args.item.page;
//            var str = page.split(',');
//            window.location.href = URL_MAIN_PATH + '/press-release/' + str['0'] + '-' + str['1'] + '.html';
//        } else {
//            args.cancel = true;
//            var editid = args.item.id;
//            window.location.href = URL_PROFILE_PATH + 'press_releases/edit/' + editid;
//        }
        var $target = $(args.event.target);
        if ($target.closest("#viewpressrelease").length) {
            //console.log('sdfsdf');
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/delete-record',
            data: {
                pageName: hashData,
                deleteId: delid,
                table_name: 'press_release',
                temptable_name: 'press_release_temp',
                temptable_field: 'press_release_id'
            },
            type: "get",
            success: function (data) {
//                console.log(data);
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
            }

        });
        window.location.href = URL_PROFILE_PATH + 'press_releases#deleted';
//        var url_path = URL_PROFILE_PATH + 'press_releases#deleted';
//        $("#load_promotion").load(url_path + "#load_promotion");
    },
    fields: [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "title", title: "Name", align: "center", type: "text", autosearch: true, valueField: "title", textField: "title"},
        {name: "description", align: "justify", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                return item.updated_at;
            }
        },
        {
            type: "control",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete  this Press Release",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        },
        {
            name: "page", width: 30, align: "center", title: "Status", itemTemplate: function (value, item) {
                var str = value.split(',');
                // console.log(hashData);
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    return '<a id="viewpressrelease" target="_blank" href="' + URL_MAIN_PATH + '/press-release/' + str['0'] + '-' + str['1'] + '.html"><span class="btn btn-sm btn-primary">View</span></a>';
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="btn pf-bt">Edited</span>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 3) {
                        var $myButton = '<span class="pf-bt btn">Deleted</span>';
                    } else {
                        var $myButton = '<span class="pf-bt btn">Ignored</span>';
                    }
                    return $result.add($myButton);
                }
            }
        }
//        {
//            name: "edited_status", width: 30, align: "center", title: "", itemTemplate: function (value) {
//                if (hashData == 'approved' && value == '1') {
//                    return '<label class="label label-warning">Already Edited</label>';
//                } else {
//
//                }
//            }
//        }



    ]
});
//********js grid for news manage block********
$("#hotnews_manage").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No news found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/hotnews',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.news);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'hotnews/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'hotnews/edit/' + editid;
        }
    },
    rowClick: function (args) {
//        if (hashData == 'approved') {
//            args.cancel = true;
//            var page = args.item.page;
//            var str = page.split(',');
//            window.location.href = URL_MAIN_PATH + '/hotnews/' + str['0'] + '-' + str['1'] + '.html';
//        } else {
//            args.cancel = true;
//            var editid = args.item.id;
//            window.location.href = URL_PROFILE_PATH + 'hotnews/edit/' + editid;
//        }
        var $target = $(args.event.target);
        if ($target.closest("#viewhotnews").length) {
            //console.log('sdfsdf');
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/delete-record',
            data: {
                pageName: hashData,
                deleteId: delid,
                table_name: 'news',
                temptable_name: 'news_temp',
                temptable_field: 'news_id'
            },
            type: "get",
            success: function (data) {
//                console.log(data);
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
            }
        });
        window.location.href = URL_PROFILE_PATH + 'hotnews#deleted';
//        var url_path = URL_PROFILE_PATH + 'hotnews#deleted';
//        $("#load_promotion").load(url_path + "#load_promotion");

    },
    fields: [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "title", title: "Name", align: "center", type: "text", autosearch: true, valueField: "title", textField: "title"},
        {name: "description", align: "justify", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                return item.updated_at;
            }
        },
        {
            type: "control",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete  this News",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        },
        {
            name: "page", width: 50, type: "button", editing: false, selecting: false, align: "center", title: "Status", itemTemplate: function (value, item) {
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    var str = value.split(',');
                    return '<a id="viewhotnews" target="_blank" href="' + URL_MAIN_PATH + '/hotnews/' + str['0'] + '-' + str['1'] + '.html"><span class="btn pf-bt">View</span></a>';
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="btn pf-bt">Edited</span>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 3) {
                        var $myButton = '<span class="btn pf-bt">Deleted</span>';
                    } else {
                        var $myButton = '<span class="btn pf-bt">Ignored</span>';
                    }
                    return $result.add($myButton);
                }
            }
        }
//        {
//            name: "edited_status", width: 30, align: "center", title: "", itemTemplate: function (value) {
//                if (hashData == 'approved' && value == '1') {
//                    return '<label class="label label-warning">Already Edited</label>';
//                } else {
//
//                }
//            }
//        }

    ]
});
//************js grid table for blog manage block************
$("#blog_manage").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No blogs found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/blog',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.blog);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'blog/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'blog/edit/' + editid;
        }
    },
    rowClick: function (args) {
//        if (hashData == 'approved') {
//            args.cancel = true;
//            var page = args.item.page;
//            var str = page.split(',');
//            window.location.href = URL_BLOGPATH + '/' + str['2'] + '/user/show/' + str['1'] + '/' + str['0'];
//        } else {
//            args.cancel = true;
//            var editid = args.item.id;
//            window.location.href = URL_PROFILE_PATH + 'blog/edit/' + editid;
//        }
        var $target = $(args.event.target);
        if ($target.closest("#viewblog").length) {
            //console.log('sdfsdf');
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/delete-record',
            data: {
                pageName: hashData,
                deleteId: delid,
                table_name: 'blog_posts',
                temptable_name: 'blog_posts_temp',
                temptable_field: 'blog_posts_id'
            },
            type: "get",
            success: function (data) {
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
                if (hashData == 'edited' || hashData == 'approved') {
                    $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/blog/remove?id=' + delid);
                }

                window.location.href = URL_PROFILE_PATH + 'blog#deleted';
            }

        });
//        var url_path = URL_PROFILE_PATH + 'blog#deleted';
//         $("#load_promotion").load('#load_promotion',"#load_promotion");
    },
    fields: [
        {
            name: "blog_image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "title", title: "Name", align: "center", type: "text", autosearch: true, valueField: "title", textField: "title"},
        {name: "description", align: "justify", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {
            name: "Action",
            type: "control",
            title: "Action",
            modeSwitchButton: true,
            filtering: false,
            sorting: false,
            deleteButtonTooltip: "Delete  this blog",
        },
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                return item.updated_at;
            }
        },
        {
            name: "page", width: 40, align: "center", title: "Status", itemTemplate: function (value, item) {
                var str = value.split(',');
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    return '<a id="viewblog" target="_blank" href="' + URL_BLOGPATH + '/' + str['2'] + '/user/show/' + str['1'] + '/' + str['0'] + '"><span class="btn pf-bt">View</span></a>';
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="label label-info">Edited</span>';
                    return $result.add($myButton);
                }
                if (hashData == 'draft') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="label label-primary">Drafted</span>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 2) {
                        var $myButton = '<span class="label label-danger">Ignored</span>';
                    } else {
                        var $myButton = '<span class="label label-danger">Deleted</span>';
                    }
                    return $result.add($myButton);
                }

            }
        }
//        {
//            name: "edited_status", width: 30, align: "center", title: "", itemTemplate: function (value) {
//                if (hashData == 'approved' && value == '1') {
//                    return '<label class="label label-warning">Already Edited</label>';
//                } else {
//
//                }
//            }
//        }

    ]
});
//********js grid for business classified product manage block(hidded)********
$("#showbscproducttable").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No " + hashData.substr(0, 1).toUpperCase() + hashData.substr(1) + " product found",
    deleteConfirm: "Are you sure want to delete this product?",
    controller: {
        loadData: function (filter) {
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/business-classifieds/products',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {
                d.resolve(response.products);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        window.location.href = URL_PROFILE_PATH + 'business-classifieds/products?edit=' + editid + '#' + hashData;
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/business-classifieds/productdelete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
            }

        });
    },
    fields: [
        {title: 'Name', name: "productname", align: "center", type: "text"},
        {title: 'Image', name: "imgname", sorting: false, align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img class="img-responsive" src="' + path + '"/>';
            }
        },
        {title: 'Categories', name: "category_details", width: 30, itemTemplate: function (value) {
                var obj = JSON.parse(value);
                var category = obj.category;
                var showcat;
                var showsubcat;
                showcat = '<b>Category Name</b><p>' + category.name + '</p>';
                showsubcat = '<b>Sub Categories</b>';
                $.each(obj.subcategory, function (i, item) {
                    showsubcat += '<p>' + item.name + '</p>';
                });
                return showcat + showsubcat;
            }
        },
        {title: "Description", name: "description", type: "text", width: 200},
        {type: "control", deleteButtonTooltip: "Delete  this Product",
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }}
        }
    ]
});
//***********js grid table for offer manage block(hidded)******
$("#selloffers_manage").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    selecting: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No  sell offers found",
    deleteConfirm: "Are you sure want to delete this selloffer?",
    controller: {
        loadData: function (filter) {
//            console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/selloffers',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.selloffers);
            });
            return d.promise();
        }
    },
    rowClick: function (args) {
        var $target = $(args.event.target);
        if ($target.closest("#viewselloffer").length) {
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'selloffers/edit/' + editid + '/edited';
        } else {
            window.location.href = URL_PROFILE_PATH + 'selloffers/edit/' + editid;
        }

    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/sellofferdelete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
            }

        });
    },
    fields: [
        {
            name: "photo", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "name", title: "Name", align: "center", type: "text", autosearch: true, valueField: "name", textField: "name"},
        {name: "description", align: "center", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {
            type: "control",
            deleteButtonTooltip: "Delete this Selloffer"
//            headerTemplate: function () {
//                return $("<span>").attr("type", "text").text("options");
//
//            }
        },
        {
            name: "slug", type: "button", editing: false, selecting: false, align: "center", title: "Status", itemTemplate: function (value, item) {
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<a id="viewselloffer" target="_blank" href="' + URL_SELLOFFERS_PATH + '/' + value + '.html"><span class="btn pf-bt">View</span></a>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 3) {
                        var $myButton = '<span class="btn pf-bt">Deleted</span>';
                    } else {
                        var $myButton = '<span class="btn pf-bt">Ignored</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="btn pf-bt">Edited</span>';
                    return $result.add($myButton);
                }
            }
        }
    ]
});
//*****js grid for buying need manage block*******
$("#buyingneeds_manage_container").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
//    pageLoading: true,
    noDataContent: "No buyer requirements found",
    deleteConfirm: "Are you sure want to delete this Buyer Requirements?",
    controller: {
        loadData: function (filter) {
//            console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/buyingneeds',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.buyingneeds);
            });
            return d.promise();
        }
    },
    rowClick: function (args) {
        var $target = $(args.event.target);
        if ($target.closest("#viewbuyingneeds").length) {
            return false;
        }

        // otherwise handle row click
        if (this.editing) {
            this.editItem($target.closest("tr"));
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        if (hashData == 'edited') {
            window.location.href = URL_PROFILE_PATH + 'buyingneeds/edit/' + editid + '/edited';
        } else if (hashData == 'pending') {
            window.location.href = URL_PROFILE_PATH + 'buyingneeds/edit/' + editid + '/pending';
        } else if (hashData == 'deleted') {
            window.location.href = URL_PROFILE_PATH + 'buyingneeds/edit/' + editid + '/ignored';
        } else if (hashData == 'approved') {
            window.location.href = URL_PROFILE_PATH + 'buyingneeds/edit/' + editid + '/approved';
        } else {
            window.location.href = URL_PROFILE_PATH + 'buyingneeds/edit/' + editid + '/pending';
        }
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/buyingneedsdelete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
                if (hashData == 'edited' || hashData == 'approved') {
                    $("#url_loder").load(URL_API_BIZ_SEARCH_PATH + '/buy-need/remove?buyneed_id=' + delid);
                }
                window.location.href = URL_PROFILE_PATH + 'buyingneeds#deleted';
                var url_path = URL_PROFILE_PATH + 'buyingneeds#deleted';
                $("#load_buyingneeds").load(url_path + " #load_buyingneeds");
            }
        });
    },
    fields: [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
//                    console.log(path);
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {
            name: "name", title: "Name", align: "center", type: "text", autosearch: true, valueField: "name", textField: "name", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {

                    return item.name;
                } else {
                    return item.temp_name;
                }
            }
        },
        {
            name: "description", align: "center", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                if (item.edited_status == 0) {
                    return item.description;
                } else {
                    return item.temp_description;
                }
            }
        },
        {
            name: "updated_at", align: "center", title: "Last Updated at", type: "text", autosearch: true, valueField: "description", textField: "description", itemTemplate: function (__, item) {
                if (item.last_update_at == '0000-00-00 00:00:00') {

                    return item.updated_at;
                } else {
                    return item.last_update_at;
                }
            }
        },
        {
            type: "control",
            deleteButtonTooltip: "Delete this Buying needs"

        },
        {
            name: "slug", type: "button", editing: false, selecting: false, align: "center", width: 50, title: "Status", itemTemplate: function (value, item) {
                if (hashData == 'pending' || hashData == '') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 0) {
                        var $myButton = '<span class="label label-warning">Pending</span>';
                    } else if (item.status == 10) {
                        var $myButton = '<span class="label label-primary">Posponed</span>';
                    } else if (item.edited_status == 1) {
                        var $myButton = '<span class="label label-info">Edited</span>';
                    }
                    return $result.add($myButton);
                }
                if (hashData == 'approved') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<a id="viewbuyingneeds" target="_blank" href="' + URL_BUYINGNEED_PATH + '/' + value + '.html"><span class="btn btn-sm btn-primary">View</span></a>';
                    return $result.add($myButton);
                }
                if (hashData == 'edited') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    var $myButton = '<span class="label label-info">Edited</span>';
                    return $result.add($myButton);
                }
                if (hashData == 'deleted') {
                    var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
                    if (item.status == 3) {
                        var $myButton = '<span class="label  label-danger">Deleted</span>';
                    } else {
                        var $myButton = '<span class="label  label-danger">Ignored</span>';
                    }
                    return $result.add($myButton);
                }
            }
        }
    ]
});


/**
 *
 *  add specification in add product form
 */
var clicked = false;
function specification(id, inc, id1, rid) {
    if (clicked === false) {
        clicked = true;
        var inc1 = +inc + +1;
        var inc2 = +inc - +1;
        var cc, parentiddis, par;
        var lastid = $('#prodctspecdev').children().last().attr('id');
        var lastidnum = lastid.substr(lastid.indexOf("_") + 1);
        var numItems = $('.addparentdiv').length;
        if (numItems == 1 && id == 'remove-spec') {
//        console.log('hi');
//        $('#' + id1 + inc).show();
            clicked = false;
            $("#gen_spec_function" + inc).select2("val", "");
            $('#gen_spec' + inc).val('');
            $('#remove-spec_' + inc).hide();
        } else if (id == 'add-more-spec') {
            cc = +lastidnum + +1;
//        if (numItems == 10) {
//            $('#' + id + cc).hide();
//        }
//        $('#' + id + lastidnum).prop('disabled', true);
//        console.log(cc);
//        console.log(lastidnum);
            $.ajax({
                type: 'post',
                url: '/profile/products/productspec',
                data: {spec: cc},
                dataType: 'html',
                success: function (output)
                {
                    $('#' + id + inc).hide();
                    $('#remove-spec_' + inc).show();
                    $('#prodctspecdev').append(output);
                    if (cc == 10) {
                        $('#' + id + cc).hide();
                    }
                    clicked = false;
                    $(function () {
                        $('.addproducttagspecfic').select2({
                            tags: true,
                            selectOnBlur: true,
//                        selectOnClose: true,
                            placeholder: 'e.g red',
                            tokenSeparators: [',', ';', '\t', '\n'],
                            maximumSelectionLength: 10
                        }).on('select2:open', function (e) {
                            selectOnTab(e);
                        });
                    });
                }

            });

        } else if ((id == 'remove-spec') && numItems != 1) {
//        parentiddis = 'remove-spec_' + inc;
            clicked = false;
            parentiddis = $('#remove-spec_' + inc).parent().prev().find('.removespecshow').attr('id');
            $('#' + id1 + inc).remove();
            par = parentiddis.substr(parentiddis.indexOf("_") + 1);
            $('#' + rid + inc2).show();
            if ($('#add-more-spec' + lastidnum).is(':visible')) {
                $('#add-more-spec' + par).hide();
            } else {
                $('#add-more-spec' + par).show();
            }
            $('#' + id + inc).hide();
        }
//    if ((id == 'add-more-spec') && (numItems > 5)) {
//        $('#hide_addspec').hide();
//        inc++;
////        console.log('#add-more-spec'+inc);
//        $('#add-more-spec' + inc).addClass('hidden');
//    }
    }
}
/**
 *
 * end add specification
 */
//***********add company video************
function companyvideo(id, inc, id1, rid) {
    var inc1 = +inc + +1;
    var inc2 = +inc - +1;
    var cc, parentiddis, par;
    var lastid = $('#company_div').children().last().attr('id');
//    console.log($('#company_div').children().last().attr('id'));
    var lastidnum = lastid.substr(lastid.indexOf("_") + 1);
    var numItems = $('.addvideodiv').length;
//    console.log(numItems);
    if (numItems == 1 && id == 'remove-video') {
        $('#remove-video_' + inc).hide();
    } else if (id == 'add-more-video') {
        cc = +lastidnum + +1;
        $.ajax({
            type: 'post',
            url: '/profile/company_profile/companyvideo',
            data: {spec: cc},
            dataType: 'html',
            success: function (output)
            {
//                console.log(inc);
                $('#' + id + inc).hide();
                $('#remove-video_' + inc).show();
                $('#company_div').append(output);
            }

        });
    } else if ((id == 'remove-video') && numItems != 1) {
//        console.log(numItems);
        parentiddis = $('#remove-video_' + inc).parent().prev().find('.removespecshow').attr('id');
        $('#' + id1 + inc).remove();
        par = parentiddis.substr(parentiddis.indexOf("_") + 1);
        $('#' + rid + inc2).show();
        if ($('#add-more-video' + lastidnum).is(':visible')) {

            $('#add-more-video' + par).hide();
        } else {

            $('#add-more-video' + par).show();
        }

        $('#' + id + inc).hide();
    }


}

/************
 profile certification details
 **************/
function standard_certificate(id, inc, id1, rid) {
    var inc1 = +inc + +1;
    var inc2 = +inc - +1;
    var cc, parentiddis, par;
    var lastid = $('#stand_cert_div').children().last().attr('id');
//    console.log(lastid);
    var lastidnum = lastid.substr(lastid.indexOf("_") + 1);
    var numItems = $('.addvideodiv').length;
//    console.log(id);
    if (numItems == 1 && id == 'remove-stand-cert') {
        $('#remove-stand-cert_' + inc).hide();
    } else if (id == 'add-more-stand-cert') {
        cc = +lastidnum + +1;
//        console.log(cc);
        $.ajax({
            type: 'post',
            url: '/profile/company_profile/standard_certificate',
            data: {spec: cc},
            dataType: 'html',
            success: function (output)
            {
                $('#' + id + inc).hide();
                $('#remove-stand-cert_' + inc).show();
                $('#stand_cert_div').append(output);
                $('.stand_sertify_name').select2({
                });
            }

        });
    } else if ((id == 'remove-stand-cert') && numItems != 1) {
//        console.log(numItems);
        parentiddis = $('#remove-stand-cert_' + inc).parent().prev().find('.removespecshow').attr('id');
        $('#' + id1 + inc).remove();
        par = parentiddis.substr(parentiddis.indexOf("_") + 1);
        $('#' + rid + inc2).show();
        if ($('#add-more-stand-cert' + lastidnum).is(':visible')) {

            $('#add-more-stand-cert' + par).hide();
        } else {

            $('#add-more-stand-cert' + par).show();
        }

        $('#' + id + inc).hide();
    }


}
function qa_certificate(id, inc, id1, rid) {
    var inc1 = +inc + +1;
    var inc2 = +inc - +1;
    var cc, parentiddis, par;
    var lastid = $('#qa_certificate_div').children().last().attr('id');
//    console.log(lastid);
    var lastidnum = lastid.substr(lastid.indexOf("_") + 1);
    var numItems = $('.addqadiv').length;
//    console.log(id);
    if (numItems == 1 && id == 'remove-qa-cert') {
        $('#remove-qa-cert_' + inc).hide();
    } else if (id == 'add-more-qa-cert') {
        cc = +lastidnum + +1;
//        console.log(cc);
        $.ajax({
            type: 'post',
            url: '/profile/company_profile/qa_certificate',
            data: {spec: cc},
            dataType: 'html',
            success: function (output)
            {
//                console.log(inc);
                $('#' + id + inc).hide();
                $('#remove-qa-cert_' + inc).show();
                $('#qa_certificate_div').append(output);
                $('.qa_sertify_name').select2({
                });
            }

        });
    } else if ((id == 'remove-qa-cert') && numItems != 1) {
//        console.log(numItems);
        parentiddis = $('#remove-qa-cert_' + inc).parent().prev().find('.removeqashow').attr('id');
        $('#' + id1 + inc).remove();
        par = parentiddis.substr(parentiddis.indexOf("_") + 1);
        $('#' + rid + inc2).show();
        if ($('#add-more-qa-cert' + lastidnum).is(':visible')) {

            $('#add-more-qa-cert' + par).hide();
        } else {

            $('#add-more-qa-cert' + par).show();
        }

        $('#' + id + inc).hide();
    }


}

/**
 *
 * variant in product form
 */
function checkdupvariantlist(val, id, firstdiv, secdiv) {


    var taskArray = new Array();
    $(firstdiv + id).each(function () {
        if (val != '') {
            taskArray.push($.trim($(this).val().toLowerCase()));
        }
    });
//    taskArray.splice($.inArray($.trim(val.toLowerCase()), taskArray), 1);

//    console.log($.trim(val.toLowerCase()));
    arrfound = $.inArray($.trim(val.toLowerCase()), taskArray);
//    console.log(taskArray);
//    console.log(arrfound);
    if (arrfound >= 0) {
//        console.log(secdiv);
        /**
         * input type div
         */
        $('#' + secdiv + id).val('');
        /**
         * error show div
         */
        $('.err' + secdiv + id).html('same attribute');
        $('.err' + secdiv + id).show(0).delay(2000).hide(0);
        return 1;
//        $('.specerror').show();
    } else {
        /**
         * input type div
         */
//        $('#' + secdiv + id).val('');

        return 2;
    }

}
$(document).ready(function () {
    $('.variantentopt').keypress(function (event) {
//        console.log("fa");
        if (event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });
    if ($('#productrepeatdatack').length) {
        $('#productchk').prop('checked', true);
        getproductdata();
    }
});
function textenter(event, count, value) {
    if (event.keyCode == 13) {
        if (count == 'custom') {
            productaddcusvariant();
        } else {
            productaddoption(count, value);
        }
    }
}
/*
 *     add/remove variant in product ecomm
 */
function productaddcusvariant() {
    var val = $('#cusvariant').val();
    var vallength = $('#cusvariant').val().length;
    var taskArray = new Array();
    if (vallength > 2) {
        var cc = checkdupvariantlist(val, '', '.variantname', 'cusvariant');
        if (cc == 2) {
            productaddvariant('cus', val);
        }

    } else {
        $('.errcusvariant').html('enter attribute name');
        $('.errcusvariant').show(0).delay(2000).hide(0);
    }

}

function productaddvariant(val, text) {
    var varoptlength1 = $('.variantdivcal').length;
    var lastid = $('#addvariantdisplay').children().last().attr('id');
//    console.log(lastid);
    var lastidnum;
    if ($('#' + lastid).length > 0)
    {
        varoptlength = lastid.substr(10);
//        console.log(lastidnum);
    } else {
        varoptlength = varoptlength1;
    }

    var text1 = text.charAt(0).toUpperCase() + text.slice(1);
    var checkvar = $('#addvariantselect').has('option:contains("' + text1 + '")').length;
    if (val.toLowerCase() != 'custom' && val != '') {
        $('#cusvariantdiv').hide();
        if (checkvar == 1) {
            $('#addvariantselect').find('option:contains("' + text1 + '")').attr("disabled", "disabled");
        }
        $('#addvariantselect option').prop("selected", false);
        var productpricelen = $('.priceshowdiv').length;
        $.ajax({
            type: 'post',
            url: '/profile/products/productaddvariant',
            data: {
                variantid: val,
                variantvalue: text,
                variantclass: +varoptlength + +1,
                priceaddlength: productpricelen
            },
            success: function (e) {

                $('#addvariantdisplay').append(e);
                $('#cusvariant').val('');
                $('#addvariantselect').hide();
            }
        });
    } else {
        $('#cusvariantdiv').show();
    }

}

function productaddoption(valcount, text) {
    var varoption = $('#variantoption' + valcount).val();
    var prdecprice = $('#esellprice').val();
    var varoptionlength = $('#variantoption' + valcount).val().length;
    var varoptlength = $('.variantoptiondiv').length;
    var varoptstock = $('.varoptionstocka').length;
    if (varoptionlength >= 1) {
        var cc = checkdupvariantlist(varoption, valcount, '.varoptionname', 'variantoption');
        if (cc == 2) {
            $('#addvariantselect option').prop("selected", false);
            $.ajax({
                type: 'post',
                url: '/profile/products/productaddvariantoption',
                data: {
                    variantcount: valcount,
                    variantvalue: text,
                    variantoption: varoption,
                    variantclass: varoptlength + 1,
                    varoptstock: varoptstock + 1,
                    prdecprice: prdecprice
                },
                success: function (e) {
                    $('.subvariant' + valcount).append(e);
                    $('.variantoption' + valcount).val('');
                    if ($(".varoptionpriceheadb" + valcount).is(':visible')) {
                        $('.varoptionprice' + valcount).show();
                    }

                }
            });
        }
    } else {
        $('.errvariantoption' + valcount).show(0).delay(2000).hide(0);
    }
}
function removevariant(id, text) {

    $('#' + id).remove();
    var text1 = text.charAt(0).toUpperCase() + text.slice(1);
    var checkvar = $('#addvariantselect').has('option:contains("' + text1 + '")').length;
    $('#addvariantselect option').prop("selected", false);
    if (checkvar == 1) {
        $('#addvariantselect').find('option:contains("' + text1 + '")').removeAttr("disabled");
    }
    var productpricelen = $('.priceshowdiv').length;
    if ($(".priceshowdiv").is(':visible')) {


    } else {
        var lastid = $('#addvariantdisplay').children().first().attr('id');
        if ($('#' + lastid).length > 0)
        {
            varoptlength = lastid.substr(10);
            $('.priceincdiv' + varoptlength).show();
        }

    }
    $('#addvariantselect').show();
}
var cur = 0;
function showprice(count, type) {

    if (type == 'add') {
        $('.varoptionpriceheadb' + count).show();
        $('.varoptionpriceheada' + count).hide();
        $('.varoptionprice' + count).show();
        cur = 1;
    } else {
        $('.varoptionpriceheada' + count).show();
        $('.varoptionpriceheadb' + count).hide();
        $('.varoptionprice' + count).val('');
        $('.varoptionprice' + count).hide();
//        $('.varoptionprice' + count).val('');
        cur = 0;
    }


}

function stockcheck(count, id) {

    if ($('#' + id).is(":checked")) {

        $('#varoptionstockb' + count).val('available');
    } else {
        $('#varoptionstockb' + count).val('not available');
    }
}
/**
 *
 *----------------end variant--------------------------
 */
function getpricecurrency(val, id) {
    $('.' + id).html(val);
}
/**
 * offers block(hidded)
 */

$(document).ready(function () {
    $('#offer_from_date')
            .datepicker({
                startDate: 'now',
                autoclose: true,
//                format: "dd-mm-yyyy",
//                todayHighlight: true

            });
    $('#offer_from_date')
            .on('changeDate', function (e) {
                var x = $('#offer_from_date')
                        .val();
//                console.log(x);
                $('#offer_from_date')
                        .val(x);
                $('#offer_to_date')
                        .datepicker('setStartDate', x)
                        .datepicker('update');
//                $('#offer_to_date')
//                        .val('');
                $('#offer_from_date')
                        .parent()
                        .addClass('has-success');
                $('#offer_from_date')
                        .parent()
                        .removeClass('has-error');
                $('#offer_from_date')
                        .addClass('valid');
                $('#offer_from_date')
                        .removeClass('error');
                $('.help-block')
                        .empty();
                $('.valid')
                        .css({
                            'border-color': '#3c763d'
                        });
            });
    $('#offer_to_date')
            .datepicker({
                startDate: 'now',
                autoclose: true,
//                format: "dd-mm-yyyy",
//                todayHighlight: true
            });
    $('#offer_to_date')
            .on('changeDate', function (e) {
                var x = $('#to_date')
                        .val();
                $('#offer_from_date')
                        .datepicker('setEndDate', x)
                        .datepicker('update');
                $('#offer_to_date')
                        .parent()
                        .addClass('has-success');
                $('#offer_to_date')
                        .parent()
                        .removeClass('has-error');
                $('#offer_to_date')
                        .addClass('valid');
                $('#offer_to_date')
                        .removeClass('error');
                $('.help-block')
                        .empty();
                $('.valid')
                        .css({
                            'border-color': '#3c763d'
                        });
            });
    $('#offerforchooose').multiselect({
        selectAllValue: 'multiselect-all',
//    enableCaseInsensitiveFiltering: true,
//    enableFiltering: true,
        maxHeight: '300',
        buttonWidth: '460'

    });
    $('#ecom_combo_offer').multiselect({
        selectAllValue: 'multiselect-all',
//    enableCaseInsensitiveFiltering: true,
//    enableFiltering: true,
        maxHeight: '300',
        buttonWidth: '235'

    });
});
//
//function discountofferchange(val, type, div) {
//
//    console.log(val);
//    $.ajax({
//        type: 'post',
//        url: URL_PROFILE_PATH + 'offers/add/discountoffers/typechange',
//        data: {
//            offerfor: val,
//            offertype: type
//        },
//        success: function (e) {
//            $('#' + div).html(e);
//            $('#offerforchooose').multiselect();
//        }
//    });
//}

//*******select product for free offer************
function freeofferchange(val, type) {


    $.ajax({
        type: 'post',
        url: URL_PROFILE_PATH + 'offers/add/freeoffers/productchange',
        data: {
            freeofproduct: val,
            freeoftype: type

        },
        success: function (e) {
            $('#freeofferprod').html(e);
        }
    });
}
//*********select free product******
function getfreeproductunit(val) {
    $.ajax({
        type: 'post',
        url: URL_PROFILE_PATH + 'offers/add/freeoffers/getunit',
        data: {
            productsid: val
        },
        success: function (e) {
//var json = $.parseJSON(e);
//            console.log(e.name);
            $('#freeproduct_name').val(e.name);
            $('#freeproduct_unit').val(e.std_unit);
            $('#freeproduct_price').val(e.price);
////            console.log(JSON.parse(e));
//
        }
    });
}
function combooffer(val) {
//    console.log(val);
    if (val != '') {
        $.ajax({
            type: 'post',
            url: URL_PROFILE_PATH + 'offers/add/freeoffers/combooffer',
            data: {
                productsid: val
            },
            success: function (e) {

                if ($('#comboproduct_' + val).length) {
//                 $('#comboofferproduct').append(e);
                } else {
                    $('#comboofferproduct').append(e);
                }
            }
        });
    } else {

    }
}
function comboautualpricecal(val) {
    var qty = $('#comboproductqty_' + val).val();
    var actprice1 = 0;
    if ($.isNumeric(qty)) {
        var price = $('#comboproductorgprice_' + val).val();
        var actprice = (qty * price);
        $('#comboproductprice_' + val).val(actprice);
        var values = $("input[name='product_off_price[]']").map(function () {
            return $(this).val();
        }).get();
        $.each(values, function (i, v) {
            actprice1 += parseInt(v);
        });
        $('#comboautualprice').val(actprice1);
    }
}
/**
 * -----------end offers block---------------
 */

//**************js grid for manage offer block(view,edit,delete)***********
$("#manage-ecom-offers").jsGrid({
    height: "auto",
    width: "90%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No offers found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/ecomoffers',
                data: {
                    pageName: hashData,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.ecomoffers);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        window.location.href = URL_PROFILE_PATH + 'offers/edit/' + editid;
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        $.ajax({
            url: URL_API_BASE_PATH + '/ecomofferdelete',
            data: {
                pageName: hashData,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
//                console.log(data);
                $('#refresh-count-load').load(location.href + ' #refresh-count-load');
            }

        });
        window.location.href = URL_PROFILE_PATH + 'offers#deleted';
    },
    fields: [
//        {
//            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
//                var path;
//                if (value != '' && value != null) {
//                    path = URL_UPLOADS_PATH + "/" + value;
//                } else {
//                    path = URL_CDN_PATH + "/assets/img/noimage.png";
//                }
//                return '<img  class="img-responsive" src="' + path + '"/>';
//            }
//        },
        {name: "offer_name", title: "Name", align: "center", itemTemplate: function (value) {
                if (value == '') {
                    typename = 'Free Shipping';
                } else {
                    typename = value;
                }
                return typename;
            }, type: "text", autosearch: true, valueField: "name", textField: "name"},
        {name: "offer_type", title: "Type", align: "center", itemTemplate: function (value) {
                if (value == 1) {
                    typename = 'Discount %';
                } else if (value == 2) {
                    typename = 'Free Offer';
                } else if (value == 3) {
                    typename = 'Frequently Bought Together';
                } else if (value == 4) {
                    typename = 'Free Shipping';
                } else {
                    typename = '';
                }
                return typename;
            }, type: "text", autosearch: true, valueField: "Type", textField: "Type"},
        {name: "offer_valid_from", title: "Start Date", align: "center", type: "text", autosearch: true, valueField: "Type", textField: "Type"},
        {name: "offer_expiry_date", title: "End Date", align: "center", type: "text", autosearch: true, valueField: "Type", textField: "Type"},
        {name: "activestatus", title: "Status", align: "center", type: "text", autosearch: true, valueField: "Type", textField: "Type"},
//        {name: "offer_valid_from", title: "Status", align: "center", itemTemplate: function (value) {
//                console.log(value);
//                var d = new Date();
//                var curr_date = d.getDate();
//                var curr_month = d.getMonth();
//                var curr_year = d.getFullYear();
//                var twoDigitMonth = ((d.getMonth().length + 1) === 1) ? (d.getMonth() + 1) : '0' + (d.getMonth() + 1);
//                var curdate = curr_year + "-" + twoDigitMonth + "-" + curr_date;
//                if (value > curdate) {
//                    datetype = 'Upcoming';
//                } else if (value == curdate) {
//                    datetype = 'Ongoing';
//                } else {
//                    datetype = 'Expired';
//                }
//                return datetype;
//            }, type: "text", autosearch: true, valueField: "Type", textField: "Type"},
//        {name: "description", align: "center", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {
            type: "control",
            modeSwitchButton: true,
            filtering: false,
            sorting: true,
            deleteButtonTooltip: "Delete  this Product"
        }
//
    ]
});
//********E-wallet details(hidded)************
$('#ewalletfrom_date')
        .datepicker({
//            startDate: 'now',
            autoclose: true

        });
$('#ewalletfrom_date')
        .on('changeDate', function (e) {
            var x = $('#ewalletfrom_date')
                    .val();
            $('#ewalletfrom_date')
                    .val(x);
            $('#ewalletto_date')
                    .datepicker('setStartDate', x)
                    .datepicker('update');
            $('#ewalletfrom_date')
                    .parent()
                    .addClass('has-success');
            $('#ewalletfrom_date')
                    .parent()
                    .removeClass('has-error');
            $('#ewalletfrom_date')
                    .addClass('valid');
            $('#ewalletfrom_date')
                    .removeClass('error');
            $('.help-block')
                    .empty();
            $('.valid')
                    .css({
                        'border-color': '#3c763d'
                    });
        });
$('#ewalletto_date')
        .datepicker({
            autoclose: true
        });
$('#ewalletto_date')
        .on('changeDate', function (e) {
            var x = $('#ewalletto_date')
                    .val();
//            $('#ewalletto_date')
//                    .datepicker('setEndDate', x)
//                    .datepicker('update');
            $('#ewalletto_date')
                    .parent()
                    .addClass('has-success');
            $('#ewalletto_date')
                    .parent()
                    .removeClass('has-error');
            $('#ewalletto_date')
                    .addClass('valid');
            $('#ewalletto_date')
                    .removeClass('error');
            $('.help-block')
                    .empty();
            $('.valid')
                    .css({
                        'border-color': '#3c763d'
                    });
        });
function checkewallet(pricevalue, revenue_slug) {
//    console.log(revenue_slug);
    var inpvalue = $('input[name=payment_gateway]:checked').val();
    if (inpvalue == 5) {
        $.ajax({
            url: URL_PROFILE_PATH + 'check_ewallet',
            dataType: 'json',
            type: 'post',
            data: {revenue_slug: revenue_slug},
            success: function (output) {
//                console.log(output);

                var ewallvalue = output.balance;
//                    var arrayvalue = value.balance;
                if (ewallvalue == 'no') {
                    $('#alert_div').slideDown('slow').show();
                    $('#alertaccount_div').hide();
                    $('#member_payment').attr('type', 'button');
                    $('#ewalletalert_div').attr('required', 'required');
                    return false;
                } else if (ewallvalue == 'acc_no') {
                    $('#alert_div').hide();
                    $('#alertaccount_div').slideDown('slow').show();
                    $('#member_payment').attr('type', 'button');
                    $('#ewalletalert_div').attr('required', 'required');
                    return false;
                } else {
                    $('#alert_div').hide();
                    $('#member_payment').attr('type', 'submit');
                    $('#ewalletalert_div').removeAttr('required', '');
                    $('#member_payment').click();
                }

            }
        });
    } else {
        $('#member_payment').attr('type', 'submit');
        $('#member_payment').click();
    }
}
//**************ewallet end*********

//*****Js grid for manage your stocks******
$("#stocks_manage_container").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: true,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No Products Found",
    controller: {
        loadData: function (filter) {
            // console.log(filter);
            $('.jsgrid-control-field').html('Action');
            var d = $.Deferred();
            $.ajax({
                url: URL_API_BASE_PATH + '/productstocks',
                data: {
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"

            }).done(function (response) {

                d.resolve(response.stocks);
            });
            return d.promise();
        },
        updateItem: function (item) {
            var id = item.id;
            var stock = item.stock_availablity;
            if (stock >= 0) {
                $.ajax({
                    url: URL_API_BASE_PATH + '/productstocksupdate',
                    data: {
                        prodid: id,
                        stock: stock
                    }, type: 'post',
                    success: function (e) {

                    }
                });
            } else {
                alert("Stock Availability should be higher & Numerics!");
                $('#stocks_manage_container').load(URL_PROFILE_PATH + 'stocks#stocks_manage_container');
            }
        }
    },
    fields: [
        {
            name: "image", title: "Image", align: "center", width: 30, itemTemplate: function (value) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "name", title: "Name", align: "center", editing: false, type: "text", autosearch: true, valueField: "name", textField: "name"},
        {name: "prd_std_qty", align: "center", editing: false, sorting: false, title: "Quantity", type: "text", autosearch: true, valueField: "prd_std_qty", textField: "prd_std_qty"},
        {name: "stock_availablity", align: "center", editing: true, title: "Stock Availablity", type: "text", autosearch: true, valueField: "Stock Availablity", textField: "Stock Availablity"},
        {name: "stock_unit", align: "center", editing: false, title: "Stock Unit", type: "number", autosearch: true, valueField: "Stock Unit", textField: "Stock Unit"},
        {
            type: "control",
            modeSwitchButton: false,
            deleteButton: false,
//            filtering: false,
            sorting: true

        }

//
    ]
});
function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
var pagename = getUrlVars()["pagename"];
if (pagename == 'new_request' || pagename == 'confirm_request' || pagename == 'ignore_request') {
    var fields = [
        {
            name: "image", title: "Image", align: "center", width: 10, itemTemplate: function (value, item) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "prod_name", title: "Product Name", width: 20, align: "center", type: "text", autosearch: true, valueField: "name", textField: "name"},
        {name: "buyer_name", width: 20, align: "center", title: "Customer Name", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {name: "pincode", width: 20, align: "center", title: "City / Pincode", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {name: "created_at", width: 20, align: "center", title: "Date", type: "text", autosearch: true, valueField: "date", textField: "date"},
        {name: "id", width: 20, align: "center", title: "Action", itemTemplate: function (value, item) {
                var path, ship_data, weight;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + item.image;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }

                if (item.shipping != '') {
                    ship_data = JSON.parse(item.shipping);
                    if (ship_data['weight'] != '') {
                        weight = ship_data['weight'] + '&nbsp;' + 'grms';
                    }
                }
                var typ = 1;
                var address = item.address.replace(/(\r\n|\n|\r)/gm, " ");
                return '<span class="btn pf-bt" data-toggle="modal" data-target="#reqModal" onclick="getproductid(\'' + pagename + '\',' + typ + ',' + item.id + ',' + item.prod_id + ',\'' + path + '\',\'' + item.prod_name + '\',\'' + item.buyer_name + '\',' + item.pincode + ',\'' + item.created_at + '\',\'' + item.updated_at + '\',\'' + weight + '\',\'' + address + '\',\'' + item.phone + '\',\'' + item.landmark + '\',\'' + item.price + '\',\'' + item.product_price + '\',' + item.status + ',\'' + item.reuse_status + '\', ' + item.stock + ', ' + item.offers_id + ',\'' + item.expiry_date + '\')">View Request</span>';
            }
        }
    ]
} else if (pagename == 'new-request' || pagename == 'confirm-request' || pagename == 'ignore-request') {
    var fields = [
        {
            name: "image", title: "Image", align: "center", width: 10, itemTemplate: function (value, item) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "prod_name", title: "Product Name", width: 20, align: "center", type: "text", autosearch: true, valueField: "name", textField: "name"},
        {name: "seller_det", width: 20, align: "center", title: "Supplier / Company Name", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {name: "created_at", width: 20, align: "center", title: "Requested Date", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {name: "updated_at", width: 20, align: "center", title: "Updated Date", type: "text", autosearch: true, valueField: "date", textField: "date"},
        {name: "product_price", width: 20, align: "center", title: "Price (INR)", type: "text", autosearch: true, valueField: "date", textField: "date"},
        {name: "id", width: 20, align: "center", title: "Action", itemTemplate: function (value, item) {
                var path, ship_data, weight;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + item.image;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }

                if (item.shipping != '') {
                    ship_data = JSON.parse(item.shipping);
                    if (ship_data['weight'] != '') {
                        weight = ship_data['weight'] + '&nbsp;' + 'grms';
                    }
                }
                typ = 2;
                address = item.address.replace(/(\r\n|\n|\r)/gm, " ");
                return '<span class="btn pf-bt" data-toggle="modal" data-target="#reqModal" onclick="getproductid(\'' + pagename + '\',' + typ + ',' + item.id + ', ' + item.prod_id + ', \'' + path + '\',\'' + item.prod_name + '\',\'' + item.company_name + '\',' + item.pincode + ',\'' + item.created_at + '\',\'' + item.updated_at + '\',\'' + weight + '\',\'' + address + '\',\'' + item.phone + '\',\'' + item.landmark + '\',\'' + item.price + '\',\'' + item.product_price + '\',' + item.status + ',\'' + item.reuse_status + '\', ' + item.stock + ', ' + item.offers_id + ',\'' + item.expiry_date + '\')">View Request</span>';
            }
        }
    ]
} else {
    var fields = [
        {
            name: "image", title: "Image", align: "center", width: 10, itemTemplate: function (value, item) {
                var path;
                if (value != '' && value != null) {
                    path = URL_UPLOADS_PATH + "/" + value;
                } else {
                    path = URL_CDN_PATH + "/assets/img/noimage.png";
                }
                return '<img  class="img-responsive" src="' + path + '"/>';
            }
        },
        {name: "name", title: "Name", width: 30, align: "center", type: "text", autosearch: true, valueField: "name", textField: "name"},
        {name: "description", width: 30, align: "center", title: "Description", type: "text", autosearch: true, valueField: "description", textField: "description"},
        {name: "date", width: 30, align: "center", title: "Date", type: "text", autosearch: true, valueField: "date", textField: "date"},
        {name: "id", width: 30, align: "center", title: "Action", itemTemplate: function (value, item) {
                var pagename = getUrlVars()["pagename"];
                if (pagename == 'accepted-orders') {
                    return '<a class="btn pf-bt" href="' + URL_PROFILE_PATH + 'ecommerce/orders-' + value + '.html">View</a><span class="btn pf-bt" onclick="getorderid(' + value + ',4)">Pack</span>';
                } else if (pagename == 'orders-to-be-pack') {
                    return '<a class="btn pf-bt" href="' + URL_PROFILE_PATH + 'ecommerce/orders-' + value + '.html">View</a><span class="btn pf-bt" data-toggle="modal" data-target="#shipModal" onclick="getshipid(' + value + ',' + item.shipping_pincode + ',5)">Ship</span>';
                } else if (pagename == 'ship') {
                    return '<a class="btn pf-bt" href="' + URL_PROFILE_PATH + 'ecommerce/orders-' + value + '.html">View</a>';
                } else if (pagename == 'status') {
                    var status_id = item.supplier_status;
                    if (status_id == 6)
                        return '<a class="btn pf-bt" href="' + URL_PROFILE_PATH + 'ecommerce/orders-' + value + '.html">View</a><span class="btn pf-bt no-cursor">Deliver</span>';
                    if (status_id == 7)
                        return '<a class="btn pf-bt" href="' + URL_PROFILE_PATH + 'ecommerce/orders-' + value + '.html">View</a><span class="btn pf-bt-org no-cursor">Return</span>';
                } else if (pagename == 'request') {
                    return '<a class="btn pf-bt" href="' + URL_PROFILE_PATH + 'ecommerce/orders-' + value + '.html">View</a>';
                } else {
                    return '<a class="btn pf-bt" href="' + URL_PROFILE_PATH + 'ecommerce/orders-' + value + '.html">View</a>';
                }
            }
        }
    ]
}
//*******js grid for e-comm Order view******
$("#ecommerce_manage_container").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: false,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageButtonCount: 5,
    noDataContent: "No orders found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            var pagename = getUrlVars()["pagename"];
//            console.log(pagename);
            // console.log(filter.pageIndex);
            var d = $.Deferred();
//            console.log(filter);
            $.ajax({
                url: URL_API_BASE_PATH + '/orders',
                data: {
                    pageName: pagename,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"
            }).done(function (response) {
//                console.log(response.orders);
                d.resolve(response.orders);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        // window.location.href = URL_PROFILE_PATH + 'ecommerce/edit/' + editid;
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        var pagename = getUrlVars()["pagename"];
        $.ajax({
            url: URL_API_BASE_PATH + '/orderdelete',
            data: {
                pageName: pagename,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
//                console.log(data);
            }

        });
    },
    fields: fields
});
$("#ecommerce_delivery_container").jsGrid({
    height: "auto",
    width: "100%",
    filtering: false,
    editing: false,
    sorting: true,
    paging: true,
    autoload: true,
    pageSize: 10,
    pageLoading: true,
    pageButtonCount: 5,
    noDataContent: "No request found",
    deleteConfirm: "Are you sure want to delete this?",
    controller: {
        loadData: function (filter) {
            var pagename = getUrlVars()["pagename"];
            // console.log(filter.pageIndex);
            var d = $.Deferred();
//            console.log(filter);
            $.ajax({
                url: URL_API_BASE_PATH + '/orders',
                data: {
                    pageName: pagename,
                    pageSize: filter.pageSize,
                    pageIndex: filter.pageIndex
                },
                dataType: "json"
            }).done(function (response) {
//                console.log(response.orders);
                d.resolve(response.orders);
            });
            return d.promise();
        }
    },
    onItemEditing: function (args) {
        args.cancel = true;
        var editid = args.item.id;
        // window.location.href = URL_PROFILE_PATH + 'ecommerce/edit/' + editid;
    },
    onItemDeleted: function (args) {
        var delid = args.item.id;
        var pagename = getUrlVars()["pagename"];
        $.ajax({
            url: URL_API_BASE_PATH + '/orderdelete',
            data: {
                pageName: pagename,
                deleteId: delid
            },
            type: "get",
            success: function (data) {
//                console.log(data);
            }

        });
    },
    fields: fields
});
//*********E-comm Order view page(hidded)**********
$('#shipdate').datepicker({
    dateFormat: "dd-mm-yy",
    startDate: 'now',
    autoclose: true
});
function cancelbox() {
    $('#order-overlay').css('display', 'none');
    $('#order-orderbox').css('display', 'none');
}

//function okbox() {
//    var id = $('#order-id').val();
//    var statuschk = $('#status-check').val();
//
//    if (statuschk == 1) {
//        $.ajax({
//            url: '/profile/ecommerce/orders/changestatus',
//            type: 'post',
//            data: {
//                orderid: id, status: 1
//            },
//            success: function (e) {
//                $('#disp-msg').css('display', 'block');
//                setTimeout(function () {
//                    window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=accepted-orders';
//                }, 3000);
//            }
//        });
//    } else if (statuschk == 3) {
//        $.ajax({
//            url: '/profile/ecommerce/orders/changestatus',
//            type: 'post',
//            data: {
//                orderid: id, status: 3
//            },
//            success: function (e) {
//                window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=reject';
//            }
//        });
//    }
//}

function confirmorder() {
    $('#order-overlay').css('display', 'block');
    $('#order-orderbox').css('display', 'block');
//    $('#ordermsgbox').css('display', 'block');
    $('#orderlightbox').css('display', 'block');
    $('#status-check').attr('value', 1);
    $('#text-content').html('Do you want to confirm this order?');
}

function rejectorder() {
    $('#order-overlay').css('display', 'block');
    $('#order-orderbox').css('display', 'block');
//    $('#ordermsgbox').css('display', 'block');
    $('#orderlightbox').css('display', 'block');
    $('#status-check').attr('value', 3);
    $('#text-content').html('Do you want to reject this order?');
}
function getproductid(pagename, t, reqid, id, image, prod_name, buyer_name, pincod, reqdate, rplydat, shipping, address, phone, landmark, price, prodprice, status, reuse, stock, offer, expirydat) {
    $('#reqproduct_id').attr('value', id);
    $('#request_id').attr('value', reqid);
    $('#reqproduct_img').attr('src', image);
    $('#reqproduct_name').html(prod_name);
    $('#reqbuyer_name').html(buyer_name);
    $('#req_pincode').html(pincod);
    $('#pincode_value').attr('value', pincod);
    $('#stock_value').attr('value', stock);
    $('#offer_value').attr('value', offer);
    $('#req_date').html(reqdate);
    $('#reply_date').html(rplydat);
    $('#req_shipping').html(shipping);
    $('#req_address').html(address);
    $('#req_phone').html(phone);
    if (landmark == '') {
        $('#req_landmark').html('N/A');
    } else {
        $('#req_landmark').html(landmark);
    }

    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd
    }
    if (mm < 10) {
        mm = '0' + mm
    }
    var today = yyyy + '-' + mm + '-' + dd;
//    console.log(today);

    $('#supreplydate').hide();
    $('#buyer-logmsg').hide();
    if (pagename == 'confirm-request') {
        $('#prodviewbtn').hide();
        $('#supreplydate').show();
        $('#buyer-logmsg').show();
    }


    if (offer > 0 && expirydat >= today) {
        $('#offer-msg').html('Offer');
    } else if (offer > 0 && expirydat < today) {
        $('#offer-msg').html('Expire Offer');
    } else if (offer == 0) {
        $('#offer-msg').html('No Offer');
    }

//    if (t == 2) {
//        $('.buyer_div').addClass('hidden');
//    }

    if (prodprice != 0)
        $('#deliver_pricespan').html(prodprice + ' INR');
    else
        $('#deliver_pricespan').html('Not Available');
    if (status != 0) {
        $('#deliver_price').attr('value', price);
        $('#deliver_pricespan').html(prodprice + ' INR');
        $('#deliver_pricepay').html(price + ' INR');
        $('#deliver_price').attr('readonly', true);
    }

    if (status == 1) {
        $('#cnfrmprce').css('display', 'none');
    }

    if (status == 2) {
        $('#ignrprce').css('display', 'none');
        $('#cnfrmprce').css('display', 'none');
        $('#deliver_div').css('display', 'none');
        $('#addcartbtn').css('display', 'none');
        $('#delvpricehide').css('display', 'none');
    }

    if (status == 0) {
        $('#deliver_div').css('display', 'none');
        $('#addcartbtn').css('display', 'none');
        $('#hidestatus0').css('display', 'none');
    }

    if (reuse == 0 && status == 0) {
        $('#retainprice').prop('checked', true);
    }

    if (reuse == 1 && status > 0) {
        $('#retainprice').prop('checked', true);
    }

    if (reuse == 0 && status > 0) {
        $('#retainprice').prop('checked', false);
    }

    $('#buynw-btn').css('display', 'none');
    if (stock > 0) {
        var buy_url = URL_MAIN_PATH + '/placeorder/' + reqid;
        if (t == 2 && price != 0 && pagename == 'confirm-request') {
            $('#buynw-btn').css('display', 'inline-block');
            $('#buynw-btn').attr("onclick", "window.open('" + buy_url + "')");
        }
        $('#stock-msg').html('Stock Available');
    } else {
        $('#buynw-btn').css('display', 'none');
        $('#stock-msg').html('No Stock');
    }
}
//****product delivery request*****
function viewProduct() {
    var productId = $('#reqproduct_id').val();
//    console.log(URL_API_BASE_PATH);
    $.ajax({
        url: URL_API_BASE_PATH + '/getPordid',
        type: 'post',
        data: {prodId: productId},
        success: function (e) {
            window.open(e, '_blank');
        }
    });
}


function getorderid(id, status) {
    $('#order-id').attr('value', id);
    $('#status-check').attr('value', status);
    $('#order-overlay').css('display', 'block');
    $('#order-orderbox').css('display', 'block');
    $('#orderlightbox').css('display', 'block');
    $('#text-content').html('Do you want to pack this order?');
}

$("#deliverreqform").on('submit', function (e) {
    e.preventDefault();
    var form = $(this);
    form.parsley().validate();
    if (form.parsley().isValid()) {
        confirmPrice();
    }
});
$('#reqModal').on('shown.bs.modal', function () {
    $('#deliver_price').focus();
});
$('#reqmessage').css('display', 'none');
function confirmPrice() {
    var formdata = $('#deliverreqform').serialize();
    $.ajax({
        url: '/profile/ecommerce/orders/confirmprice',
        type: 'post',
        data: formdata,
        success: function (e) {
            $('#reqmessage').css('display', 'block');
            $('#reqmessage').html('Delivery request confirmed.!');
            setTimeout(function () {
                $('#reqmessage').css('display', 'none');
                window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=confirm_request';
            }, 3000);
        }
    });
}

function ignoreDeliver() {
    $('#deliver_price').val('0');
    $('#deliverreqform').parsley().validate();
    if ($('#deliverreqform').parsley().isValid()) {

        var formdata = $('#deliverreqform').serialize();
        $.ajax({
            url: '/profile/ecommerce/orders/ignoredeliver',
            type: 'post',
            data: formdata,
            success: function (e) {
                $('#reqmessage').css('display', 'block');
                $('#reqmessage').html('Delivery request ignored.!');
                setTimeout(function () {
                    $('#reqmessage').css('display', 'none');
                    window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=ignore_request';
                }, 3000);
            }
        });
    }
}

function getshipid(id, pincode, status) {
    $('#hid_shipid').attr('value', id);
    $('#supincode').attr('value', pincode);
    $('#status-check').attr('value', status);
}

function shiplghtbx() {
    $('#shipModal').modal('hide');
    $('#order-overlay').css('display', 'block');
    $('#order-orderbox').css('display', 'block');
    $('#orderlightbox').css('display', 'block');
    $('#text-content').html('Do you want to ship this order?');
}

function lightboxshow() {
    $('#order-overlay').css('display', 'block');
    $('#order-orderbox').css('display', 'block');
    $('#packok').attr('disabled', 'disabled');
    $('#packcancel').attr('disabled', 'disabled');
    $('#orderlightbox').css('display', 'block');
}

$("#pack_detfrm").on('submit', function (e) {
    e.preventDefault();
    var form = $(this);
    form.parsley().validate();
    if (form.parsley().isValid()) {
        successbt();
    }
});
function successbt() {
    var id = $('#order-id').val();
    var statuschk = $('#status-check').val();
    $('#packok').attr('disabled', 'disabled');
    $('#packcancel').attr('disabled', 'disabled');
    $('#disbtn-cancel').attr('disabled', 'disabled');
    $('#disbtn-ok').attr('disabled', 'disabled');
    if (statuschk == 1) {
        $.ajax({
            url: URL_PROFILE_PATH + 'ecommerce/orders/changestatus',
            type: 'post',
            data: {
                orderid: id, status: 1
            },
            success: function (e) {
                $('#confirm_successmsg').show();
                setTimeout(function () {
                    window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=accepted-orders';
                }, 3000);
            }
        });
    } else if (statuschk == 3) {
        $.ajax({
            url: '/profile/ecommerce/orders/changestatus',
            type: 'post',
            data: {
                orderid: id, status: 3
            },
            success: function (e) {
                $('#reject_successmsg').show();
                setTimeout(function () {
                    window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=reject';
                }, 3000);
            }
        });
    } else if (statuschk == 4) {
        $.ajax({
            url: '/profile/ecommerce/orders/changestatus',
            type: 'post',
            data: {
                orderid: id, status: 4
            },
            success: function (e) {
                $('#packed_successmsg').show();
                setTimeout(function () {
                    window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=orders-to-be-pack';
                }, 3000);
            }
        });
    } else if (statuschk == 5) {
        var id = $('#hid_shipid').val();
        var date = $('#shipdate').val();
        var newdate = date.split("-").reverse().join("-");
        var time = $('#shiptim').val();
        var pin = $('#supincode').val();
        var closetime = $('#shopclstim').val();
        var datetime = newdate + " " + time;
        $('.load-butt2').addClass('load-butt');
        $('#pack-submit').attr('disabled', true);
        $.ajax({
            url: URL_MAIN_PATH + '/logistics/order-pickup/',
            type: 'get',
            data: {
                orderid: id, datetime: datetime, closetime: closetime, pin: pin
            },
            dataType: 'json',
            success: function (e) {
                $('#ship-sucmsg').css('display', 'block');
                setTimeout(function () {
                    window.location = URL_PROFILE_PATH + 'ecommerce/orders-on-shipping';
                }, 3000);
            }
        });
    }
}

//function shipid(id, pincode) {
//    $('#hid_shipid').attr('value', id);
//    $('#supincode').attr('value', pincode);
//    $('#pack_detfrm').parsley();
//}

//function shiporder() {
//    var id = $('#hid_shipid').val();
//    var date = $('#shipdate').val();
//    var newdate = date.split("-").reverse().join("-");
//    var time = $('#shiptim').val();
//    var pin = $('#supincode').val();
//    var closetime = $('#shopclstim').val();
//    var datetime = newdate + " " + time;
////    console.log(newdate);
//    var result = confirm("Want to Ship order?");
//    if (result) {
//        $.ajax({
//            url: URL_MAIN_PATH + '/logistics/order-pickup/',
//            type: 'get',
//            data: {orderid: id, datetime: datetime, closetime: closetime, pin: pin},
//            dataType: 'json',
//            success: function (e) {
//                console.log(e);
////                window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=ship';
//            }
//        });
//    }
//}

function deliverorder(id, status) {
    var result = confirm("Want to Deliver order?");
    if (result) {
        $.ajax({
            url: '/profile/ecommerce/orders/changestatus',
            type: 'post',
            data: {
                orderid: id, status: status
            },
            success: function (e) {
                window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=status';
            }
        });
    }
}

function returnorder(id, status) {
    var result = confirm("Want to Return order?");
    if (result) {
        $.ajax({
            url: '/profile/ecommerce/orders/changestatus',
            type: 'post',
            data: {
                orderid: id, status: status
            },
            success: function (e) {
                window.location = URL_PROFILE_PATH + 'ecommerce/orders?pagename=status';
            }
        });
    }
}
//function stockunitchangeone() {
//    var val = $("#min_order_unit").val();
//    var value = $("#production_capacity_unit2").val();
//    $("#production_capacity_unit1").each(function () {
//        $("select#production_capacity_unit1").val(val);
//    });
//    $('#stock_unit').html("<option>" + val + "</option>");
//    $("#production_capacity_unit").val(val);
//    $("#min_order_unit").val(val);
//    $("#production_capacity_unit2").each(function () {
//        $("select#production_capacity_unit2").val(value);
//    });
//}
function stockunitchange(val, id) {
    $.ajax({
        url: '/profile/products/productstockunit',
        type: 'post',
        data: {
            stockunit: val
        },
        success: function (e) {
            var str = e.split(',');
            //$('#stock_unit').html("<option>" + str['1'] + "</option>");
            // $("#production_capacity_unit").val(str['0']);
            // $("#min_order_unit").val(str['1']);
//            $("#production_capacity_unit1").val(str['1']);
            if (id == 1) {
                $("#production_capacity_unit1").each(function () {
                    $("select#production_capacity_unit1").val(val);
                });
                $('#stock_unit').html("<option>" + str['1'] + "</option>");
                $("#production_capacity_unit").val(val);
                $("#min_order_unit").val(val);
            }
            if (id == 2) {
                $("#production_capacity_unit2").each(function () {
                    $("select#production_capacity_unit2").val(val);
                });
            }
            if (id == 3) {
                $("#production_capacity_unit1").each(function () {
                    $("select#production_capacity_unit1").val(val);
                });
                $('#stock_unit').html("<option>" + str['1'] + "</option>");
//                $("#production_capacity_unit").val(val);
                $("#min_order_unit").val(val);
            }

        }
    });
}

//$('#productadd').click(function () {
//    $("form").parsley();
//    $('#produnit_msg').hide();
//    var submitForm = false;
//    $('#proforms').on('submit', function (e) {
//        $('#production_capacity_perunit').attr('required','required');
////        if (!submitForm) {
////            e.preventDefault();
////        }
//        var form = $(this);
//        var prodsupply = $('#production_supply').val();
//        if (prodsupply == '') {
//            form.parsley().validate();
//            if (form.parsley().isValid()) {
//                submitForm = true;
//                form.submit();
//            } else {
//                submitForm = false;
//            }
//        } else {
//            var produnit = $('#production_capacity_perunit').val();
//            if (produnit == '') {
//                $('#produnit_msg').show();
//                submitForm = false;
//            }
//        }
//    });
//});
/*
 * profile product add form non mandatory field error message setting
 */
$('#productadd').click(function () {
    var prodsupply = $('#production_supply').val();
    if (prodsupply == '') {
        $('#production_capacity_unit').removeAttr('required', 'required');
        $('#production_capacity_perunit').removeAttr('required', 'required');
    } else {
        $('#production_capacity_unit').attr('required', 'required');
        $('#production_capacity_perunit').attr('required', 'required');
    }
});
/*
 * profile buying requirements add form non mandatory field error message setting
 */
$('#buyingadd').click(function () {
    var buying_frequency = $('#buying_frequency').val();
    var req_qty = $('#yearly_req_qty').val();
    var currency_unit = $('#preferred_currency_unit').val();
    var preferred_price = $('#preferred_price').val();
    if (buying_frequency == '') {
        $('#yearly_req_unit').removeAttr('required', 'required');
        $('#yearly_req_qty').removeAttr('required', 'required');
    } else {
        $('#yearly_req_unit').attr('required', 'required');
        $('#yearly_req_qty').attr('required', 'required');
    }
//    if (req_qty == '') {
//        $('#yearly_req_unit').removeAttr('required', 'required');
//        $('#buying_frequency').removeAttr('required', 'required');
//    } else {
//        $('#yearly_req_unit').attr('required', 'required');
//        $('#buying_frequency').attr('required', 'required');
//    }
    if (currency_unit == '') {
        $('#preferred_price').removeAttr('required', 'required');
        $('#production_capacity_unit1').removeAttr('required', 'required');
    } else {
        $('#preferred_price').attr('required', 'required');
        $('#production_capacity_unit1').attr('required', 'required');
    }
    if (currency_unit == '' && preferred_price == '') {
        $('#production_capacity_unit').removeAttr('required', 'required');
        $('#production_capacity_unit1').removeAttr('required', 'required');
    } else {
        $('#production_capacity_unit').attr('required', 'required');
        $('#production_capacity_unit1').attr('required', 'required');
    }
});
$('#additional_submit').click(function () {
    var sale_currency = $('#sales_currency').val();
    if (sale_currency == '') {
        $('#total_sales').removeAttr('required', 'required');
    } else {
        $('#total_sales').attr('required', 'required');
    }
    var total_sales = $('#total_sales').val();
    if (total_sales == '') {
        $('#sales_currency').removeAttr('required', 'required');
    } else {
        $('#sales_currency').attr('required', 'required');
    }
    var purchase_currency = $('#purchase_currency').val();
    if (purchase_currency == '') {
        $('#total_purchases').removeAttr('required', 'required');
    } else {
        $('#total_purchases').attr('required', 'required');
    }
    var total_purchases = $('#total_purchases').val();
    if (total_purchases == '') {
        $('#purchase_currency').removeAttr('required', 'required');
    } else {
        $('#purchase_currency').attr('required', 'required');
    }
});
//function samplefile_upload() {
//    var filename = new FormData($('#sample_form')[0]);
//    console.log(filename);
//    $.ajax({
//        type: "POST",
//        url: URL_PROFILE_PATH + 'samplefile_upload'
//
////        enctype: 'multipart/form-data',
//        data: {
//            filename: filename
//        },
//        success: function (output) {
//            console.log(output.filename);
//        }
//    });
//}
//***************e-comm order end*********

//************Certification details************
//function samplefileupload() {
$("#stand_certificate_form").on('submit', (function (e) {
    $('#stand_certificate_form').parsley();
    $('#stand_certificate_form').parsley().validate("first");
    if ($('#stand_certificate_form').parsley().isValid()) {
        e.preventDefault();
//        $("#message").empty();
//        $('#loading').show();
        $('#stand_but').attr('disabled', true);
        $('#stand_but').val('Loading....');
        $.ajax({
            url: URL_PROFILE_PATH + 'standard_vertificate_upload', // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send DOMDocument or non processed data file it is set to false
            success: function (data)   // A function to be called if request succeeds
            {

                $('#stand_but').removeAttr('disabled');
                $('#stand_but').val('ADD MY CERTIFICATE');
                $('#countstand_div').hide();
                $('#countlessdiv').show();
                $('#tablecontent').html(data).show();
                $('#stand_certificate_form')[0].reset();
            }
        });
    }
}));
//}

$("#qa_certificate_form").on('submit', (function (e) {
    $('#qa_certificate_form').parsley();
    $('#qa_certificate_form').parsley().validate("first");
    if ($('#qa_certificate_form').parsley().isValid()) {
        e.preventDefault();
//        $("#message").empty();
//        $('#loading').show();
        $('#qa_but').attr('disabled', true);
        $('#qa_but').val('Loading....');
        $.ajax({
            url: URL_PROFILE_PATH + 'qa_vertificate_upload', // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send DOMDocument or non processed data file it is set to false
            success: function (data)   // A function to be called if request succeeds
            {
                $('#qa_but').removeAttr('disabled');
                $('#qa_but').val('ADD MY CERTIFICATE');
                $('#countqa_div').hide();
                $('#countqalessdiv').show();
                $('#tableqacontent').html(data).show();
                $('#qa_certificate_form')[0].reset();
                $('#qafile_div').load(location.href + ' #qafile_div');
                $('#load_certify_types').load(location.href + ' #load_certify_types');
            }
        });
    }
}));
//***********certification details end*************

//******for fetching previous product content in add product form*********
function getproductdata() {

    if ($("input[name='getproduct']").is(":checked")) {
        $.ajax({
            url: 'getproductdata',
            type: 'post',
            dataType: 'json',
            success: function (e) {
//                console.log(e);
                setTimeout(function () {
                    if ($('#subcategorydiv').length) {
                        $('#subcategorydiv').val(e.subcategory).change();
                    }
                }, 3000);
                setTimeout(function () {
                    if ($('#subsubcategorydiv').length) {
                        $('#subsubcategorydiv').val(e.subsubcategory).change();
                    }
                }, 5000);
                $('#product_name').val(e.name);
                $('#product_desc').val(e.description);
                $('#currency').val(e.price_unit);
                $('#preferred_price').val(e.price_range_from);
                $('#preferred_priceto').val(e.price_range_to);
                $('#production_capacity_unit1').val(e.price_cap_unit);
                var spec = JSON.parse(e.specs);
                $("#production_supply").val(spec.production_capacity);
                $("#production_capacity_unit").val(spec.production_capacity_unit);
                $("#production_capacity_perunit").val(spec.production_capacity_per_unit);
                $('#delivery_time').val(e.delivery_time);
                $('#packing_details').val(e.packaging_details);
                $('#warranty').val(e.warranty);
                $('#category').val(e.category).change();
            }
        });
    } else {
        $('#product_name').val('');
        $('#product_desc').val('');
        $("#production_supply").val('');
        $("#production_capacity_unit").val('');
        $("#production_capacity_perunit").val('');
        $('#delivery_time').val('');
        $('#packing_details').val('');
        $('#warranty').val('');
        $('#category').val('');
        setTimeout(function () {
            $('#subcategorydiv').val('');
            $('.catshowsubcategory').html('');
            $('.catshowsubsubcategory').html('');
            $('.catshowsubsubsubcategory').html('');
//            if ($('#subcategorydiv').length) {
            $('#subsubcategorydiv').val('');
//            }
        }, 1500);
    }
}

//******payment method(all) in add product form***********
function checkallpayment() {

    for (var i = 1; i <= 9; i++) {
        if (i != 8) {
            if ($('#payment_terms10').is(':checked')) {
                $('#payment_terms' + i).prop('checked', 'checked');
            } else {
                $('#payment_terms' + i).prop('checked', false);
            }
        }
    }
}

//*******add as halal product in add product form*********
$(function () {

    $halal_id = $('#halal_id').val();
    if ($halal_id) {
        $('#halal_details').show();
        $('#halalproductadd').attr('checked', 'checked');
        $('.required-block').attr('required', 'required');
    } else {
        $('.required-block').removeAttr('required', 'required');
    }

});
function showHalalDetails() {

    if ($('#halalproductadd').is(':checked')) {
        $('#halal_details').slideDown();
        $('.required-block').attr('required', 'required');
        $('#halal_details').removeClass('hide')
    } else {
        $('#halal_details').slideUp();
        $('.required-block').removeAttr('required', 'required');
        $('#halal_details').addClass('hide')
    }

}

function getProductHalalName(id) {
    console.log(id);
}
//*****halal product end*****
function changeimage(id) {
    $('#' + id).click();
}

//*****add image in article,press release,news and blog forms*******
var old_imgpromo = $('#old_imgpromo').val();
function readURLDocImage(input, div) {
//    console.log(input.files.length);
    if (input.files.length > 0) {
        var extension = input.files[0].name.split('.').pop().toLowerCase();
        if (input.files && input.files[0] && (extension == 'jpg' || extension == 'JPG' || extension == 'jpeg' || extension == 'JPEG' || extension == 'png' || extension == 'PNG' || extension == 'pdf' || extension == 'PDF' || extension == 'DOC' || extension == 'doc' || extension == 'DOCX' || extension == 'docx')) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    if (extension == 'pdf') {
                        $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/icons/pdf.png');
                    } else if (extension == 'doc') {
                        $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/icons/doc.png');
                    } else if (extension == 'docx') {
                        $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/icons/doc.png');
                    } else {
                        $('#' + div).attr('src', e.target.result);
                    }
                };
                reader.readAsDataURL(input.files[0]);
            } else {
                if (typeof old_imgpromo != 'undefined' && old_imgpromo != '') {
                    $('#' + div).attr('src', URL_UPLOADS_PATH + '/' + old_imgpromo);
                } else {
                    $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
                }
            }
        } else {

            $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
        }
    } else {
        $('#' + div).attr('src', URL_CDN_PATH + '/assets/img/noimage.png');
    }
}

//function formatState(data) {
//    console.log(data);
////    var $optimage = $(data.element).data('image');
//    var $optimage = $(data.element).attr('data-image');
//    if ($optimage != '') {
//        $photo = URL_UPLOADS_PATH + '/' + $optimage;
//    } else {
//        $photo = URL_CDN_PATH + '/assets/img/noimage.png';
//    }
//
//    if (data.id != '') {
//        var $state = $(
//                '<span><img src="' + $photo + '" width="50px" height="50px"  /> ' + data.text + '</span>'
//                );
//    } else {
//        var $state = $(
//                '<span>' + data.text + '</span>'
//                );
//    }
//    return $state;
//
//}


//$("#non_halal_product_name").select2({
//     templateResult: formatState,
//    templateSelection: formatState,
//    escapeMarkup: function (m) {
//    return m;
//    }
//});

$("#non_halal_product_name").select2();
//auto hide of alert messages within 2 sec
$(function () {
    setTimeout(function () {
        $('#auto_hide .alert').fadeOut('slow');
    }, 4000);
});
//$(function () {
//    setTimeout(function () {
//        $(' .alert').css('display' , 'none');
//    }, 3000);
//});
/*
 * automatically submit form in (billdesk payment form)
 */

/*
 * coupon code checking
 */
//$('#coupon_cd').click(function () {
function activeCouponCode() {
    var coupon_code = $('#coupon_code_value').val();
    $('#coupon_apply_btn').val('Processing...');
    $.ajax({
        url: URL_PROFILE_PATH + 'checkcouponcode',
        data: {coupon_code: coupon_code},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            var successval = output.coupon;
            var code = output.coupon_code;
            if (successval == 1) {
                $('#payment_div').load(location.href + ' #payment_div');
                $('#coupon_msg_invalid').css({'display': 'none'});
                $('#coupon_msg_empty').css({'display': 'none'});
//                $('#coupon_apply_btn').val('APPLY');
            } else if (successval == 0) {
                $('#coupon_msg_invalid').css({'display': 'block'});
                $('#coupon_msg_empty').css({'display': 'none'});
                $('#coupon_apply_btn').val('APPLY');
            } else if (successval == 2) {
                $('#coupon_msg_empty').css({'display': 'block'});
                $('#coupon_msg_invalid').css({'display': 'none'});
                $('#coupon_apply_btn').val('APPLY');
            } else if (successval == 3) {
                $('#coupon_msg_invalid').css({'display': 'block'}).html('Coupon Code Expired!');
                $('#coupon_apply_btn').val('APPLY');
            } else if (successval == 4) {
                $('#coupon_msg_invalid').css({'display': 'block'}).html('Not Eligible!');
                $('#coupon_apply_btn').val('APPLY');
            }
        }
    });
}

/*
 * service_agreement_mail
 */
$('#service_agreement_mail').click(function () {

//    var coupon_code = $('#service_agreement_mail').val();
    $.ajax({
        url: URL_PROFILE_PATH + 'serviceagrementmail',
        data: {},
        dataType: 'json',
        type: 'post',
        success: function (output) {
//            alert('successfully send');
            var successval = output.status;
            console.log(successval);
//             console.log('dfasdfad');
//            if (successval == 1) {
//                alert('successfully send');
//
//                $('#service_agr_msg').css({'display': 'block'});
//            } else if (successval == 0) {
//                $('#service_agr_msg').css({'display': 'none'});
//            }
        }
    });
});
/*
 * payorder insert for upgrade membership
 */
//$('#member_details_pay').click(function () {
function member_payment_insert() {
    var revenue_modelid = $('#revenue_modelid').val();
    var revenue_purpose = $('#revenue_purpose').val();
    var addonstype = $('#addonstype').val();
    var totalPrice = $('#totalPrice').val();
    var priceAmount = $('#priceAmount').val();
    var coupon_code = $('#coupon_code').val();
    var coupon_value = $('#coupon_value').val();
    var discount_price = $('#discount_price').val();
    var coupon_offer_title = $('#coupon_offer_title').val();
    var currency = $('#currency').val();
    var payment_gateway = $('#payment_gateway').val();
    $.ajax({
        url: URL_PROFILE_PATH + 'addons/insermemberdetails',
        data: {revenue_modelid: revenue_modelid, discount_price: discount_price, coupon_offer_title: coupon_offer_title, priceAmount: priceAmount, coupon_code: coupon_code, coupon_value: coupon_value, revenue_purpose: revenue_purpose, addonstype: addonstype, totalPrice: totalPrice, currency: currency, payment_gateway: payment_gateway},
        dataType: 'json',
        type: 'post',
//        async:false,
        success: function (output) {
            var successval = output.status;
            if (successval == 1) {
                var paymentString = output.paymentString;
                $('#billdesk_pay_msg').val(paymentString);
                $('#bill_pay_section').load(location.href + ' #bill_pay_section');
                document.getElementById('billdesk_payment_form').submit();
            } else if (successval == 0) {
            }
        }
    });
}


//});
//-----------add product form------------


$("#serviceon").select2({
    placeholder: '--Choose countries--',
    selectOnClose: false,
    tokenSeparators: [" "],
    matcher: function (params, data) {
        return matchStart(params, data);
    }
});

/* dashboard form submit */
function submitdashboardform() {
//    $('#buypreferform').submit();
//    if ($('.select2-selection__choice__remove').data('clicked')) {
//        console.log('hi');
//    }

    var buy_local = $('#buy_local').val();
    var check_buy = $('#prefered_all_buy').val();
    if ($('#prefered_all_buy').is(':checked')) {
        var prefered_all_buy = 1;
    } else {
        prefered_all_buy = 0;
    }
    var buy_keyword = $('#buy_keyword').val();
    var sell_local = $('#sell_local').val();
    var check_sell = $('#prefered_all_sell').val();
    if ($('#prefered_all_sell').is(':checked')) {
        var prefered_all_sell = 1;
    } else {
        prefered_all_sell = 0;
    }
    var sellres_time = $('#sellres_time').val();
    var sell_keyword = $('#sell_keyword').val();
    $.ajax({
        url: URL_PROFILE_PATH + 'buypreference',
        data: {buy_local: buy_local, prefered_all_buy: prefered_all_buy, buy_keyword: buy_keyword, sell_local: sell_local, prefered_all_sell: prefered_all_sell, sellres_time: sellres_time, sell_keyword: sell_keyword},
        dataType: 'json',
        type: 'post',
        success: function (output) {
            var successval = output.success;
            if (successval == 1) {
            }
        }
    });
}


function addservice_processing() {
    $('#addserviceform').parsley().validate("first");
    if ($('#addserviceform').parsley().isValid()) {
        $('#addservices_processing').css({'display': 'block'});
        $('#addservices_submitting').css({'display': 'none'});
    }
}

$(function () {

    $('#story_form,#article_form,#blog_form,#news_form,#press_form,#addtradeshow_form').submit(function () {
        $('#story_form,#article_form,#blog_form,#news_form,#press_form,#addtradeshow_form').parsley().validate("first");
        if ($('#story_form,#article_form,#blog_form,#news_form,#press_form,#addtradeshow_form').parsley().isValid()) {
            $('.submitting').css({'display': 'none'});
            $('.processing').css({'display': 'inline-block', 'width': 'auto'});
        }
    });
});


//$('#basiccompany_form,#addserviceform,#story_form,#proforms,#add_buyingneed,#blog_form,#article_form,#news_form,#press_form,#addtradeshow_form').on('submit', function () {
//    var description = $('#txtdetails,#product_desc,#description,#blogeditor,#busnews,#successstories,#about_event,#exhibitors_event,#visitors_event,#about_company').val();
//    var desc = description.replace(/[\|\^\=\@\<\>\{\}\[\]\#\~\/\\]/g, '');
//    $('#txtdetails,#product_desc,#description,#blogeditor,#busnews,#successstories,#about_event,#exhibitors_event,#visitors_event,#about_company').val(desc);
//});
var validate_module_name = $('#validate_module_name').val();

if (validate_module_name != '' && typeof validate_module_name != 'undefined') {

    $(function () {
        var $sections = $('.form-section');
        function navigateTo(index) {
            // Mark the current section with the class 'current'
            $sections
                    .removeClass('current')
                    .eq(index)
                    .addClass('current');
            // Show only the navigation buttons that make sense for the current section:
            $('.form-navigation .previous').toggle(index > 0);
            var atTheEnd = index >= $sections.length - 1;
            $('.form-navigation .next').toggle(!atTheEnd);
            $('.form-navigation [type=submit]').toggle(atTheEnd);
        }

        function curIndex() {
            // Return the current index by looking at which section has the class 'current'
            return $sections.index($sections.filter('.current'));
        }

        // Previous button is easy, just go back
        $('.form-navigation .previous').click(function () {
            navigateTo(curIndex() - 1);
        });
        // Next button goes forward iff current block validates
        if (validate_module_name == 'verified_membership') {
            $('.form-navigation .next').click(function () {
                if ($('.verified_form').parsley().validate({group: 'block-' + curIndex()}))
                    navigateTo(curIndex() + 1);
            });
        } else if (validate_module_name == 'upgrade_membership') {
            $('.form-navigation .next').click(function () {
                if ($('.upgrade_membership').parsley().validate({group: 'block-' + curIndex()}))
                    navigateTo(curIndex() + 1);
            });
        } else if (validate_module_name == 'ewallet_recharge') {
            $('.form-navigation .next').click(function () {
                if ($('.ewallet_form').parsley().validate({group: 'block-' + curIndex()}))
                    navigateTo(curIndex() + 1);
            });
        }
        // Prepare sections by setting the `data-parsley-group` attribute to 'block-0', 'block-1', etc.
        $sections.each(function (index, section) {
            $(section).find(':input').attr('data-parsley-group', 'block-' + index);
        });
        navigateTo(0); // Start at the beginning
    });
}
function change_remitance_details(remit_value) {
    if (remit_value == 'online') {
        $('#onlinedetails').css('display', 'block');
        $('#dddetails').css('display', 'none');
        $('#chequedetails').css('display', 'none');
        $('#ccavanuedetails').css('display', 'none');
    } else if (remit_value == 'cheque') {
        $('#onlinedetails').css('display', 'none');
        $('#dddetails').css('display', 'none');
        $('#chequedetails').css('display', 'block');
        $('#ccavanuedetails').css('display', 'none');
    } else if (remit_value == 'demand_draft') {
        $('#onlinedetails').css('display', 'none');
        $('#dddetails').css('display', 'block');
        $('#chequedetails').css('display', 'none');
        $('#ccavanuedetails').css('display', 'none');
    } else if (remit_value == 'ccavenue') {
        $('#onlinedetails').css('display', 'none');
        $('#dddetails').css('display', 'none');
        $('#chequedetails').css('display', 'none');
        $('#ccavanuedetails').css('display', 'block');
    }

}
var app = app || {};
// Utils
(function ($, app) {
    'use strict';
    app.utils = {};
    app.utils.formDataSuppoerted = (function () {
        return !!('FormData' in window);
    }());
}(jQuery, app));
// Parsley validators
//(function ($, app) {
//    'use strict';
//    window.Parsley
//            .addValidator('filemaxmegabytes', {
//                requirementType: 'string',
//                validateString: function (value, requirement, parsleyInstance) {
//
//                    if (!app.utils.formDataSuppoerted) {
//                        return true;
//                    }
//
//                    var file = parsleyInstance.$element[0].files;
//                    var maxBytes = requirement * 1048576;
//                    if (file.length == 0) {
//                        return true;
//                    }
//
//                    return file.length === 1 && file[0].size <= maxBytes;
//                },
//                messages: {
//                    en: 'File size exceeds 5 Mb'
//                }
//            })
//            .addValidator('filemimetypes', {
//                requirementType: 'string',
//                validateString: function (value, requirement, parsleyInstance) {
//
//                    if (!app.utils.formDataSuppoerted) {
//                        return true;
//                    }
//
//                    var file = parsleyInstance.$element[0].files;
//                    if (file.length == 0) {
//                        return true;
//                    }
//
//                    var allowedMimeTypes = requirement.replace(/\s/g, "").split(',');
//                    return allowedMimeTypes.indexOf(file[0].type) !== -1;
//                },
////                messages: {
////                    en: 'You can upload only  .jpeg, .jpg, .png'
////                }
//            });
//}(jQuery, app));
// Parsley Init
(function ($, app) {
    'use strict';
    $('#verified_form').parsley();
    $('#companyprofile-form').parsley();
    $('#stand_certificate_form').parsley();
    $('#qa_certificate_form').parsley();

}(jQuery, app));
function file_validation() {
    var tan_number = $('#tan_number').val();
    var tan_file = $('#tan_file').val();
    var pan_number = $('#pan_number').val();
    var pan_file = $('#pan_file').val();
    var tin_number = $('#tin_number').val();
    var tin_file = $('#tin_file').val();
    var iec_number = $('#iec_number').val();
    var iec_file = $('#iec_file').val();
    if ((tan_number == '' || tan_file == '') && (pan_number == '' || pan_file == '') && (tin_number == '' || tin_file == '') && (iec_number == '' || iec_file == '')) {
        if ((tan_number != '' && tan_file == '')) {
            $('#tan_file').attr('required', 'required');
            $('#tan_file').attr('data-parsley-required-message', 'Choose tan_file');
        } else if (tan_number == '' && tan_file != '') {
            $('#tan_number').attr('required', 'required');
            $('#tan_number').attr('data-parsley-required-message', 'Enter Tan Number');
        } else if ((pan_number != '' && pan_file == '')) {
            $('#pan_file').attr('required', 'required');
            $('#pan_file').attr('data-parsley-required-message', 'Choose Pan File');
        } else if (pan_number == '' && pan_file != '') {
            $('#pan_number').attr('required', 'required');
            $('#pan_number').attr('data-parsley-required-message', 'Enter Pan Number');
        } else if ((tin_number != '' && tin_file == '')) {
            $('#tin_file').attr('required', 'required');
            $('#tin_file').attr('data-parsley-required-message', 'Choose Tin File');
        } else if (tin_number == '' && tin_file != '') {
            $('#tin_number').attr('required', 'required');
            $('#tin_number').attr('data-parsley-required-message', 'Enter Tin Number');
        } else if ((iec_number != '' && iec_file == '')) {
            $('#iec_file').attr('required', 'required');
            $('#iec_file').attr('data-parsley-required-message', 'Choose IEC File');
        } else if (iec_number == '' && iec_file != '') {
            $('#iec_number').attr('required', 'required');
            $('#iec_number').attr('data-parsley-required-message', 'Enter IEC Number');
        } else {
            $('#tan_number').attr('required', 'required');
            $('#tan_file').attr('required', 'required');
            $('#tan_number').attr('data-parsley-required-message', 'Choose Any One Attachment with proof');
            $('#tan_file').attr('data-parsley-required-message', 'Choose file');
            $('#pan_file').removeAttr('required');
            $('#pan_number').removeAttr('required');
            $('#tin_file').removeAttr('required');
            $('#tin_number').removeAttr('required');
            $('#iec_file').removeAttr('required');
            $('#iec_number').removeAttr('required');
        }
    } else {
        $('#tan_number').removeAttr('required');
        $('#tan_file').removeAttr('required');
    }
}
//function checkAvailbalance(addonamount) {
//
//}
function filechangefunc(val) {
    if (val == 1) {
        $('#cheque_number').attr('required', 'required');
        $('#sender_name').attr('required', 'required');
        $('#sending_from').attr('required', 'required');
        $('#postal_date').attr('required', 'required');
        $('#courier_name').attr('required', 'required');
        $('#tracking_number').attr('required', 'required');
        $('#bank_name').removeAttr('required');
        $('#branch_name').removeAttr('required');
        $('#branch_code').removeAttr('required');
        $('#ifsc_code').removeAttr('required');
        $('#bank_date').removeAttr('required');

    } else if (val == 2) {
        $('#cheque_number').removeAttr('required');
        $('#sender_name').removeAttr('required');
        $('#sending_from').removeAttr('required');
        $('#postal_date').removeAttr('required');
        $('#courier_name').removeAttr('required');
        $('#tracking_number').removeAttr('required');

        $('#bank_name').attr('required', 'required');
        $('#branch_name').attr('required', 'required');
        $('#branch_code').attr('required', 'required');
        $('#ifsc_code').attr('required', 'required');
        $('#bank_date').attr('required', 'required');
    }
}
function readURL(input, div) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        var extension = input.files[0].name.split('.').pop().toLowerCase();
        reader.onload = function (e) {
            if (extension == 'jpg' || extension == 'jpeg' || extension == 'png') {
                $('#' + div)
                        .attr('src', e.target.result)
                        .width(110)
                        .height(110);
            } else {
                var filenoimage = URL_CDN_PATH + '/assets/img/noimage.png';
                $('#' + div)
                        .attr('src', filenoimage)
                        .width(110)
                        .height(110);
            }
        };

        reader.readAsDataURL(input.files[0]);
    }
}
function readstandURL(input, div) {

    if (input.files && input.files[0]) {
        var extension = input.files[0].name.split('.').pop().toLowerCase();

        var reader = new FileReader();
//        console.log(input.files[0]);
        reader.onload = function (e) {
            if (extension == 'jpg' || extension == 'jpeg' || extension == 'png' || extension == 'gif') {
                $('.' + div)
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
            } else if (extension == 'pdf' || extension == 'docx' || extension == 'doc') {
                var docurl = URL_CDN_PATH + '/assets/img/icons/doc.png';
                $('.' + div)
                        .attr('src', docurl)
                        .width(100)
                        .height(100);
            } else {
                var docurl = URL_CDN_PATH + '/assets/img/noimage.png';
                $('.' + div)
                        .attr('src', docurl)
                        .width(100)
                        .height(100);
            }
        };

        if (extension == 'jpg' || extension == 'jpeg' || extension == 'png' || extension == 'gif' || extension == 'pdf' || extension == 'docx' || extension == 'doc') {
            reader.readAsDataURL(input.files[0]);
        }
    }
}
function readqaURL(input, div) {

    if (input.files && input.files[0]) {
        var extension = input.files[0].name.split('.').pop().toLowerCase();

        var reader = new FileReader();
//        console.log(input.files[0]);
        reader.onload = function (e) {
            if (extension == 'jpg' || extension == 'jpeg' || extension == 'png' || extension == 'gif') {
                $('.' + div)
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
            } else if (extension == 'pdf' || extension == 'docx' || extension == 'doc') {
                var docurl = URL_CDN_PATH + '/assets/img/icons/doc.png';
                $('.' + div)
                        .attr('src', docurl)
                        .width(100)
                        .height(100);
            } else {
                var docurl = URL_CDN_PATH + '/assets/img/noimage.png';
                $('.' + div)
                        .attr('src', docurl)
                        .width(100)
                        .height(100);
            }
        };
        if (extension == 'jpg' || extension == 'jpeg' || extension == 'png' || extension == 'gif' || extension == 'pdf' || extension == 'docx' || extension == 'doc') {
            reader.readAsDataURL(input.files[0]);
        }
    }
}
function replaceslug(slugvalue) {
    $('#slug_name').val(slugvalue);
}